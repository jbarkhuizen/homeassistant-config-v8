
function $parcel$interopDefault(a) {
  return a && a.__esModule ? a.default : a;
}
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ /* global Reflect, Promise, SuppressedError, Symbol, Iterator */ var $e710f43c4558477c$var$extendStatics = function(d, b) {
    $e710f43c4558477c$var$extendStatics = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(d, b) {
        d.__proto__ = b;
    } || function(d, b) {
        for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return $e710f43c4558477c$var$extendStatics(d, b);
};
function $e710f43c4558477c$export$a8ba968b8961cb8a(d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    $e710f43c4558477c$var$extendStatics(d, b);
    function __() {
        this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var $e710f43c4558477c$export$18ce0697a983be9b = function() {
    $e710f43c4558477c$export$18ce0697a983be9b = Object.assign || function __assign(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return $e710f43c4558477c$export$18ce0697a983be9b.apply(this, arguments);
};
function $e710f43c4558477c$export$3c9a16f847548506(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") {
        for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++)if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
}
function $e710f43c4558477c$export$29e00dfd3077644b(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function $e710f43c4558477c$export$d5ad3fd78186038f(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function $e710f43c4558477c$export$3a84e1ae4e97e9b0(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) {
        if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected");
        return f;
    }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for(var i = decorators.length - 1; i >= 0; i--){
        var context = {};
        for(var p in contextIn)context[p] = p === "access" ? {} : contextIn[p];
        for(var p in contextIn.access)context.access[p] = contextIn.access[p];
        context.addInitializer = function(f) {
            if (done) throw new TypeError("Cannot add initializers after decoration has completed");
            extraInitializers.push(accept(f || null));
        };
        var result = (0, decorators[i])(kind === "accessor" ? {
            get: descriptor.get,
            set: descriptor.set
        } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        } else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
}
function $e710f43c4558477c$export$d831c04e792af3d(thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for(var i = 0; i < initializers.length; i++)value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    return useValue ? value : void 0;
}
function $e710f43c4558477c$export$6a2a36740a146cb8(x) {
    return typeof x === "symbol" ? x : "".concat(x);
}
function $e710f43c4558477c$export$d1a06452d3489bc7(f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", {
        configurable: true,
        value: prefix ? "".concat(prefix, " ", name) : name
    });
}
function $e710f43c4558477c$export$f1db080c865becb9(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function $e710f43c4558477c$export$1050f835b63b671e(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function $e710f43c4558477c$export$67ebef60e6f28a6(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var $e710f43c4558477c$export$45d3717a4c69092e = Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
        enumerable: true,
        get: function() {
            return m[k];
        }
    };
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
};
function $e710f43c4558477c$export$f33643c0debef087(m, o) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) $e710f43c4558477c$export$45d3717a4c69092e(o, m, p);
}
function $e710f43c4558477c$export$19a8beecd37a4c45(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function $e710f43c4558477c$export$8d051b38c9118094(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while((n === void 0 || n-- > 0) && !(r = i.next()).done)ar.push(r.value);
    } catch (error) {
        e = {
            error: error
        };
    } finally{
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally{
            if (e) throw e.error;
        }
    }
    return ar;
}
function $e710f43c4558477c$export$afc72e2116322959() {
    for(var ar = [], i = 0; i < arguments.length; i++)ar = ar.concat($e710f43c4558477c$export$8d051b38c9118094(arguments[i]));
    return ar;
}
function $e710f43c4558477c$export$6388937ca91ccae8() {
    for(var s = 0, i = 0, il = arguments.length; i < il; i++)s += arguments[i].length;
    for(var r = Array(s), k = 0, i = 0; i < il; i++)for(var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)r[k] = a[j];
    return r;
}
function $e710f43c4558477c$export$1216008129fb82ed(to, from, pack) {
    if (pack || arguments.length === 2) {
        for(var i = 0, l = from.length, ar; i < l; i++)if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}
function $e710f43c4558477c$export$10c90e4f7922046c(v) {
    return this instanceof $e710f43c4558477c$export$10c90e4f7922046c ? (this.v = v, this) : new $e710f43c4558477c$export$10c90e4f7922046c(v);
}
function $e710f43c4558477c$export$e427f37a30a4de9b(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    function awaitReturn(f) {
        return function(v) {
            return Promise.resolve(v).then(f, reject);
        };
    }
    function verb(n, f) {
        if (g[n]) {
            i[n] = function(v) {
                return new Promise(function(a, b) {
                    q.push([
                        n,
                        v,
                        a,
                        b
                    ]) > 1 || resume(n, v);
                });
            };
            if (f) i[n] = f(i[n]);
        }
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof $e710f43c4558477c$export$10c90e4f7922046c ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
}
function $e710f43c4558477c$export$bbd80228419bb833(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function(e) {
        throw e;
    }), verb("return"), i[Symbol.iterator] = function() {
        return this;
    }, i;
    function verb(n, f) {
        i[n] = o[n] ? function(v) {
            return (p = !p) ? {
                value: $e710f43c4558477c$export$10c90e4f7922046c(o[n](v)),
                done: false
            } : f ? f(v) : v;
        } : f;
    }
}
function $e710f43c4558477c$export$e3b29a3d6162315f(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof $e710f43c4558477c$export$19a8beecd37a4c45 === "function" ? $e710f43c4558477c$export$19a8beecd37a4c45(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
}
function $e710f43c4558477c$export$4fb47efe1390b86f(cooked, raw) {
    if (Object.defineProperty) Object.defineProperty(cooked, "raw", {
        value: raw
    });
    else cooked.raw = raw;
    return cooked;
}
var $e710f43c4558477c$var$__setModuleDefault = Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
};
var $e710f43c4558477c$var$ownKeys = function(o) {
    $e710f43c4558477c$var$ownKeys = Object.getOwnPropertyNames || function(o) {
        var ar = [];
        for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
        return ar;
    };
    return $e710f43c4558477c$var$ownKeys(o);
};
function $e710f43c4558477c$export$c21735bcef00d192(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k = $e710f43c4558477c$var$ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") $e710f43c4558477c$export$45d3717a4c69092e(result, mod, k[i]);
    }
    $e710f43c4558477c$var$__setModuleDefault(result, mod);
    return result;
}
function $e710f43c4558477c$export$da59b14a69baef04(mod) {
    return mod && mod.__esModule ? mod : {
        default: mod
    };
}
function $e710f43c4558477c$export$d5dcaf168c640c35(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function $e710f43c4558477c$export$d40a35129aaff81f(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function $e710f43c4558477c$export$81fdc39f203e4e04(state, receiver) {
    if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}
function $e710f43c4558477c$export$88ac25d8e944e405(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose, inner;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
            if (async) inner = dispose;
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        if (inner) dispose = function() {
            try {
                inner.call(this);
            } catch (e) {
                return Promise.reject(e);
            }
        };
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) env.stack.push({
        async: true
    });
    return value;
}
var $e710f43c4558477c$var$_SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
function $e710f43c4558477c$export$8f076105dc360e92(env) {
    function fail(e) {
        env.error = env.hasError ? new $e710f43c4558477c$var$_SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    var r, s = 0;
    function next() {
        while(r = env.stack.pop())try {
            if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
            if (r.dispose) {
                var result = r.dispose.call(r.value);
                if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) {
                    fail(e);
                    return next();
                });
            } else s |= 1;
        } catch (e) {
            fail(e);
        }
        if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
        if (env.hasError) throw env.error;
    }
    return next();
}
function $e710f43c4558477c$export$889dfb5d17574b0b(path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function(m, tsx, d, ext, cm) {
        return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : d + ext + "." + cm.toLowerCase() + "js";
    });
    return path;
}
var $e710f43c4558477c$export$2e2bcd8739ae039 = {
    __extends: $e710f43c4558477c$export$a8ba968b8961cb8a,
    __assign: $e710f43c4558477c$export$18ce0697a983be9b,
    __rest: $e710f43c4558477c$export$3c9a16f847548506,
    __decorate: $e710f43c4558477c$export$29e00dfd3077644b,
    __param: $e710f43c4558477c$export$d5ad3fd78186038f,
    __esDecorate: $e710f43c4558477c$export$3a84e1ae4e97e9b0,
    __runInitializers: $e710f43c4558477c$export$d831c04e792af3d,
    __propKey: $e710f43c4558477c$export$6a2a36740a146cb8,
    __setFunctionName: $e710f43c4558477c$export$d1a06452d3489bc7,
    __metadata: $e710f43c4558477c$export$f1db080c865becb9,
    __awaiter: $e710f43c4558477c$export$1050f835b63b671e,
    __generator: $e710f43c4558477c$export$67ebef60e6f28a6,
    __createBinding: $e710f43c4558477c$export$45d3717a4c69092e,
    __exportStar: $e710f43c4558477c$export$f33643c0debef087,
    __values: $e710f43c4558477c$export$19a8beecd37a4c45,
    __read: $e710f43c4558477c$export$8d051b38c9118094,
    __spread: $e710f43c4558477c$export$afc72e2116322959,
    __spreadArrays: $e710f43c4558477c$export$6388937ca91ccae8,
    __spreadArray: $e710f43c4558477c$export$1216008129fb82ed,
    __await: $e710f43c4558477c$export$10c90e4f7922046c,
    __asyncGenerator: $e710f43c4558477c$export$e427f37a30a4de9b,
    __asyncDelegator: $e710f43c4558477c$export$bbd80228419bb833,
    __asyncValues: $e710f43c4558477c$export$e3b29a3d6162315f,
    __makeTemplateObject: $e710f43c4558477c$export$4fb47efe1390b86f,
    __importStar: $e710f43c4558477c$export$c21735bcef00d192,
    __importDefault: $e710f43c4558477c$export$da59b14a69baef04,
    __classPrivateFieldGet: $e710f43c4558477c$export$d5dcaf168c640c35,
    __classPrivateFieldSet: $e710f43c4558477c$export$d40a35129aaff81f,
    __classPrivateFieldIn: $e710f43c4558477c$export$81fdc39f203e4e04,
    __addDisposableResource: $e710f43c4558477c$export$88ac25d8e944e405,
    __disposeResources: $e710f43c4558477c$export$8f076105dc360e92,
    __rewriteRelativeImportExtension: $e710f43c4558477c$export$889dfb5d17574b0b
};


/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $def2de46b9306e8a$var$t = globalThis, $def2de46b9306e8a$export$b4d10f6001c083c2 = $def2de46b9306e8a$var$t.ShadowRoot && (void 0 === $def2de46b9306e8a$var$t.ShadyCSS || $def2de46b9306e8a$var$t.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, $def2de46b9306e8a$var$s = Symbol(), $def2de46b9306e8a$var$o = new WeakMap;
class $def2de46b9306e8a$export$505d1e8739bad805 {
    constructor(t, e, o){
        if (this._$cssResult$ = !0, o !== $def2de46b9306e8a$var$s) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
        this.cssText = t, this.t = e;
    }
    get styleSheet() {
        let t = this.o;
        const s = this.t;
        if ($def2de46b9306e8a$export$b4d10f6001c083c2 && void 0 === t) {
            const e = void 0 !== s && 1 === s.length;
            e && (t = $def2de46b9306e8a$var$o.get(s)), void 0 === t && ((this.o = t = new CSSStyleSheet).replaceSync(this.cssText), e && $def2de46b9306e8a$var$o.set(s, t));
        }
        return t;
    }
    toString() {
        return this.cssText;
    }
}
const $def2de46b9306e8a$export$8d80f9cac07cdb3 = (t)=>new $def2de46b9306e8a$export$505d1e8739bad805("string" == typeof t ? t : t + "", void 0, $def2de46b9306e8a$var$s), $def2de46b9306e8a$export$dbf350e5966cf602 = (t, ...e)=>{
    const o = 1 === t.length ? t[0] : e.reduce((e, s, o)=>e + ((t)=>{
            if (!0 === t._$cssResult$) return t.cssText;
            if ("number" == typeof t) return t;
            throw Error("Value passed to 'css' function must be a 'css' function result: " + t + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
        })(s) + t[o + 1], t[0]);
    return new $def2de46b9306e8a$export$505d1e8739bad805(o, t, $def2de46b9306e8a$var$s);
}, $def2de46b9306e8a$export$2ca4a66ec4cecb90 = (s, o)=>{
    if ($def2de46b9306e8a$export$b4d10f6001c083c2) s.adoptedStyleSheets = o.map((t)=>t instanceof CSSStyleSheet ? t : t.styleSheet);
    else for (const e of o){
        const o = document.createElement("style"), n = $def2de46b9306e8a$var$t.litNonce;
        void 0 !== n && o.setAttribute("nonce", n), o.textContent = e.cssText, s.appendChild(o);
    }
}, $def2de46b9306e8a$export$ee69dfd951e24778 = $def2de46b9306e8a$export$b4d10f6001c083c2 ? (t)=>t : (t)=>t instanceof CSSStyleSheet ? ((t)=>{
        let e = "";
        for (const s of t.cssRules)e += s.cssText;
        return $def2de46b9306e8a$export$8d80f9cac07cdb3(e);
    })(t) : t;


/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const { is: $19fe8e3abedf4df0$var$i, defineProperty: $19fe8e3abedf4df0$var$e, getOwnPropertyDescriptor: $19fe8e3abedf4df0$var$h, getOwnPropertyNames: $19fe8e3abedf4df0$var$r, getOwnPropertySymbols: $19fe8e3abedf4df0$var$o, getPrototypeOf: $19fe8e3abedf4df0$var$n } = Object, $19fe8e3abedf4df0$var$a = globalThis, $19fe8e3abedf4df0$var$c = $19fe8e3abedf4df0$var$a.trustedTypes, $19fe8e3abedf4df0$var$l = $19fe8e3abedf4df0$var$c ? $19fe8e3abedf4df0$var$c.emptyScript : "", $19fe8e3abedf4df0$var$p = $19fe8e3abedf4df0$var$a.reactiveElementPolyfillSupport, $19fe8e3abedf4df0$var$d = (t, s)=>t, $19fe8e3abedf4df0$export$7312b35fbf521afb = {
    toAttribute (t, s) {
        switch(s){
            case Boolean:
                t = t ? $19fe8e3abedf4df0$var$l : null;
                break;
            case Object:
            case Array:
                t = null == t ? t : JSON.stringify(t);
        }
        return t;
    },
    fromAttribute (t, s) {
        let i = t;
        switch(s){
            case Boolean:
                i = null !== t;
                break;
            case Number:
                i = null === t ? null : Number(t);
                break;
            case Object:
            case Array:
                try {
                    i = JSON.parse(t);
                } catch (t) {
                    i = null;
                }
        }
        return i;
    }
}, $19fe8e3abedf4df0$export$53a6892c50694894 = (t, s)=>!$19fe8e3abedf4df0$var$i(t, s), $19fe8e3abedf4df0$var$b = {
    attribute: !0,
    type: String,
    converter: $19fe8e3abedf4df0$export$7312b35fbf521afb,
    reflect: !1,
    useDefault: !1,
    hasChanged: $19fe8e3abedf4df0$export$53a6892c50694894
};
Symbol.metadata ??= Symbol("metadata"), $19fe8e3abedf4df0$var$a.litPropertyMetadata ??= new WeakMap;
class $19fe8e3abedf4df0$export$c7c07a37856565d extends HTMLElement {
    static addInitializer(t) {
        this._$Ei(), (this.l ??= []).push(t);
    }
    static get observedAttributes() {
        return this.finalize(), this._$Eh && [
            ...this._$Eh.keys()
        ];
    }
    static createProperty(t, s = $19fe8e3abedf4df0$var$b) {
        if (s.state && (s.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((s = Object.create(s)).wrapped = !0), this.elementProperties.set(t, s), !s.noAccessor) {
            const i = Symbol(), h = this.getPropertyDescriptor(t, i, s);
            void 0 !== h && $19fe8e3abedf4df0$var$e(this.prototype, t, h);
        }
    }
    static getPropertyDescriptor(t, s, i) {
        const { get: e, set: r } = $19fe8e3abedf4df0$var$h(this.prototype, t) ?? {
            get () {
                return this[s];
            },
            set (t) {
                this[s] = t;
            }
        };
        return {
            get: e,
            set (s) {
                const h = e?.call(this);
                r?.call(this, s), this.requestUpdate(t, h, i);
            },
            configurable: !0,
            enumerable: !0
        };
    }
    static getPropertyOptions(t) {
        return this.elementProperties.get(t) ?? $19fe8e3abedf4df0$var$b;
    }
    static _$Ei() {
        if (this.hasOwnProperty($19fe8e3abedf4df0$var$d("elementProperties"))) return;
        const t = $19fe8e3abedf4df0$var$n(this);
        t.finalize(), void 0 !== t.l && (this.l = [
            ...t.l
        ]), this.elementProperties = new Map(t.elementProperties);
    }
    static finalize() {
        if (this.hasOwnProperty($19fe8e3abedf4df0$var$d("finalized"))) return;
        if (this.finalized = !0, this._$Ei(), this.hasOwnProperty($19fe8e3abedf4df0$var$d("properties"))) {
            const t = this.properties, s = [
                ...$19fe8e3abedf4df0$var$r(t),
                ...$19fe8e3abedf4df0$var$o(t)
            ];
            for (const i of s)this.createProperty(i, t[i]);
        }
        const t = this[Symbol.metadata];
        if (null !== t) {
            const s = litPropertyMetadata.get(t);
            if (void 0 !== s) for (const [t, i] of s)this.elementProperties.set(t, i);
        }
        this._$Eh = new Map;
        for (const [t, s] of this.elementProperties){
            const i = this._$Eu(t, s);
            void 0 !== i && this._$Eh.set(i, t);
        }
        this.elementStyles = this.finalizeStyles(this.styles);
    }
    static finalizeStyles(s) {
        const i = [];
        if (Array.isArray(s)) {
            const e = new Set(s.flat(1 / 0).reverse());
            for (const s of e)i.unshift((0, $def2de46b9306e8a$export$ee69dfd951e24778)(s));
        } else void 0 !== s && i.push((0, $def2de46b9306e8a$export$ee69dfd951e24778)(s));
        return i;
    }
    static _$Eu(t, s) {
        const i = s.attribute;
        return !1 === i ? void 0 : "string" == typeof i ? i : "string" == typeof t ? t.toLowerCase() : void 0;
    }
    constructor(){
        super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
    }
    _$Ev() {
        this._$ES = new Promise((t)=>this.enableUpdating = t), this._$AL = new Map, this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t)=>t(this));
    }
    addController(t) {
        (this._$EO ??= new Set).add(t), void 0 !== this.renderRoot && this.isConnected && t.hostConnected?.();
    }
    removeController(t) {
        this._$EO?.delete(t);
    }
    _$E_() {
        const t = new Map, s = this.constructor.elementProperties;
        for (const i of s.keys())this.hasOwnProperty(i) && (t.set(i, this[i]), delete this[i]);
        t.size > 0 && (this._$Ep = t);
    }
    createRenderRoot() {
        const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
        return (0, $def2de46b9306e8a$export$2ca4a66ec4cecb90)(t, this.constructor.elementStyles), t;
    }
    connectedCallback() {
        this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$EO?.forEach((t)=>t.hostConnected?.());
    }
    enableUpdating(t) {}
    disconnectedCallback() {
        this._$EO?.forEach((t)=>t.hostDisconnected?.());
    }
    attributeChangedCallback(t, s, i) {
        this._$AK(t, i);
    }
    _$ET(t, s) {
        const i = this.constructor.elementProperties.get(t), e = this.constructor._$Eu(t, i);
        if (void 0 !== e && !0 === i.reflect) {
            const h = (void 0 !== i.converter?.toAttribute ? i.converter : $19fe8e3abedf4df0$export$7312b35fbf521afb).toAttribute(s, i.type);
            this._$Em = t, null == h ? this.removeAttribute(e) : this.setAttribute(e, h), this._$Em = null;
        }
    }
    _$AK(t, s) {
        const i = this.constructor, e = i._$Eh.get(t);
        if (void 0 !== e && this._$Em !== e) {
            const t = i.getPropertyOptions(e), h = "function" == typeof t.converter ? {
                fromAttribute: t.converter
            } : void 0 !== t.converter?.fromAttribute ? t.converter : $19fe8e3abedf4df0$export$7312b35fbf521afb;
            this._$Em = e;
            const r = h.fromAttribute(s, t.type);
            this[e] = r ?? this._$Ej?.get(e) ?? r, this._$Em = null;
        }
    }
    requestUpdate(t, s, i) {
        if (void 0 !== t) {
            const e = this.constructor, h = this[t];
            if (i ??= e.getPropertyOptions(t), !((i.hasChanged ?? $19fe8e3abedf4df0$export$53a6892c50694894)(h, s) || i.useDefault && i.reflect && h === this._$Ej?.get(t) && !this.hasAttribute(e._$Eu(t, i)))) return;
            this.C(t, s, i);
        }
        !1 === this.isUpdatePending && (this._$ES = this._$EP());
    }
    C(t, s, { useDefault: i, reflect: e, wrapped: h }, r) {
        i && !(this._$Ej ??= new Map).has(t) && (this._$Ej.set(t, r ?? s ?? this[t]), !0 !== h || void 0 !== r) || (this._$AL.has(t) || (this.hasUpdated || i || (s = void 0), this._$AL.set(t, s)), !0 === e && this._$Em !== t && (this._$Eq ??= new Set).add(t));
    }
    async _$EP() {
        this.isUpdatePending = !0;
        try {
            await this._$ES;
        } catch (t) {
            Promise.reject(t);
        }
        const t = this.scheduleUpdate();
        return null != t && await t, !this.isUpdatePending;
    }
    scheduleUpdate() {
        return this.performUpdate();
    }
    performUpdate() {
        if (!this.isUpdatePending) return;
        if (!this.hasUpdated) {
            if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
                for (const [t, s] of this._$Ep)this[t] = s;
                this._$Ep = void 0;
            }
            const t = this.constructor.elementProperties;
            if (t.size > 0) for (const [s, i] of t){
                const { wrapped: t } = i, e = this[s];
                !0 !== t || this._$AL.has(s) || void 0 === e || this.C(s, void 0, i, e);
            }
        }
        let t = !1;
        const s = this._$AL;
        try {
            t = this.shouldUpdate(s), t ? (this.willUpdate(s), this._$EO?.forEach((t)=>t.hostUpdate?.()), this.update(s)) : this._$EM();
        } catch (s) {
            throw t = !1, this._$EM(), s;
        }
        t && this._$AE(s);
    }
    willUpdate(t) {}
    _$AE(t) {
        this._$EO?.forEach((t)=>t.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
    }
    _$EM() {
        this._$AL = new Map, this.isUpdatePending = !1;
    }
    get updateComplete() {
        return this.getUpdateComplete();
    }
    getUpdateComplete() {
        return this._$ES;
    }
    shouldUpdate(t) {
        return !0;
    }
    update(t) {
        this._$Eq &&= this._$Eq.forEach((t)=>this._$ET(t, this[t])), this._$EM();
    }
    updated(t) {}
    firstUpdated(t) {}
}
$19fe8e3abedf4df0$export$c7c07a37856565d.elementStyles = [], $19fe8e3abedf4df0$export$c7c07a37856565d.shadowRootOptions = {
    mode: "open"
}, $19fe8e3abedf4df0$export$c7c07a37856565d[$19fe8e3abedf4df0$var$d("elementProperties")] = new Map, $19fe8e3abedf4df0$export$c7c07a37856565d[$19fe8e3abedf4df0$var$d("finalized")] = new Map, $19fe8e3abedf4df0$var$p?.({
    ReactiveElement: $19fe8e3abedf4df0$export$c7c07a37856565d
}), ($19fe8e3abedf4df0$var$a.reactiveElementVersions ??= []).push("2.1.1");


/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $f58f44579a4747ac$var$t = globalThis, $f58f44579a4747ac$var$i = $f58f44579a4747ac$var$t.trustedTypes, $f58f44579a4747ac$var$s = $f58f44579a4747ac$var$i ? $f58f44579a4747ac$var$i.createPolicy("lit-html", {
    createHTML: (t)=>t
}) : void 0, $f58f44579a4747ac$var$e = "$lit$", $f58f44579a4747ac$var$h = `lit$${Math.random().toFixed(9).slice(2)}$`, $f58f44579a4747ac$var$o = "?" + $f58f44579a4747ac$var$h, $f58f44579a4747ac$var$n = `<${$f58f44579a4747ac$var$o}>`, $f58f44579a4747ac$var$r = document, $f58f44579a4747ac$var$l = ()=>$f58f44579a4747ac$var$r.createComment(""), $f58f44579a4747ac$var$c = (t)=>null === t || "object" != typeof t && "function" != typeof t, $f58f44579a4747ac$var$a = Array.isArray, $f58f44579a4747ac$var$u = (t)=>$f58f44579a4747ac$var$a(t) || "function" == typeof t?.[Symbol.iterator], $f58f44579a4747ac$var$d = "[ \t\n\f\r]", $f58f44579a4747ac$var$f = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, $f58f44579a4747ac$var$v = /-->/g, $f58f44579a4747ac$var$_ = />/g, $f58f44579a4747ac$var$m = RegExp(`>|${$f58f44579a4747ac$var$d}(?:([^\\s"'>=/]+)(${$f58f44579a4747ac$var$d}*=${$f58f44579a4747ac$var$d}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`, "g"), $f58f44579a4747ac$var$p = /'/g, $f58f44579a4747ac$var$g = /"/g, $f58f44579a4747ac$var$$ = /^(?:script|style|textarea|title)$/i, $f58f44579a4747ac$var$y = (t)=>(i, ...s)=>({
            _$litType$: t,
            strings: i,
            values: s
        }), $f58f44579a4747ac$export$c0bb0b647f701bb5 = $f58f44579a4747ac$var$y(1), $f58f44579a4747ac$export$7ed1367e7fa1ad68 = $f58f44579a4747ac$var$y(2), $f58f44579a4747ac$export$47d5b44d225be5b4 = $f58f44579a4747ac$var$y(3), $f58f44579a4747ac$export$9c068ae9cc5db4e8 = Symbol.for("lit-noChange"), $f58f44579a4747ac$export$45b790e32b2810ee = Symbol.for("lit-nothing"), $f58f44579a4747ac$var$A = new WeakMap, $f58f44579a4747ac$var$C = $f58f44579a4747ac$var$r.createTreeWalker($f58f44579a4747ac$var$r, 129);
function $f58f44579a4747ac$var$P(t, i) {
    if (!$f58f44579a4747ac$var$a(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
    return void 0 !== $f58f44579a4747ac$var$s ? $f58f44579a4747ac$var$s.createHTML(i) : i;
}
const $f58f44579a4747ac$var$V = (t, i)=>{
    const s = t.length - 1, o = [];
    let r, l = 2 === i ? "<svg>" : 3 === i ? "<math>" : "", c = $f58f44579a4747ac$var$f;
    for(let i = 0; i < s; i++){
        const s = t[i];
        let a, u, d = -1, y = 0;
        for(; y < s.length && (c.lastIndex = y, u = c.exec(s), null !== u);)y = c.lastIndex, c === $f58f44579a4747ac$var$f ? "!--" === u[1] ? c = $f58f44579a4747ac$var$v : void 0 !== u[1] ? c = $f58f44579a4747ac$var$_ : void 0 !== u[2] ? ($f58f44579a4747ac$var$$.test(u[2]) && (r = RegExp("</" + u[2], "g")), c = $f58f44579a4747ac$var$m) : void 0 !== u[3] && (c = $f58f44579a4747ac$var$m) : c === $f58f44579a4747ac$var$m ? ">" === u[0] ? (c = r ?? $f58f44579a4747ac$var$f, d = -1) : void 0 === u[1] ? d = -2 : (d = c.lastIndex - u[2].length, a = u[1], c = void 0 === u[3] ? $f58f44579a4747ac$var$m : '"' === u[3] ? $f58f44579a4747ac$var$g : $f58f44579a4747ac$var$p) : c === $f58f44579a4747ac$var$g || c === $f58f44579a4747ac$var$p ? c = $f58f44579a4747ac$var$m : c === $f58f44579a4747ac$var$v || c === $f58f44579a4747ac$var$_ ? c = $f58f44579a4747ac$var$f : (c = $f58f44579a4747ac$var$m, r = void 0);
        const x = c === $f58f44579a4747ac$var$m && t[i + 1].startsWith("/>") ? " " : "";
        l += c === $f58f44579a4747ac$var$f ? s + $f58f44579a4747ac$var$n : d >= 0 ? (o.push(a), s.slice(0, d) + $f58f44579a4747ac$var$e + s.slice(d) + $f58f44579a4747ac$var$h + x) : s + $f58f44579a4747ac$var$h + (-2 === d ? i : x);
    }
    return [
        $f58f44579a4747ac$var$P(t, l + (t[s] || "<?>") + (2 === i ? "</svg>" : 3 === i ? "</math>" : "")),
        o
    ];
};
class $f58f44579a4747ac$var$N {
    constructor({ strings: t, _$litType$: s }, n){
        let r;
        this.parts = [];
        let c = 0, a = 0;
        const u = t.length - 1, d = this.parts, [f, v] = $f58f44579a4747ac$var$V(t, s);
        if (this.el = $f58f44579a4747ac$var$N.createElement(f, n), $f58f44579a4747ac$var$C.currentNode = this.el.content, 2 === s || 3 === s) {
            const t = this.el.content.firstChild;
            t.replaceWith(...t.childNodes);
        }
        for(; null !== (r = $f58f44579a4747ac$var$C.nextNode()) && d.length < u;){
            if (1 === r.nodeType) {
                if (r.hasAttributes()) for (const t of r.getAttributeNames())if (t.endsWith($f58f44579a4747ac$var$e)) {
                    const i = v[a++], s = r.getAttribute(t).split($f58f44579a4747ac$var$h), e = /([.?@])?(.*)/.exec(i);
                    d.push({
                        type: 1,
                        index: c,
                        name: e[2],
                        strings: s,
                        ctor: "." === e[1] ? $f58f44579a4747ac$var$H : "?" === e[1] ? $f58f44579a4747ac$var$I : "@" === e[1] ? $f58f44579a4747ac$var$L : $f58f44579a4747ac$var$k
                    }), r.removeAttribute(t);
                } else t.startsWith($f58f44579a4747ac$var$h) && (d.push({
                    type: 6,
                    index: c
                }), r.removeAttribute(t));
                if ($f58f44579a4747ac$var$$.test(r.tagName)) {
                    const t = r.textContent.split($f58f44579a4747ac$var$h), s = t.length - 1;
                    if (s > 0) {
                        r.textContent = $f58f44579a4747ac$var$i ? $f58f44579a4747ac$var$i.emptyScript : "";
                        for(let i = 0; i < s; i++)r.append(t[i], $f58f44579a4747ac$var$l()), $f58f44579a4747ac$var$C.nextNode(), d.push({
                            type: 2,
                            index: ++c
                        });
                        r.append(t[s], $f58f44579a4747ac$var$l());
                    }
                }
            } else if (8 === r.nodeType) {
                if (r.data === $f58f44579a4747ac$var$o) d.push({
                    type: 2,
                    index: c
                });
                else {
                    let t = -1;
                    for(; -1 !== (t = r.data.indexOf($f58f44579a4747ac$var$h, t + 1));)d.push({
                        type: 7,
                        index: c
                    }), t += $f58f44579a4747ac$var$h.length - 1;
                }
            }
            c++;
        }
    }
    static createElement(t, i) {
        const s = $f58f44579a4747ac$var$r.createElement("template");
        return s.innerHTML = t, s;
    }
}
function $f58f44579a4747ac$var$S(t, i, s = t, e) {
    if (i === $f58f44579a4747ac$export$9c068ae9cc5db4e8) return i;
    let h = void 0 !== e ? s._$Co?.[e] : s._$Cl;
    const o = $f58f44579a4747ac$var$c(i) ? void 0 : i._$litDirective$;
    return h?.constructor !== o && (h?._$AO?.(!1), void 0 === o ? h = void 0 : (h = new o(t), h._$AT(t, s, e)), void 0 !== e ? (s._$Co ??= [])[e] = h : s._$Cl = h), void 0 !== h && (i = $f58f44579a4747ac$var$S(t, h._$AS(t, i.values), h, e)), i;
}
class $f58f44579a4747ac$var$M {
    constructor(t, i){
        this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = i;
    }
    get parentNode() {
        return this._$AM.parentNode;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    u(t) {
        const { el: { content: i }, parts: s } = this._$AD, e = (t?.creationScope ?? $f58f44579a4747ac$var$r).importNode(i, !0);
        $f58f44579a4747ac$var$C.currentNode = e;
        let h = $f58f44579a4747ac$var$C.nextNode(), o = 0, n = 0, l = s[0];
        for(; void 0 !== l;){
            if (o === l.index) {
                let i;
                2 === l.type ? i = new $f58f44579a4747ac$var$R(h, h.nextSibling, this, t) : 1 === l.type ? i = new l.ctor(h, l.name, l.strings, this, t) : 6 === l.type && (i = new $f58f44579a4747ac$var$z(h, this, t)), this._$AV.push(i), l = s[++n];
            }
            o !== l?.index && (h = $f58f44579a4747ac$var$C.nextNode(), o++);
        }
        return $f58f44579a4747ac$var$C.currentNode = $f58f44579a4747ac$var$r, e;
    }
    p(t) {
        let i = 0;
        for (const s of this._$AV)void 0 !== s && (void 0 !== s.strings ? (s._$AI(t, s, i), i += s.strings.length - 2) : s._$AI(t[i])), i++;
    }
}
class $f58f44579a4747ac$var$R {
    get _$AU() {
        return this._$AM?._$AU ?? this._$Cv;
    }
    constructor(t, i, s, e){
        this.type = 2, this._$AH = $f58f44579a4747ac$export$45b790e32b2810ee, this._$AN = void 0, this._$AA = t, this._$AB = i, this._$AM = s, this.options = e, this._$Cv = e?.isConnected ?? !0;
    }
    get parentNode() {
        let t = this._$AA.parentNode;
        const i = this._$AM;
        return void 0 !== i && 11 === t?.nodeType && (t = i.parentNode), t;
    }
    get startNode() {
        return this._$AA;
    }
    get endNode() {
        return this._$AB;
    }
    _$AI(t, i = this) {
        t = $f58f44579a4747ac$var$S(this, t, i), $f58f44579a4747ac$var$c(t) ? t === $f58f44579a4747ac$export$45b790e32b2810ee || null == t || "" === t ? (this._$AH !== $f58f44579a4747ac$export$45b790e32b2810ee && this._$AR(), this._$AH = $f58f44579a4747ac$export$45b790e32b2810ee) : t !== this._$AH && t !== $f58f44579a4747ac$export$9c068ae9cc5db4e8 && this._(t) : void 0 !== t._$litType$ ? this.$(t) : void 0 !== t.nodeType ? this.T(t) : $f58f44579a4747ac$var$u(t) ? this.k(t) : this._(t);
    }
    O(t) {
        return this._$AA.parentNode.insertBefore(t, this._$AB);
    }
    T(t) {
        this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
    }
    _(t) {
        this._$AH !== $f58f44579a4747ac$export$45b790e32b2810ee && $f58f44579a4747ac$var$c(this._$AH) ? this._$AA.nextSibling.data = t : this.T($f58f44579a4747ac$var$r.createTextNode(t)), this._$AH = t;
    }
    $(t) {
        const { values: i, _$litType$: s } = t, e = "number" == typeof s ? this._$AC(t) : (void 0 === s.el && (s.el = $f58f44579a4747ac$var$N.createElement($f58f44579a4747ac$var$P(s.h, s.h[0]), this.options)), s);
        if (this._$AH?._$AD === e) this._$AH.p(i);
        else {
            const t = new $f58f44579a4747ac$var$M(e, this), s = t.u(this.options);
            t.p(i), this.T(s), this._$AH = t;
        }
    }
    _$AC(t) {
        let i = $f58f44579a4747ac$var$A.get(t.strings);
        return void 0 === i && $f58f44579a4747ac$var$A.set(t.strings, i = new $f58f44579a4747ac$var$N(t)), i;
    }
    k(t) {
        $f58f44579a4747ac$var$a(this._$AH) || (this._$AH = [], this._$AR());
        const i = this._$AH;
        let s, e = 0;
        for (const h of t)e === i.length ? i.push(s = new $f58f44579a4747ac$var$R(this.O($f58f44579a4747ac$var$l()), this.O($f58f44579a4747ac$var$l()), this, this.options)) : s = i[e], s._$AI(h), e++;
        e < i.length && (this._$AR(s && s._$AB.nextSibling, e), i.length = e);
    }
    _$AR(t = this._$AA.nextSibling, i) {
        for(this._$AP?.(!1, !0, i); t !== this._$AB;){
            const i = t.nextSibling;
            t.remove(), t = i;
        }
    }
    setConnected(t) {
        void 0 === this._$AM && (this._$Cv = t, this._$AP?.(t));
    }
}
class $f58f44579a4747ac$var$k {
    get tagName() {
        return this.element.tagName;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    constructor(t, i, s, e, h){
        this.type = 1, this._$AH = $f58f44579a4747ac$export$45b790e32b2810ee, this._$AN = void 0, this.element = t, this.name = i, this._$AM = e, this.options = h, s.length > 2 || "" !== s[0] || "" !== s[1] ? (this._$AH = Array(s.length - 1).fill(new String), this.strings = s) : this._$AH = $f58f44579a4747ac$export$45b790e32b2810ee;
    }
    _$AI(t, i = this, s, e) {
        const h = this.strings;
        let o = !1;
        if (void 0 === h) t = $f58f44579a4747ac$var$S(this, t, i, 0), o = !$f58f44579a4747ac$var$c(t) || t !== this._$AH && t !== $f58f44579a4747ac$export$9c068ae9cc5db4e8, o && (this._$AH = t);
        else {
            const e = t;
            let n, r;
            for(t = h[0], n = 0; n < h.length - 1; n++)r = $f58f44579a4747ac$var$S(this, e[s + n], i, n), r === $f58f44579a4747ac$export$9c068ae9cc5db4e8 && (r = this._$AH[n]), o ||= !$f58f44579a4747ac$var$c(r) || r !== this._$AH[n], r === $f58f44579a4747ac$export$45b790e32b2810ee ? t = $f58f44579a4747ac$export$45b790e32b2810ee : t !== $f58f44579a4747ac$export$45b790e32b2810ee && (t += (r ?? "") + h[n + 1]), this._$AH[n] = r;
        }
        o && !e && this.j(t);
    }
    j(t) {
        t === $f58f44579a4747ac$export$45b790e32b2810ee ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
    }
}
class $f58f44579a4747ac$var$H extends $f58f44579a4747ac$var$k {
    constructor(){
        super(...arguments), this.type = 3;
    }
    j(t) {
        this.element[this.name] = t === $f58f44579a4747ac$export$45b790e32b2810ee ? void 0 : t;
    }
}
class $f58f44579a4747ac$var$I extends $f58f44579a4747ac$var$k {
    constructor(){
        super(...arguments), this.type = 4;
    }
    j(t) {
        this.element.toggleAttribute(this.name, !!t && t !== $f58f44579a4747ac$export$45b790e32b2810ee);
    }
}
class $f58f44579a4747ac$var$L extends $f58f44579a4747ac$var$k {
    constructor(t, i, s, e, h){
        super(t, i, s, e, h), this.type = 5;
    }
    _$AI(t, i = this) {
        if ((t = $f58f44579a4747ac$var$S(this, t, i, 0) ?? $f58f44579a4747ac$export$45b790e32b2810ee) === $f58f44579a4747ac$export$9c068ae9cc5db4e8) return;
        const s = this._$AH, e = t === $f58f44579a4747ac$export$45b790e32b2810ee && s !== $f58f44579a4747ac$export$45b790e32b2810ee || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, h = t !== $f58f44579a4747ac$export$45b790e32b2810ee && (s === $f58f44579a4747ac$export$45b790e32b2810ee || e);
        e && this.element.removeEventListener(this.name, this, s), h && this.element.addEventListener(this.name, this, t), this._$AH = t;
    }
    handleEvent(t) {
        "function" == typeof this._$AH ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
    }
}
class $f58f44579a4747ac$var$z {
    constructor(t, i, s){
        this.element = t, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = s;
    }
    get _$AU() {
        return this._$AM._$AU;
    }
    _$AI(t) {
        $f58f44579a4747ac$var$S(this, t);
    }
}
const $f58f44579a4747ac$export$8613d1ca9052b22e = {
    M: $f58f44579a4747ac$var$e,
    P: $f58f44579a4747ac$var$h,
    A: $f58f44579a4747ac$var$o,
    C: 1,
    L: $f58f44579a4747ac$var$V,
    R: $f58f44579a4747ac$var$M,
    D: $f58f44579a4747ac$var$u,
    V: $f58f44579a4747ac$var$S,
    I: $f58f44579a4747ac$var$R,
    H: $f58f44579a4747ac$var$k,
    N: $f58f44579a4747ac$var$I,
    U: $f58f44579a4747ac$var$L,
    B: $f58f44579a4747ac$var$H,
    F: $f58f44579a4747ac$var$z
}, $f58f44579a4747ac$var$j = $f58f44579a4747ac$var$t.litHtmlPolyfillSupport;
$f58f44579a4747ac$var$j?.($f58f44579a4747ac$var$N, $f58f44579a4747ac$var$R), ($f58f44579a4747ac$var$t.litHtmlVersions ??= []).push("3.3.1");
const $f58f44579a4747ac$export$b3890eb0ae9dca99 = (t, i, s)=>{
    const e = s?.renderBefore ?? i;
    let h = e._$litPart$;
    if (void 0 === h) {
        const t = s?.renderBefore ?? null;
        e._$litPart$ = h = new $f58f44579a4747ac$var$R(i.insertBefore($f58f44579a4747ac$var$l(), t), t, void 0, s ?? {});
    }
    return h._$AI(t), h;
};




/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $ab210b2da7b39b9d$var$s = globalThis;
class $ab210b2da7b39b9d$export$3f2f9f5909897157 extends (0, $19fe8e3abedf4df0$export$c7c07a37856565d) {
    constructor(){
        super(...arguments), this.renderOptions = {
            host: this
        }, this._$Do = void 0;
    }
    createRenderRoot() {
        const t = super.createRenderRoot();
        return this.renderOptions.renderBefore ??= t.firstChild, t;
    }
    update(t) {
        const r = this.render();
        this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = (0, $f58f44579a4747ac$export$b3890eb0ae9dca99)(r, this.renderRoot, this.renderOptions);
    }
    connectedCallback() {
        super.connectedCallback(), this._$Do?.setConnected(!0);
    }
    disconnectedCallback() {
        super.disconnectedCallback(), this._$Do?.setConnected(!1);
    }
    render() {
        return 0, $f58f44579a4747ac$export$9c068ae9cc5db4e8;
    }
}
$ab210b2da7b39b9d$export$3f2f9f5909897157._$litElement$ = !0, $ab210b2da7b39b9d$export$3f2f9f5909897157["finalized"] = !0, $ab210b2da7b39b9d$var$s.litElementHydrateSupport?.({
    LitElement: $ab210b2da7b39b9d$export$3f2f9f5909897157
});
const $ab210b2da7b39b9d$var$o = $ab210b2da7b39b9d$var$s.litElementPolyfillSupport;
$ab210b2da7b39b9d$var$o?.({
    LitElement: $ab210b2da7b39b9d$export$3f2f9f5909897157
});
const $ab210b2da7b39b9d$export$f5c524615a7708d6 = {
    _$AK: (t, e, r)=>{
        t._$AK(e, r);
    },
    _$AL: (t)=>t._$AL
};
($ab210b2da7b39b9d$var$s.litElementVersions ??= []).push("4.2.1");


/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $a00bca1a101a9088$export$6acf61af03e62db = !1;





/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $107bb7d062dde330$export$9ba3b3f20a85bfa = {
    ATTRIBUTE: 1,
    CHILD: 2,
    PROPERTY: 3,
    BOOLEAN_ATTRIBUTE: 4,
    EVENT: 5,
    ELEMENT: 6
}, $107bb7d062dde330$export$99b43ad1ed32e735 = (t)=>(...e)=>({
            _$litDirective$: t,
            values: e
        });
class $107bb7d062dde330$export$befdefbdce210f91 {
    constructor(t){}
    get _$AU() {
        return this._$AM._$AU;
    }
    _$AT(t, e, i) {
        this._$Ct = t, this._$AM = e, this._$Ci = i;
    }
    _$AS(t, e) {
        return this.update(t, e);
    }
    update(t, e) {
        return this.render(...e);
    }
}


/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $19f464fcda7d2482$var$n = "important", $19f464fcda7d2482$var$i = " !" + $19f464fcda7d2482$var$n, $19f464fcda7d2482$export$1e5b4ce2fa884e6a = (0, $107bb7d062dde330$export$99b43ad1ed32e735)(class extends (0, $107bb7d062dde330$export$befdefbdce210f91) {
    constructor(t){
        if (super(t), t.type !== (0, $107bb7d062dde330$export$9ba3b3f20a85bfa).ATTRIBUTE || "style" !== t.name || t.strings?.length > 2) throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.");
    }
    render(t) {
        return Object.keys(t).reduce((e, r)=>{
            const s = t[r];
            return null == s ? e : e + `${r = r.includes("-") ? r : r.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g, "-$&").toLowerCase()}:${s};`;
        }, "");
    }
    update(e, [r]) {
        const { style: s } = e.element;
        if (void 0 === this.ft) return this.ft = new Set(Object.keys(r)), this.render(r);
        for (const t of this.ft)null == r[t] && (this.ft.delete(t), t.includes("-") ? s.removeProperty(t) : s[t] = null);
        for(const t in r){
            const e = r[t];
            if (null != e) {
                this.ft.add(t);
                const r = "string" == typeof e && e.endsWith($19f464fcda7d2482$var$i);
                t.includes("-") || r ? s.setProperty(t, r ? e.slice(0, -11) : e, r ? $19f464fcda7d2482$var$n : "") : s[t] = e;
            }
        }
        return 0, $f58f44579a4747ac$export$9c068ae9cc5db4e8;
    }
});




const $81267a1185dd4399$export$57bf213be019eeb0 = (config, section)=>!config.exclude_sections?.includes(section);


var $d8229c453ce2530e$exports = {};
"use strict";
Object.defineProperty($d8229c453ce2530e$exports, "__esModule", {
    value: true
});
$d8229c453ce2530e$exports.fireEvent = void 0;
var $5c300232e2fb99f1$exports = {};
"use strict";
Object.defineProperty($5c300232e2fb99f1$exports, "__esModule", {
    value: true
});


/**
 * Dispatches a custom event with an optional detail value.
 *
 * @param {string} type Name of event type.
 * @param {*=} detail Detail value containing event-specific
 *   payload.
 * @param {{ bubbles: (boolean|undefined),
 *           cancelable: (boolean|undefined),
 *           composed: (boolean|undefined) }=}
 *  options Object specifying options.  These may include:
 *  `bubbles` (boolean, defaults to `true`),
 *  `cancelable` (boolean, defaults to false), and
 *  `node` on which to fire the event (HTMLElement, defaults to `this`).
 * @return {Event} The new event that was fired.
 */ const $d8229c453ce2530e$var$fireEvent = (node, type, detail, options)=>{
    options = options || {};
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment -- upstream HA
    // @ts-ignore
    detail = detail === null || detail === undefined ? {} : detail;
    const event = new Event(type, {
        bubbles: options.bubbles === undefined ? true : options.bubbles,
        cancelable: Boolean(options.cancelable),
        composed: options.composed === undefined ? true : options.composed
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- upstream HA Event detail
    event.detail = detail;
    node.dispatchEvent(event);
    return event;
};
$d8229c453ce2530e$exports.fireEvent = $d8229c453ce2530e$var$fireEvent;


var $505f309a99680a49$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/panels/lovelace/common/directives/action-handler-directive.ts
 */ Object.defineProperty($505f309a99680a49$exports, "__esModule", {
    value: true
});
$505f309a99680a49$exports.actionHandler = $505f309a99680a49$exports.actionHandlerBind = void 0;




const $505f309a99680a49$var$getActionHandler = ()=>{
    const body = document.body;
    if (body.querySelector('action-handler')) return body.querySelector('action-handler');
    const actionhandler = document.createElement('action-handler');
    body.appendChild(actionhandler);
    return actionhandler;
};
const $505f309a99680a49$var$actionHandlerBind = (element, options)=>{
    const actionhandler = $505f309a99680a49$var$getActionHandler();
    if (!actionhandler) return;
    actionhandler.bind(element, options);
};
$505f309a99680a49$exports.actionHandlerBind = $505f309a99680a49$var$actionHandlerBind;
$505f309a99680a49$exports.actionHandler = (0, $107bb7d062dde330$export$99b43ad1ed32e735)(class extends $107bb7d062dde330$export$befdefbdce210f91 {
    update(part, [options]) {
        (0, $505f309a99680a49$exports.actionHandlerBind)(part.element, options);
        return $f58f44579a4747ac$export$9c068ae9cc5db4e8;
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    render(_options) {}
});


const $57febad8376708f1$export$8a44987212de21b = (config)=>{
    const isActionEnabled = (actionConfig)=>actionConfig?.action !== 'none' && actionConfig?.action !== undefined;
    return (0, $505f309a99680a49$exports.actionHandler)({
        hasDoubleClick: isActionEnabled(config?.double_tap_action),
        hasHold: isActionEnabled(config?.hold_action)
    });
};
const $57febad8376708f1$export$3d3654ce4577c53d = (element, sectionConfig, entity)=>{
    return {
        /**
     * Handles an action event by creating and dispatching a 'hass-action' custom event.
     * The event contains the entity configuration and the action type (tap, double_tap, hold).
     *
     * @param {ActionHandlerEvent} ev - The action handler event to process
     */ handleEvent: (ev)=>{
            // Extract action from event detail
            const action = ev.detail?.action;
            if (!action) return;
            // Create configuration object for the action
            const config = {
                entity: entity.entity_id,
                ...sectionConfig || {}
            };
            (0, $d8229c453ce2530e$exports.fireEvent)(element, 'hass-action', {
                config: config,
                action: action
            });
        }
    };
};
const $57febad8376708f1$export$5dd91bc989d0761d = (element, actionConfigs)=>{
    return {
        /**
     * Handles an action event by creating and dispatching a 'hass-action' custom event.
     * The event contains the entity configuration and the action type (tap, double_tap, hold).
     *
     * @param {ActionHandlerEvent} ev - The action handler event to process
     */ handleEvent: (ev)=>{
            // Extract action from event detail
            const action = ev.detail?.action;
            if (!action) return;
            // Process each action configuration
            actionConfigs.forEach((config)=>{
                (0, $d8229c453ce2530e$exports.fireEvent)(element, 'hass-action', {
                    config: config,
                    action: action
                });
            });
        }
    };
};


var $46dabcff6df1e992$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/common/entity/state_active.ts
 */ Object.defineProperty($46dabcff6df1e992$exports, "__esModule", {
    value: true
});
$46dabcff6df1e992$exports.stateActive = $46dabcff6df1e992$var$stateActive;
var $d25e6b86739c3dd6$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/data/entity/entity.ts
 */ Object.defineProperty($d25e6b86739c3dd6$exports, "__esModule", {
    value: true
});
$d25e6b86739c3dd6$exports.isOffState = $d25e6b86739c3dd6$exports.isUnavailableState = $d25e6b86739c3dd6$exports.OFF_STATES = $d25e6b86739c3dd6$exports.UNAVAILABLE_STATES = $d25e6b86739c3dd6$exports.OFF = $d25e6b86739c3dd6$exports.ON = $d25e6b86739c3dd6$exports.UNKNOWN = $d25e6b86739c3dd6$exports.UNAVAILABLE = void 0;
var $f4456c331bb6c271$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/common/array/literal-includes.ts
 */ Object.defineProperty($f4456c331bb6c271$exports, "__esModule", {
    value: true
});
$f4456c331bb6c271$exports.arrayLiteralIncludes = void 0;
/**
 * Creates a type predicate function for determining if an array literal includes a given value
 * @param array - The array to check
 * @returns A type predicate function
 */ const $f4456c331bb6c271$var$arrayLiteralIncludes = (array)=>(searchElement, fromIndex)=>array.includes(searchElement, fromIndex);
$f4456c331bb6c271$exports.arrayLiteralIncludes = $f4456c331bb6c271$var$arrayLiteralIncludes;


$d25e6b86739c3dd6$exports.UNAVAILABLE = 'unavailable';
$d25e6b86739c3dd6$exports.UNKNOWN = 'unknown';
$d25e6b86739c3dd6$exports.ON = 'on';
$d25e6b86739c3dd6$exports.OFF = 'off';
$d25e6b86739c3dd6$exports.UNAVAILABLE_STATES = [
    $d25e6b86739c3dd6$exports.UNAVAILABLE,
    $d25e6b86739c3dd6$exports.UNKNOWN
];
$d25e6b86739c3dd6$exports.OFF_STATES = [
    $d25e6b86739c3dd6$exports.UNAVAILABLE,
    $d25e6b86739c3dd6$exports.UNKNOWN,
    $d25e6b86739c3dd6$exports.OFF
];
$d25e6b86739c3dd6$exports.isUnavailableState = (0, $f4456c331bb6c271$exports.arrayLiteralIncludes)($d25e6b86739c3dd6$exports.UNAVAILABLE_STATES);
$d25e6b86739c3dd6$exports.isOffState = (0, $f4456c331bb6c271$exports.arrayLiteralIncludes)($d25e6b86739c3dd6$exports.OFF_STATES);


var $9be1c046bd0bdc20$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/common/entity/compute_domain.ts
 */ Object.defineProperty($9be1c046bd0bdc20$exports, "__esModule", {
    value: true
});
$9be1c046bd0bdc20$exports.computeDomain = void 0;
const $9be1c046bd0bdc20$var$computeDomain = (entityId)=>entityId.substring(0, entityId.indexOf('.'));
$9be1c046bd0bdc20$exports.computeDomain = $9be1c046bd0bdc20$var$computeDomain;


function $46dabcff6df1e992$var$stateActive(stateObj, state) {
    const domain = (0, $9be1c046bd0bdc20$exports.computeDomain)(stateObj.entity_id);
    const compareState = state ?? stateObj?.state;
    if ([
        'button',
        'event',
        'infrared',
        'input_button',
        'radio_frequency',
        'scene'
    ].includes(domain)) return compareState !== $d25e6b86739c3dd6$exports.UNAVAILABLE;
    if (compareState === $d25e6b86739c3dd6$exports.UNAVAILABLE || compareState === $d25e6b86739c3dd6$exports.UNKNOWN) return false;
    // The "off" check is relevant for most domains, but there are exceptions
    // such as "alert" where "off" is still a somewhat active state and
    // therefore gets a custom color and "idle" is instead the state that
    // matches what most other domains consider inactive.
    if (compareState === $d25e6b86739c3dd6$exports.OFF && domain !== 'alert') return false;
    // Custom cases
    switch(domain){
        case 'alarm_control_panel':
            return compareState !== 'disarmed';
        case 'alert':
            // "on" and "off" are active, as "off" just means alert was acknowledged but is still active
            return compareState !== 'idle';
        case 'cover':
            return compareState !== 'closed';
        case 'device_tracker':
        case 'person':
            return compareState !== 'not_home';
        case 'lawn_mower':
            return ![
                'docked',
                'paused'
            ].includes(compareState);
        case 'lock':
            return compareState !== 'locked';
        case 'media_player':
            // Upstream treats paused as active; cards treat paused like standby (inactive).
            return ![
                'standby',
                'paused'
            ].includes(compareState);
        case 'vacuum':
            return ![
                'idle',
                'docked',
                'paused'
            ].includes(compareState);
        case 'valve':
            return compareState !== 'closed';
        case 'plant':
            return compareState === 'problem';
        case 'group':
            return [
                'on',
                'home',
                'open',
                'locked',
                'problem'
            ].includes(compareState);
        case 'timer':
            return compareState === 'active';
        case 'camera':
            return compareState === 'streaming';
    }
    return true;
}


var $116f7515b52a2ba4$exports = {};
$116f7515b52a2ba4$exports = JSON.parse('{"card":{"stats":{"total_queries":"DNS \u0437\u0430\u044F\u0432\u043A\u0438","safe_searches":"{number} safe searches","queries_blocked":"\u0411\u043B\u043E\u043A\u0438\u0440\u0430\u043D\u0438 \u043E\u0442 \u0444\u0438\u043B\u0442\u0440\u0438","list_blocked_queries":"\u0421\u043F\u0438\u0441\u044A\u043A \u0441 \u0431\u043B\u043E\u043A\u0438\u0440\u0430\u043D\u0438 \u0437\u0430\u044F\u0432\u043A\u0438","percentage_blocked":"\u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u0431\u043B\u043E\u043A\u0438\u0440\u0430\u043D\u0438","list_all_queries":"\u0421\u043F\u0438\u0441\u044A\u043A \u0441 \u0432\u0441\u0438\u0447\u043A\u0438 \u0437\u0430\u044F\u0432\u043A\u0438","average_processing_speed":"\u0421\u043A\u043E\u0440\u043E\u0441\u0442 \u043D\u0430 \u041E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430","processing_speed_info":"\u0412\u0440\u0435\u043C\u0435 \u0437\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0430"},"sections":{"switches":"\u041A\u043B\u044E\u0447\u043E\u0432\u0435"},"units":{"seconds":"\u0441\u0435\u043A\u0443\u043D\u0434\u0438","second":"\u0441\u0435\u043A\u0443\u043D\u0434\u0430","minutes":"\u043C\u0438\u043D\u0443\u0442\u0438","minute":"\u043C\u0438\u043D\u0443\u0442\u0430","hours":"\u0447\u0430\u0441\u043E\u0432\u0435","hour":"\u0447\u0430\u0441"},"ui":{"partial":"\u0427\u0430\u0441\u0442\u0438\u0447\u0435\u043D"}},"editor":{"space_around":"\u041F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u043E\u043A\u043E\u043B\u043E","space_between":"\u041F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u043C\u0435\u0436\u0434\u0443","header":"\u0413\u043E\u0440\u043D\u0430 \u0447\u0430\u0441\u0442","footer":"\u0414\u043E\u043B\u043D\u0430 \u0447\u0430\u0441\u0442","statistics":"\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0430","sensors":"\u0421\u0435\u043D\u0437\u043E\u0440\u0438","switches":"\u041A\u043B\u044E\u0447\u043E\u0432\u0435","tap_action":"\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u0440\u0438 \u043D\u0430\u0442\u0438\u0441\u043A\u0430\u043D\u0435","hold_action":"\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u0440\u0438 \u0437\u0430\u0434\u044A\u0440\u0436\u0430\u043D\u0435","double_tap_action":"\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u0440\u0438 \u0434\u0432\u043E\u0439\u043D\u043E \u043D\u0430\u0442\u0438\u0441\u043A\u0430\u043D\u0435","content":"\u0421\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435","card_title":"\u0417\u0430\u0433\u043B\u0430\u0432\u0438\u0435 \u043D\u0430 \u043A\u0430\u0440\u0442\u0430\u0442\u0430","card_icon":"\u0418\u043A\u043E\u043D\u0430 \u043D\u0430 \u043A\u0430\u0440\u0442\u0430\u0442\u0430","layout":"\u041F\u043E\u0434\u0440\u0435\u0434\u0431\u0430","sections_to_exclude":"\u0421\u0435\u043A\u0446\u0438\u0438 \u0437\u0430 \u0438\u0437\u043A\u043B\u044E\u0447\u0432\u0430\u043D\u0435","sections_collapsed_by_default":"\u0421\u0432\u0438\u0442\u0438 \u0441\u0435\u043A\u0446\u0438\u0438 \u043F\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0431\u0438\u0440\u0430\u043D\u0435","style_for_switches":"\u0421\u0442\u0438\u043B \u043D\u0430 \u043A\u043B\u044E\u0447\u043E\u0432\u0435","entities_to_exclude":"\u041E\u0431\u0435\u043A\u0442\u0438 \u0437\u0430 \u0438\u0437\u043A\u043B\u044E\u0447\u0432\u0430\u043D\u0435","styles":{"label":"\u0421\u0442\u0438\u043B\u043E\u0432\u0435","css_styles":"\u0412\u0430\u0448\u0438\u0442\u0435 CSS \u0441\u0442\u0438\u043B\u043E\u0432\u0435","card_styles":"\u0421\u0442\u0438\u043B\u043E\u0432\u0435 \u043D\u0430 \u043A\u0430\u0440\u0442\u0430\u0442\u0430","section_styles":"\u0421\u0442\u0438\u043B\u043E\u0432\u0435 \u043D\u0430 \u0441\u0435\u043A\u0446\u0438\u044F\u0442\u0430"},"switch_spacing":"\u0420\u0430\u0437\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u043C\u0435\u0436\u0434\u0443 \u043A\u043B\u044E\u0447\u043E\u0432\u0435\u0442\u0435","interactions":"\u0412\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F","badge":"\u0417\u043D\u0430\u0447\u043A\u0430","status":"\u0421\u0442\u0430\u0442\u0443\u0441","information":"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F","adguard_device":"AdGuard \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E","entity_display_order":"\u0420\u0435\u0434 \u043D\u0430 \u043F\u043E\u043A\u0430\u0437\u0432\u0430\u043D\u0435 \u043D\u0430 \u043E\u0431\u0435\u043A\u0442\u0438\u0442\u0435 (\u043A\u043B\u0438\u043A\u0432\u0430\u043D\u0435 \u0432 \u0440\u0435\u0434)","flex_default":"Flex (\u043F\u043E \u043F\u043E\u0434\u0440\u0430\u0437\u0431\u0438\u0440\u0430\u043D\u0435)"}}');


var $311afcb0e9c10c81$exports = {};
$311afcb0e9c10c81$exports = JSON.parse('{"card":{"stats":{"total_queries":"DNS-Anfragen","safe_searches":"{number} safe searches","queries_blocked":"Von Filtern blockiert","list_blocked_queries":"Blockierte Anfragen anzeigen","percentage_blocked":"Prozentual blockiert","list_all_queries":"Alle Anfragen anzeigen","average_processing_speed":"Verarbeitungsgeschwindigkeit","processing_speed_info":"Verarbeitungszeit"},"sections":{"switches":"Schalter"},"units":{"seconds":"Sekunden","second":"Sekunde","minutes":"Minuten","minute":"Minute","hours":"Stunden","hour":"Stunde"},"ui":{"partial":"Teilweise"}},"editor":{"space_around":"Platz umher","space_between":"Platz dazwischen","header":"Kopfzeile","footer":"Fu\xdfzeile","statistics":"Statistiken","sensors":"Sensoren","switches":"Schalter","tap_action":"Tipp-Aktion","hold_action":"Halte-Aktion","double_tap_action":"Doppel-Tipp-Aktion","content":"Inhalt","card_title":"Karten-Titel","card_icon":"Karten-Symbol","layout":"Layout","sections_to_exclude":"Auszuschlie\xdfende Abschnitte","sections_collapsed_by_default":"Standardm\xe4\xdfig eingeklappte Abschnitte","style_for_switches":"Stil f\xfcr Schalter","entities_to_exclude":"Auszuschlie\xdfende Entit\xe4ten","styles":{"label":"Stile","css_styles":"Ihre CSS-Stile","card_styles":"Karten-Stile","section_styles":"Abschnitts-Stile"},"switch_spacing":"Schalter-Abstand","interactions":"Interaktionen","badge":"Abzeichen","status":"Status","information":"Informationen","adguard_device":"AdGuard Ger\xe4t","entity_display_order":"Entit\xe4ts-Anzeigereihenfolge (in Reihenfolge klicken)","flex_default":"Flex (Standard)"}}');


var $71f67b2c94b2fafe$exports = {};
$71f67b2c94b2fafe$exports = JSON.parse('{"card":{"stats":{"total_queries":"DNS \u03B5\u03C1\u03C9\u03C4\u03AE\u03BC\u03B1\u03C4\u03B1","safe_searches":"{number} safe searches","queries_blocked":"\u0391\u03C0\u03BF\u03BA\u03BB\u03B5\u03B9\u03C3\u03BC\u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC \u03C6\u03AF\u03BB\u03C4\u03C1\u03B1","list_blocked_queries":"\u039B\u03AF\u03C3\u03C4\u03B1 \u03B1\u03C0\u03BF\u03BA\u03BB\u03B5\u03B9\u03C3\u03BC\u03AD\u03BD\u03C9\u03BD \u03B5\u03C1\u03C9\u03C4\u03B7\u03BC\u03AC\u03C4\u03C9\u03BD","percentage_blocked":"\u03A0\u03BF\u03C3\u03BF\u03C3\u03C4\u03CC \u03C0\u03BF\u03C5 \u03B1\u03C0\u03BF\u03BA\u03BB\u03B5\u03AF\u03C3\u03C4\u03B7\u03BA\u03B5","list_all_queries":"\u039B\u03AF\u03C3\u03C4\u03B1 \u03CC\u03BB\u03C9\u03BD \u03C4\u03C9\u03BD \u03B5\u03C1\u03C9\u03C4\u03B7\u03BC\u03AC\u03C4\u03C9\u03BD","average_processing_speed":"\u03A4\u03B1\u03C7\u03CD\u03C4\u03B7\u03C4\u03B1 \u0395\u03C0\u03B5\u03BE\u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1\u03C2","processing_speed_info":"\u03A7\u03C1\u03CC\u03BD\u03BF\u03C2 \u03B5\u03C0\u03B5\u03BE\u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1\u03C2"},"sections":{"switches":"\u0394\u03B9\u03B1\u03BA\u03CC\u03C0\u03C4\u03B5\u03C2"},"units":{"seconds":"\u03B4\u03B5\u03C5\u03C4\u03B5\u03C1\u03CC\u03BB\u03B5\u03C0\u03C4\u03B1","second":"\u03B4\u03B5\u03C5\u03C4\u03B5\u03C1\u03CC\u03BB\u03B5\u03C0\u03C4\u03BF","minutes":"\u03BB\u03B5\u03C0\u03C4\u03AC","minute":"\u03BB\u03B5\u03C0\u03C4\u03CC","hours":"\u03CE\u03C1\u03B5\u03C2","hour":"\u03CE\u03C1\u03B1"},"ui":{"partial":"\u039C\u03B5\u03C1\u03B9\u03BA\u03CC"}},"editor":{"space_around":"\u03A7\u03CE\u03C1\u03BF\u03C2 \u0393\u03CD\u03C1\u03C9","space_between":"\u03A7\u03CE\u03C1\u03BF\u03C2 \u0391\u03BD\u03AC\u03BC\u03B5\u03C3\u03B1","header":"\u039A\u03B5\u03C6\u03B1\u03BB\u03AF\u03B4\u03B1","footer":"\u03A5\u03C0\u03BF\u03C3\u03AD\u03BB\u03B9\u03B4\u03BF","statistics":"\u03A3\u03C4\u03B1\u03C4\u03B9\u03C3\u03C4\u03B9\u03BA\u03AC","sensors":"\u0391\u03B9\u03C3\u03B8\u03B7\u03C4\u03AE\u03C1\u03B5\u03C2","switches":"\u0394\u03B9\u03B1\u03BA\u03CC\u03C0\u03C4\u03B5\u03C2","tap_action":"\u0395\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 \u0391\u03C6\u03AE\u03C2","hold_action":"\u0395\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 \u039A\u03C1\u03AC\u03C4\u03B7\u03C3\u03B7\u03C2","double_tap_action":"\u0395\u03BD\u03AD\u03C1\u03B3\u03B5\u03B9\u03B1 \u0394\u03B9\u03C0\u03BB\u03AE\u03C2 \u0391\u03C6\u03AE\u03C2","content":"\u03A0\u03B5\u03C1\u03B9\u03B5\u03C7\u03CC\u03BC\u03B5\u03BD\u03BF","card_title":"\u03A4\u03AF\u03C4\u03BB\u03BF\u03C2 \u039A\u03AC\u03C1\u03C4\u03B1\u03C2","card_icon":"\u0395\u03B9\u03BA\u03BF\u03BD\u03AF\u03B4\u03B9\u03BF \u039A\u03AC\u03C1\u03C4\u03B1\u03C2","layout":"\u0394\u03B9\u03AC\u03C4\u03B1\u03BE\u03B7","sections_to_exclude":"\u0395\u03BD\u03CC\u03C4\u03B7\u03C4\u03B5\u03C2 \u03C0\u03C1\u03BF\u03C2 \u03B5\u03BE\u03B1\u03AF\u03C1\u03B5\u03C3\u03B7","sections_collapsed_by_default":"\u0395\u03BD\u03CC\u03C4\u03B7\u03C4\u03B5\u03C2 \u03C0\u03BF\u03C5 \u03C3\u03C5\u03BC\u03C0\u03C4\u03CD\u03C3\u03C3\u03BF\u03BD\u03C4\u03B1\u03B9 \u03B1\u03C0\u03CC \u03C0\u03C1\u03BF\u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE","style_for_switches":"\u03A3\u03C4\u03C5\u03BB \u03B3\u03B9\u03B1 \u03B4\u03B9\u03B1\u03BA\u03CC\u03C0\u03C4\u03B5\u03C2","entities_to_exclude":"\u039F\u03BD\u03C4\u03CC\u03C4\u03B7\u03C4\u03B5\u03C2 \u03C0\u03C1\u03BF\u03C2 \u03B5\u03BE\u03B1\u03AF\u03C1\u03B5\u03C3\u03B7","styles":{"label":"\u03A3\u03C4\u03C5\u03BB","css_styles":"\u03A4\u03B1 CSS \u03A3\u03C4\u03C5\u03BB \u03C3\u03B1\u03C2","card_styles":"\u03A3\u03C4\u03C5\u03BB \u039A\u03AC\u03C1\u03C4\u03B1\u03C2","section_styles":"\u03A3\u03C4\u03C5\u03BB \u0395\u03BD\u03CC\u03C4\u03B7\u03C4\u03B1\u03C2"},"switch_spacing":"\u0394\u03B9\u03AC\u03C3\u03C4\u03B7\u03BC\u03B1 \u0394\u03B9\u03B1\u03BA\u03BF\u03C0\u03C4\u03CE\u03BD","interactions":"\u0391\u03BB\u03BB\u03B7\u03BB\u03B5\u03C0\u03B9\u03B4\u03C1\u03AC\u03C3\u03B5\u03B9\u03C2","badge":"\u03A3\u03AE\u03BC\u03B1","status":"\u039A\u03B1\u03C4\u03AC\u03C3\u03C4\u03B1\u03C3\u03B7","information":"\u03A0\u03BB\u03B7\u03C1\u03BF\u03C6\u03BF\u03C1\u03AF\u03B5\u03C2","adguard_device":"\u03A3\u03C5\u03C3\u03BA\u03B5\u03C5\u03AE AdGuard","entity_display_order":"\u03A3\u03B5\u03B9\u03C1\u03AC \u03B5\u03BC\u03C6\u03AC\u03BD\u03B9\u03C3\u03B7\u03C2 \u03BF\u03BD\u03C4\u03BF\u03C4\u03AE\u03C4\u03C9\u03BD (\u03BA\u03AC\u03BD\u03C4\u03B5 \u03BA\u03BB\u03B9\u03BA \u03BC\u03B5 \u03C3\u03B5\u03B9\u03C1\u03AC)","flex_default":"Flex (\u03C0\u03C1\u03BF\u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE)"}}');


var $9a28a77a5af263d9$exports = {};
$9a28a77a5af263d9$exports = JSON.parse("{\"card\":{\"stats\":{\"total_queries\":\"DNS Queries\",\"safe_searches\":\"{number} safe searches\",\"queries_blocked\":\"Blocked by Filters\",\"list_blocked_queries\":\"List blocked queries\",\"percentage_blocked\":\"Percentage Blocked\",\"list_all_queries\":\"List all queries\",\"average_processing_speed\":\"Processing Speed\",\"processing_speed_info\":\"Processing time\"},\"sections\":{\"switches\":\"Switches\"},\"units\":{\"seconds\":\"seconds\",\"second\":\"second\",\"minutes\":\"minutes\",\"minute\":\"minute\",\"hours\":\"hours\",\"hour\":\"hour\"},\"ui\":{\"partial\":\"Partial\"}},\"editor\":{\"space_around\":\"Space Around\",\"space_between\":\"Space Between\",\"header\":\"Header\",\"footer\":\"Footer\",\"statistics\":\"Statistics\",\"sensors\":\"Sensors\",\"switches\":\"Switches\",\"tap_action\":\"Tap Action\",\"hold_action\":\"Hold Action\",\"double_tap_action\":\"Double Tap Action\",\"content\":\"Content\",\"card_title\":\"Card Title\",\"card_icon\":\"Card Icon\",\"layout\":\"Layout\",\"sections_to_exclude\":\"Sections to exclude\",\"sections_collapsed_by_default\":\"Sections collapsed by default\",\"style_for_switches\":\"Style for switches\",\"entities_to_exclude\":\"Entities to exclude\",\"styles\":{\"label\":\"Styles\",\"css_styles\":\"Your CSS Styles\",\"card_styles\":\"Card Styles\",\"section_styles\":\"Section Styles\"},\"switch_spacing\":\"Switch Spacing\",\"interactions\":\"Interactions\",\"badge\":\"Badge\",\"status\":\"Status\",\"information\":\"Information\",\"adguard_device\":\"AdGuard Device\",\"entity_display_order\":\"Entity display order (click in order)\",\"flex_default\":\"Flex (default)\"}}");


var $ac00f57d502abb29$exports = {};
$ac00f57d502abb29$exports = JSON.parse('{"card":{"stats":{"total_queries":"Consultas DNS","safe_searches":"{number} safe searches","queries_blocked":"Bloqueadas por filtros","list_blocked_queries":"Listar peticiones bloqueadas","percentage_blocked":"Porcentaje bloqueos","list_all_queries":"Listar todas las peticiones","average_processing_speed":"Velocidad de Procesamiento","processing_speed_info":"Tiempo de procesamiento"},"sections":{"switches":"Interruptores"},"units":{"seconds":"segundos","second":"segundo","minutes":"minutos","minute":"minuto","hours":"horas","hour":"hora"},"ui":{"partial":"Parcial"}},"editor":{"space_around":"Espacio Alrededor","space_between":"Espacio Entre","header":"Encabezado","footer":"Pie de P\xe1gina","statistics":"Estad\xedsticas","sensors":"Sensores","switches":"Interruptores","tap_action":"Acci\xf3n de Toque","hold_action":"Acci\xf3n de Mantener","double_tap_action":"Acci\xf3n de Doble Toque","content":"Contenido","card_title":"T\xedtulo de la Tarjeta","card_icon":"Icono de la Tarjeta","layout":"Dise\xf1o","sections_to_exclude":"Secciones a excluir","sections_collapsed_by_default":"Secciones colapsadas por defecto","style_for_switches":"Estilo para interruptores","entities_to_exclude":"Entidades a excluir","styles":{"label":"Estilos","css_styles":"Tus Estilos CSS","card_styles":"Estilos de Tarjeta","section_styles":"Estilos de Secci\xf3n"},"switch_spacing":"Espaciado de Interruptores","interactions":"Interacciones","badge":"Insignia","status":"Estado","information":"Informaci\xf3n","adguard_device":"Dispositivo AdGuard","entity_display_order":"Orden de visualizaci\xf3n de entidades (hacer clic en orden)","flex_default":"Flex (predeterminado)"}}');


var $a8bf67e13c48de4e$exports = {};
$a8bf67e13c48de4e$exports = JSON.parse('{"card":{"stats":{"total_queries":"Requ\xeates DNS","safe_searches":"{number} safe searches","queries_blocked":"Bloqu\xe9es par les filtres","list_blocked_queries":"Liste des requ\xeates bloqu\xe9es","percentage_blocked":"Pourcentage bloqu\xe9","list_all_queries":"Liste de toutes les requ\xeates","average_processing_speed":"Vitesse de Traitement","processing_speed_info":"Temps de traitement"},"sections":{"switches":"Interrupteurs"},"units":{"seconds":"secondes","second":"seconde","minutes":"minutes","minute":"minute","hours":"heures","hour":"heure"},"ui":{"partial":"Partiel"}},"editor":{"space_around":"Espace autour","space_between":"Espace entre","header":"En-t\xeate","footer":"Pied de page","statistics":"Statistiques","sensors":"Capteurs","switches":"Interrupteurs","tap_action":"Action sur un appui court","hold_action":"Action sur un appui long","double_tap_action":"Action sur un double appui","content":"Contenu","card_title":"Titre de la carte","card_icon":"Ic\xf4ne de la carte","layout":"Disposition","sections_to_exclude":"Sections \xe0 exclure","sections_collapsed_by_default":"Sections repli\xe9es par d\xe9faut","style_for_switches":"Style des interrupteurs","entities_to_exclude":"Entit\xe9s \xe0 exclure","styles":{"label":"Styles","css_styles":"Vos Styles CSS","card_styles":"Styles de Carte","section_styles":"Styles de Section"},"switch_spacing":"Espacement des interrupteurs","interactions":"Interactions","badge":"Badge","status":"Statut","information":"Informations","adguard_device":"Appareil AdGuard","entity_display_order":"Ordre d\'affichage des entit\xe9s (cliquer dans l\'ordre)","flex_default":"Flexible (par d\xe9faut)"}}');


var $f112f750c9161502$exports = {};
$f112f750c9161502$exports = JSON.parse('{"card":{"stats":{"total_queries":"Richieste DNS","safe_searches":"{number} safe searches","queries_blocked":"Bloccate dai filtri","list_blocked_queries":"Elenco richieste bloccate","percentage_blocked":"Percentuale bloccate","list_all_queries":"Elenca tutte le richieste","average_processing_speed":"Velocit\xe0 di Elaborazione","processing_speed_info":"Tempo di elaborazione"},"sections":{"switches":"Opzioni"},"units":{"seconds":"secondi","second":"secondo","minutes":"minuti","minute":"minuto","hours":"ore","hour":"ora"},"ui":{"partial":"Parziale"}},"editor":{"space_around":"Spazi prima e dopo","space_between":"Spazi in mezzo","header":"Intestazione","footer":"Pi\xe8 di pagina","statistics":"Statistiche","sensors":"Sensori","switches":"Opzioni","tap_action":"Azione con Tap","hold_action":"Azione con Hold","double_tap_action":"Azione con Doppio Tap","content":"Contenunto","card_title":"Titolo della Card","card_icon":"Icona della Card","layout":"Layout","sections_to_exclude":"Sezioni da escludere","sections_collapsed_by_default":"Sezioni nascoste di default","style_for_switches":"Stile degli switch","entities_to_exclude":"Entit\xe0 da escludere","styles":{"label":"Stili","css_styles":"I Tuoi Stili CSS","card_styles":"Stili Card","section_styles":"Stili Sezione"},"switch_spacing":"Spaziatura Switch","interactions":"Interazioni","badge":"Badge","status":"Stato","information":"Informazioni","adguard_device":"Dispositivo AdGuard","entity_display_order":"Ordine delle Entit\xe0 (cliccare in ordine)","flex_default":"Flex (default)"}}');


// Import other languages as needed above this line and in order
// Define supported languages
const $623ffaa3e77fea87$var$languages = {
    bg: $116f7515b52a2ba4$exports,
    el: $71f67b2c94b2fafe$exports,
    en: $9a28a77a5af263d9$exports,
    es: $ac00f57d502abb29$exports,
    de: $311afcb0e9c10c81$exports,
    it: $f112f750c9161502$exports,
    fr: $a8bf67e13c48de4e$exports
};
const $623ffaa3e77fea87$export$b3bd0bc58e36cd63 = (hass, key, search = '', replace = '')=>{
    let translated;
    translated = $623ffaa3e77fea87$var$getNestedTranslation($623ffaa3e77fea87$var$languages[hass.language], key) ?? $623ffaa3e77fea87$var$getNestedTranslation($623ffaa3e77fea87$var$languages.en, key) ?? key;
    // Replace placeholders
    if (search !== '' && replace !== '') translated = translated.replace(search, replace);
    return translated;
};
// Helper function to safely navigate nested objects
function $623ffaa3e77fea87$var$getNestedTranslation(obj, path) {
    if (!obj) return undefined;
    const keys = path.split('.');
    let result = obj;
    for (const key of keys){
        if (result === undefined || result === null || typeof result !== 'object') return undefined;
        result = result[key];
    }
    return typeof result === 'string' ? result : undefined;
}





const $0cafd9360b3c4d75$export$1ca1ec8b29a4ce27 = (element, config, setup)=>{
    // Create ActionConfigParams for each AdGuard instance
    const actionConfigs = setup.holes.map((h)=>{
        // If user has custom badge config, apply it to all AdGuard instances
        if (config.badge) return {
            entity: h.protection?.entity_id ?? h.device_id,
            ...config.badge
        };
        // Use config.badge if provided, otherwise create custom actions
        const baseConfig = {
            tap_action: {
                action: 'more-info'
            },
            hold_action: {
                action: 'more-info'
            },
            double_tap_action: {
                action: 'more-info'
            }
        };
        // For AdGuard instances, use the base config
        return {
            entity: h.protection?.entity_id ?? h.device_id,
            ...baseConfig
        };
    });
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<div
    class="badge"
    @action=${(0, $57febad8376708f1$export$5dd91bc989d0761d)(element, actionConfigs)}
    .actionHandler=${(0, $57febad8376708f1$export$8a44987212de21b)(actionConfigs[0])}
  >
    <ha-icon icon="${config.icon ?? 'mdi:shield-check'}"></ha-icon>
  </div>`;
};



const $409574f4dbacb1f1$export$c18c768bbe3223b7 = (hass, entity, className = '')=>(0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<state-display
    .hass=${hass}
    .stateObj=${entity}
    class=${className}
  ></state-display>`;


const $a2b1c365027138cb$export$dfb737c0873de058 = (element, setup, hass, config)=>{
    if (!(0, $81267a1185dd4399$export$57bf213be019eeb0)(config, 'header')) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
    const primary = setup.holes[0];
    const activeCount = setup.holes.map((h)=>h.protection).filter((status)=>status !== undefined && (0, $46dabcff6df1e992$exports.stateActive)(status, status.state)).length;
    const mixedStatus = activeCount > 0 && activeCount < setup.holes.length;
    // Get status color based on active count and mixed status
    const getStatusColor = ()=>{
        if (mixedStatus) return 'var(--warning-color, orange)';
        else if (activeCount > 0) return 'var(--success-color, green)';
        else return 'var(--error-color, red)';
    };
    // Create ActionConfigParams for each AdGuard instance
    const actionConfigs = setup.holes.map((h)=>{
        // If user has custom status config, apply it to all AdGuard instances
        if (config.status) return {
            entity: h.protection?.entity_id ?? h.device_id,
            ...config.status
        };
        // Use config.status if provided, otherwise create custom actions
        // Default tap_action is toggle, hold and double_tap default to more-info
        const baseConfig = {
            tap_action: {
                action: 'toggle'
            },
            hold_action: {
                action: 'more-info'
            },
            double_tap_action: {
                action: 'more-info'
            }
        };
        // For AdGuard instances, use the base config
        return {
            entity: h.protection?.entity_id ?? h.device_id,
            ...baseConfig
        };
    });
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div class="card-header">
      <div class="name">
        ${(0, $0cafd9360b3c4d75$export$1ca1ec8b29a4ce27)(element, config, setup)}${config.title ?? 'AdGuard'}
        ${setup.holes.length > 1 ? (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<span class="multi-status"
                >(${activeCount}/${setup.holes.length})</span
              >` : ''}
      </div>
      <div
        style="color: ${getStatusColor()}; cursor: pointer;"
        @action=${(0, $57febad8376708f1$export$5dd91bc989d0761d)(element, actionConfigs)}
        .actionHandler=${(0, $57febad8376708f1$export$8a44987212de21b)(actionConfigs[0])}
      >
        <ha-icon
          icon="${activeCount > 0 ? 'mdi:check-circle' : 'mdi:close-circle'}"
        ></ha-icon>
        ${mixedStatus ? (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`${(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, 'card.ui.partial')}` : (0, $409574f4dbacb1f1$export$c18c768bbe3223b7)(hass, primary.protection)}
      </div>
    </div>
  `;
};


const $313ad4784c1ca11f$export$7f14135d73b0f07a = (safeSearchesEnforced)=>[
        [
            {
                sensorKey: 'dns_queries',
                title: 'card.stats.total_queries',
                footer: {
                    key: 'card.stats.safe_searches',
                    search: '{number}',
                    replace: safeSearchesEnforced
                },
                className: 'queries-box',
                icon: 'mdi:earth'
            },
            {
                sensorKey: 'dns_queries_blocked',
                title: 'card.stats.queries_blocked',
                footer: 'card.stats.list_blocked_queries',
                className: 'blocked-box',
                icon: 'mdi:hand-back-right'
            }
        ],
        [
            {
                sensorKey: 'dns_queries_blocked_ratio',
                title: 'card.stats.percentage_blocked',
                footer: 'card.stats.list_all_queries',
                className: 'percentage-box',
                icon: 'mdi:chart-pie'
            },
            {
                sensorKey: 'average_processing_speed',
                title: 'card.stats.average_processing_speed',
                footer: 'card.stats.processing_speed_info',
                className: 'domains-box',
                icon: 'mdi:speedometer'
            }
        ]
    ];




/**
 * Formats a number for display using the user's language.
 */ const $5d21a05749e1ce63$export$f5dd818bff069720 = (num, language, options)=>{
    const value = Number(num);
    if (Number.isNaN(value) || num === '') return typeof num === 'string' ? num : String(num);
    return new Intl.NumberFormat(language, options).format(value);
};





const $1f2c0e8d95d0a59b$export$c26b385db31056a8 = (element, hass, entity, sectionConfig, statBoxConfig)=>{
    if (!entity) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
    const uom = [
        '%',
        'ms'
    ].includes(entity.attributes?.unit_of_measurement ?? '') ? entity.attributes?.unit_of_measurement : '';
    const value = (0, $5d21a05749e1ce63$export$f5dd818bff069720)(entity.state, hass.language, {
        maximumFractionDigits: 1
    });
    const footer = typeof statBoxConfig.footer === 'string' ? (0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, statBoxConfig.footer) : (0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, statBoxConfig.footer.key, statBoxConfig.footer.search, statBoxConfig.footer.replace);
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div
      class="stat-box ${statBoxConfig.className}"
      @action=${(0, $57febad8376708f1$export$3d3654ce4577c53d)(element, sectionConfig, entity)}
      .actionHandler=${(0, $57febad8376708f1$export$8a44987212de21b)(sectionConfig)}
    >
      <div class="stat-icon">
        <ha-icon icon="${statBoxConfig.icon}"></ha-icon>
      </div>
      <div class="stat-content">
        <div class="stat-header">${(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, statBoxConfig.title)}</div>
        <div class="stat-value">${value}${uom}</div>
      </div>
      <div class="stat-footer">
        <span>${footer}</span>
        <ha-icon icon="mdi:arrow-right-circle-outline"></ha-icon>
      </div>
    </div>
  `;
};


const $b0d8503ad71f8731$export$ceaadd68dd4c5e98 = (element, hass, device, config)=>{
    if (!(0, $81267a1185dd4399$export$57bf213be019eeb0)(config, 'statistics')) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
    // Get the unique clients count for the configuration
    const safeSearchesEnforced = device.safe_searches_enforced?.state ?? '0';
    // Get the stats configuration with the unique clients count
    const statConfigs = (0, $313ad4784c1ca11f$export$7f14135d73b0f07a)(safeSearchesEnforced);
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div class="dashboard-stats">
      ${statConfigs.map((group)=>(0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
          <div class="stat-group">
            ${group.map((statConfig)=>(0, $1f2c0e8d95d0a59b$export$c26b385db31056a8)(element, hass, device[statConfig.sensorKey], config.stats, statConfig))}
          </div>
        `)}
    </div>
  `;
};


const $e67ba06cac005a46$export$9c903d35b97d0190 = (config, section)=>!!config.collapsed_sections?.includes(section);






/**
 * Toggles the visibility of a section
 * @param e - The click event
 * @param selector - The CSS selector for the section to toggle
 */ const $993360189f76a862$export$b7c305685fc8cb26 = (e, selector)=>{
    const icon = e.currentTarget.querySelector('.caret-icon');
    const section = e.currentTarget.parentElement?.querySelector(selector);
    if (section) {
        const isHidden = section.classList.toggle('hidden');
        if (icon) icon.setAttribute('icon', isHidden ? 'mdi:chevron-right' : 'mdi:chevron-down');
    }
};



const $6cbf4e557bc1fbf1$export$535a09426ee2ea59 = (hass, entity, className)=>(0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<state-card-content
    .hass=${hass}
    .stateObj=${entity}
    class=${className}
  ></state-card-content>`;


/**
 * Renders the switches section for the AdGuard card with collapsible functionality.
 * Each section can be toggled open or closed, and displays the relevant switches
 * based on the provided configuration and device state.
 *
 * @param element - The root HTMLElement for the card.
 * @param hass - The Home Assistant instance.
 * @param device - The AdGuardDevice object containing switches.
 * @param config - The configuration object for the card, including section visibility and entity order.
 * @returns A lit-html TemplateResult representing the switches UI, or `nothing` if the section is hidden.
 */ const $9369c7e3c6702a0b$var$switches = (element, hass, device, config)=>{
    const switchCollapsed = (0, $e67ba06cac005a46$export$9c903d35b97d0190)(config, 'switches');
    const sectionStyles = config.styles?.section || {};
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`${(0, $81267a1185dd4399$export$57bf213be019eeb0)(config, 'switches') ? (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<div class="collapsible-section" style=${(0, $19f464fcda7d2482$export$1e5b4ce2fa884e6a)(sectionStyles)}>
          <div
            class="section-header"
            @click=${(e)=>(0, $993360189f76a862$export$b7c305685fc8cb26)(e, '.switches')}
          >
            <span>${(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, 'card.sections.switches')}</span>
            <ha-icon
              class="caret-icon"
              icon="mdi:chevron-${switchCollapsed ? 'right' : 'down'}"
            ></ha-icon>
          </div>
          <div
            class="${[
        'switches',
        switchCollapsed ? 'hidden' : undefined,
        config.switch_spacing
    ].filter((s)=>s).join(' ')}"
          >
            ${device.switches.map((piSwitch)=>{
        const orderExists = config.entity_order?.includes(piSwitch.entity_id);
        if (orderExists) {
            const orderIndex = config.entity_order.indexOf(piSwitch.entity_id);
            const nextItem = config.entity_order[orderIndex + 1];
            if (nextItem === 'divider') return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`${(0, $6cbf4e557bc1fbf1$export$535a09426ee2ea59)(hass, piSwitch)}
                    <div class="divider"></div>`;
        }
        return (0, $6cbf4e557bc1fbf1$export$535a09426ee2ea59)(hass, piSwitch);
    })}
          </div>
        </div>` : (0, $f58f44579a4747ac$export$45b790e32b2810ee)}`;
};
const $9369c7e3c6702a0b$export$85691f7dcbc38c10 = (element, hass, setup, device, config)=>{
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)` <div>${$9369c7e3c6702a0b$var$switches(element, hass, device, config)}</div> `;
};






const $4227987aac09cd77$export$efbe1467c55dee42 = (entity)=>{
    // super hacky - but too lazy to hardcode the names
    const label = (entity.attributes.friendly_name ?? '').replace(' update', '');
    const hasUpdate = (0, $46dabcff6df1e992$exports.stateActive)(entity, entity.state);
    const latestVersion = entity.attributes.latest_version;
    const installedVersion = entity.attributes.installed_version;
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div class="version-item ${hasUpdate ? 'update-available' : ''}">
      <span class="version-label">${label}</span>
      <a href="${entity.attributes.release_url}" target="_blank">
        <span class="version-text">
          ${installedVersion}
          ${hasUpdate && latestVersion ? (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<span class="version-separator"> → </span
                  ><span class="version-latest">${latestVersion}</span>` : ''}
        </span>
      </a>
    </div>
  `;
};


const $49bfcbfa0b6e0050$export$7c88f7b87167f6 = (_element, _hass, config, device)=>{
    if (!(0, $81267a1185dd4399$export$57bf213be019eeb0)(config, 'footer')) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<div class="version-info">
    ${device.updates.map((update)=>{
        return (0, $4227987aac09cd77$export$efbe1467c55dee42)(update);
    })}
  </div>`;
};







const $0f7838a7e387da95$export$7c3e21e9e0c181da = (hass, element, config, entity)=>{
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div
      class="additional-stat"
      @action=${(0, $57febad8376708f1$export$3d3654ce4577c53d)(element, config, entity)}
      .actionHandler=${(0, $57febad8376708f1$export$8a44987212de21b)(config)}
    >
      <ha-state-icon .hass=${hass} .stateObj=${entity}></ha-state-icon>
      ${(0, $409574f4dbacb1f1$export$c18c768bbe3223b7)(hass, entity)}
    </div>
  `;
};


const $f72adbed169bb149$export$f7d6b8c683630484 = (element, hass, device, config)=>{
    if (!(0, $81267a1185dd4399$export$57bf213be019eeb0)(config, 'sensors')) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
    const regularSensors = device.sensors;
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <div class="additional-stats">
      ${regularSensors.map((sensor)=>{
        return (0, $0f7838a7e387da95$export$7c3e21e9e0c181da)(hass, element, config.info, sensor);
    })}
    </div>
  `;
};


const $f5cecba293939c1a$export$b078560c105809a7 = (element, hass, setup, config)=>{
    const primary = setup.holes[0];
    const cardStyles = config.styles?.card || {};
    return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
    <ha-card style=${(0, $19f464fcda7d2482$export$1e5b4ce2fa884e6a)(cardStyles)}>
      ${(0, $a2b1c365027138cb$export$dfb737c0873de058)(element, setup, hass, config)}
      <div class="card-content">
        ${(0, $b0d8503ad71f8731$export$ceaadd68dd4c5e98)(element, hass, primary, config)}
        ${(0, $f72adbed169bb149$export$f7d6b8c683630484)(element, hass, primary, config)}
      </div>
      ${(0, $9369c7e3c6702a0b$export$85691f7dcbc38c10)(element, hass, setup, primary, config)}
      ${(0, $49bfcbfa0b6e0050$export$7c88f7b87167f6)(element, hass, config, primary)}
    </ha-card>
  `;
};


const $19442883b2a008d3$export$df7b058ef38e4826 = async (hass)=>{
    const registries = await hass.callWS({
        type: 'config_entries/get',
        domain: 'adguard'
    });
    const registry = registries[0];
    if (!registry) return undefined;
    const devices = Object.values(hass.devices).filter((device)=>device.config_entries.includes(registry.entry_id));
    return devices[0];
};


const $28ca676359267166$export$ce4e438906f3b684 = (config, entities)=>{
    if (config.entity_order?.length) {
        const entityOrderMap = new Map();
        // Create a map with entity_id as key and its position in entity_order as value
        config.entity_order.forEach((entityId, index)=>{
            entityOrderMap.set(entityId, index);
        });
        // Sort entities based on their position in entity_order
        // Entities not in entity_order will have undefined position and will be placed at the end
        entities = entities.sort((a, b)=>{
            const aPosition = entityOrderMap.has(a.entity_id) ? entityOrderMap.get(a.entity_id) : Number.MAX_SAFE_INTEGER;
            const bPosition = entityOrderMap.has(b.entity_id) ? entityOrderMap.get(b.entity_id) : Number.MAX_SAFE_INTEGER;
            return (aPosition ?? Number.MAX_SAFE_INTEGER) - (bPosition ?? Number.MAX_SAFE_INTEGER);
        });
    }
    return entities;
};


const $7aa94e0bc82e2c26$var$keyToPropertyMap = {
    // stat boxes
    dns_queries: 'dns_queries',
    dns_queries_blocked: 'dns_queries_blocked',
    dns_queries_blocked_ratio: 'dns_queries_blocked_ratio',
    average_processing_speed: 'average_processing_speed',
    safe_searches_enforced: 'safe_searches_enforced',
    protection: 'protection',
    // testing w/ pi-hole
    dns_queries_today: 'dns_queries',
    domains_blocked: 'dns_queries_blocked',
    ads_percentage_blocked_today: 'dns_queries_blocked_ratio',
    ftl_info_message_count: 'average_processing_speed',
    dns_unique_clients: 'safe_searches_enforced',
    status: 'protection'
};
const $7aa94e0bc82e2c26$export$51bb3e4a8dd2f2ff = (entity, device)=>{
    const key = entity.translation_key;
    if (key && key in $7aa94e0bc82e2c26$var$keyToPropertyMap) {
        const prop = $7aa94e0bc82e2c26$var$keyToPropertyMap[key];
        device[prop] = entity;
        return true;
    }
    return false;
};


const $25a2e2943b63f930$export$2448ebcf2d0e9554 = (entity, config)=>{
    if (!config.exclude_entities?.length) return false;
    return config.exclude_entities.some((entityId)=>entity.entity_id === entityId);
};




const $5bd3a7e1f19a6de3$export$30c823bc834d6ab4 = (hass, deviceId)=>hass.devices[deviceId];


const $e24dedcf9e480b2d$export$50fdfeece43146fd = (hass, entityId, fakeState = false)=>{
    if (!entityId) return undefined;
    const state = hass.states[entityId] ?? (fakeState ? {
        entity_id: entityId,
        state: 'off',
        attributes: {}
    } : undefined);
    if (!state) return undefined;
    return {
        state: state.state,
        attributes: state.attributes,
        entity_id: state.entity_id
    };
};


const $093edc2594769ee5$export$c6a2d06cc40e579 = (hass, deviceId, deviceName)=>{
    const deviceEntities = Object.values(hass.entities).filter((entity)=>entity.device_id === deviceId || entity.entity_id === 'update.pi_hole_v6_integration_update').map((entity)=>{
        const state = (0, $e24dedcf9e480b2d$export$50fdfeece43146fd)(hass, entity.entity_id);
        if (state === undefined) return;
        // convenience
        const name = state.attributes.friendly_name === deviceName ? deviceName : state.attributes.friendly_name?.replace(deviceName ?? '', '').trim();
        return {
            entity_id: entity.entity_id,
            translation_key: entity.translation_key,
            state: state.state,
            attributes: {
                ...state.attributes,
                friendly_name: name
            }
        };
    }).filter((e)=>e !== undefined);
    return deviceEntities;
};


const $284c781f33d4e276$export$e59f4de531f44b4e = (hass, config, deviceId)=>{
    const device = {
        device_id: deviceId,
        sensors: [],
        switches: [],
        updates: []
    };
    const hassDevice = (0, $5bd3a7e1f19a6de3$export$30c823bc834d6ab4)(hass, device.device_id);
    if (!hassDevice) return undefined;
    // Get all entities for the device
    const entities = (0, $093edc2594769ee5$export$c6a2d06cc40e579)(hass, hassDevice.id, hassDevice.name);
    // Map entities to the device object
    (0, $28ca676359267166$export$ce4e438906f3b684)(config, entities).forEach((entity)=>{
        if ((0, $25a2e2943b63f930$export$2448ebcf2d0e9554)(entity, config)) return;
        // Skip already handled entities by translation key
        if ((0, $7aa94e0bc82e2c26$export$51bb3e4a8dd2f2ff)(entity, device)) return;
        // Handle other entities by domain
        const domain = (0, $9be1c046bd0bdc20$exports.computeDomain)(entity.entity_id);
        switch(domain){
            case 'sensor':
                device.sensors.push(entity);
                break;
            case 'switch':
                device.switches.push(entity);
                break;
            case 'update':
                device.updates.push(entity);
                break;
        }
    });
    // Sort updates by title (using nullish coalescing for cleaner code)
    device.updates.sort((a, b)=>{
        const aTitle = a.attributes.title ?? 'z';
        const bTitle = b.attributes.title ?? 'z';
        return aTitle.localeCompare(bTitle);
    });
    return device;
};


const $0544f6a0e4690d02$export$3e7625def91a5ba7 = (hass, config)=>{
    // Handle both string and array device IDs
    const deviceIds = Array.isArray(config.device_id) ? config.device_id : [
        config.device_id
    ];
    if (deviceIds.length === 0) return undefined;
    // keep track of switches that are not in the first device
    const spareSwitches = [];
    const holes = deviceIds.map((deviceId)=>(0, $284c781f33d4e276$export$e59f4de531f44b4e)(hass, config, deviceId)).filter((hole)=>hole !== undefined).map((hole, i)=>{
        if (i > 0) {
            spareSwitches.push(...hole.switches);
            // don't track entites that are not in the first device
            return {
                device_id: hole.device_id,
                // required for the setup state to work
                protection: hole.protection,
                controls: [],
                sensors: [],
                switches: [],
                updates: []
            };
        }
        return hole;
    });
    if (holes.length > 1) {
        const primary = holes[0];
        // resort the combined switches
        primary.switches = (0, $28ca676359267166$export$ce4e438906f3b684)(config, [
            ...primary.switches,
            ...spareSwitches
        ]);
    }
    return {
        holes: holes
    };
};



var $30856da572fd852b$exports = {};
'use strict';
// do not edit .js files directly - edit src/index.jst
$30856da572fd852b$exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && typeof a == 'object' && typeof b == 'object') {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
            length = a.length;
            if (length != b.length) return false;
            for(i = length; i-- !== 0;)if (!equal(a[i], b[i])) return false;
            return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for(i = length; i-- !== 0;)if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for(i = length; i-- !== 0;){
            var key = keys[i];
            if (!equal(a[key], b[key])) return false;
        }
        return true;
    }
    // true if both NaN, false otherwise
    return a !== a && b !== b;
};



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $14742f68afc766d6$export$da64fc29f17f9d0e = (t)=>(e, o)=>{
        void 0 !== o ? o.addInitializer(()=>{
            customElements.define(t, e);
        }) : customElements.define(t, e);
    };



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $9cd908ed2625c047$var$o = {
    attribute: !0,
    type: String,
    converter: (0, $19fe8e3abedf4df0$export$7312b35fbf521afb),
    reflect: !1,
    hasChanged: (0, $19fe8e3abedf4df0$export$53a6892c50694894)
}, $9cd908ed2625c047$export$8d623b1670eb40f4 = (t = $9cd908ed2625c047$var$o, e, r)=>{
    const { kind: n, metadata: i } = r;
    let s = globalThis.litPropertyMetadata.get(i);
    if (void 0 === s && globalThis.litPropertyMetadata.set(i, s = new Map), "setter" === n && ((t = Object.create(t)).wrapped = !0), s.set(r.name, t), "accessor" === n) {
        const { name: o } = r;
        return {
            set (r) {
                const n = e.get.call(this);
                e.set.call(this, r), this.requestUpdate(o, n, t);
            },
            init (e) {
                return void 0 !== e && this.C(o, void 0, t, e), e;
            }
        };
    }
    if ("setter" === n) {
        const { name: o } = r;
        return function(r) {
            const n = this[o];
            e.call(this, r), this.requestUpdate(o, n, t);
        };
    }
    throw Error("Unsupported decorator location: " + n);
};
function $9cd908ed2625c047$export$d541bacb2bda4494(t) {
    return (e, o)=>"object" == typeof o ? $9cd908ed2625c047$export$8d623b1670eb40f4(t, e, o) : ((t, e, o)=>{
            const r = e.hasOwnProperty(o);
            return e.constructor.createProperty(o, t), r ? Object.getOwnPropertyDescriptor(e, o) : void 0;
        })(t, e, o);
}



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $04c21ea1ce1f6057$export$ca000e230c0caa3e(r) {
    return (0, $9cd908ed2625c047$export$d541bacb2bda4494)({
        ...r,
        state: !0,
        attribute: !1
    });
}


/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $b4269277b3c48b0c$export$b2b799818fbabcf3(t) {
    return (n, o)=>{
        const c = "function" == typeof n ? n : n[o];
        Object.assign(c, t);
    };
}


/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ const $25e9c5a8f7ecfc69$export$51987bb50e1f6752 = (e, t, c)=>(c.configurable = !0, c.enumerable = !0, Reflect.decorate && "object" != typeof t && Object.defineProperty(e, t, c), c);


/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $02a1f3a787c54a30$export$2fa187e846a241c4(e, r) {
    return (n, s, i)=>{
        const o = (t)=>t.renderRoot?.querySelector(e) ?? null;
        if (r) {
            const { get: e, set: r } = "object" == typeof s ? n : i ?? (()=>{
                const t = Symbol();
                return {
                    get () {
                        return this[t];
                    },
                    set (e) {
                        this[t] = e;
                    }
                };
            })();
            return (0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(n, s, {
                get () {
                    let t = e.call(this);
                    return void 0 === t && (t = o(this), (null !== t || this.hasUpdated) && r.call(this, t)), t;
                }
            });
        }
        return (0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(n, s, {
            get () {
                return o(this);
            }
        });
    };
}



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ let $ed34c589b230c255$var$e;
function $ed34c589b230c255$export$dcd0d083aa86c355(r) {
    return (n, o)=>(0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(n, o, {
            get () {
                return (this.renderRoot ?? ($ed34c589b230c255$var$e ??= document.createDocumentFragment())).querySelectorAll(r);
            }
        });
}



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $ea50f1870b80cbec$export$163dfc35cc43f240(r) {
    return (n, e)=>(0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(n, e, {
            async get () {
                return await this.updateComplete, this.renderRoot?.querySelector(r) ?? null;
            }
        });
}



/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $563fcf7ce7e6c5aa$export$4682af2d9ee91415(o) {
    return (e, n)=>{
        const { slot: r, selector: s } = o ?? {}, c = "slot" + (r ? `[name=${r}]` : ":not([name])");
        return (0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(e, n, {
            get () {
                const t = this.renderRoot?.querySelector(c), e = t?.assignedElements(o) ?? [];
                return void 0 === s ? e : e.filter((t)=>t.matches(s));
            }
        });
    };
}



/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */ function $728f1385dd7bf557$export$1bdbe53f9df1b8(n) {
    return (o, r)=>{
        const { slot: e } = n ?? {}, s = "slot" + (e ? `[name=${e}]` : ":not([name])");
        return (0, $25e9c5a8f7ecfc69$export$51987bb50e1f6752)(o, r, {
            get () {
                const t = this.renderRoot?.querySelector(s);
                return t?.assignedNodes(n) ?? [];
            }
        });
    };
}





const $13632afec4749c69$export$7d546b06e96d63cc = (0, $def2de46b9306e8a$export$dbf350e5966cf602)`
  .collapsible-section {
    margin: 0;
  }

  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 16px;
    cursor: pointer;
    user-select: none;
  }

  .section-header span {
    font-weight: 500;
  }

  .caret-icon {
    transition: transform 0.3s ease;
    display: var(--user--section--caret--display, block);
  }

  .hidden {
    max-height: 0;
    opacity: 0;
    margin: 0;
    padding: 0;
  }
`;
const $13632afec4749c69$export$9dd6ff9ea0189349 = (0, $def2de46b9306e8a$export$dbf350e5966cf602)`
  ${$13632afec4749c69$export$7d546b06e96d63cc}

  ha-card {
    overflow: hidden;
  }

  /* Card header styles */
  .card-header {
    display: flex;
    justify-content: space-between;
    padding: 16px 16px 0;
  }

  .name {
    display: flex;
    align-items: center;
    font-size: 1.2rem;
    font-weight: 500;
  }

  .name ha-icon {
    margin-right: 8px;
  }

  .status {
    display: flex;
    font-weight: 500;
  }

  .status ha-icon {
    margin-right: 4px;
  }

  .card-content {
    padding: 16px 16px 0px 16px;
  }

  /* Dashboard-style layout with grouped stat boxes */
  .dashboard-stats {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 16px;
  }

  /* Stat groups - will appear side by side on larger screens */
  .stat-group {
    display: flex;
    gap: 12px;
    flex: 1;
  }

  .stat-box {
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    color: white;
    transition: transform 0.2s;
    min-height: 120px;
    min-width: 120px;
    flex: 1;
    position: relative;
    overflow: hidden;
    cursor: pointer;
  }

  .stat-box:hover {
    transform: scale(1.02);
  }

  /* New: Stat Icon (Background) */
  .stat-icon {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.2;
    z-index: 1;
  }

  .stat-icon ha-icon {
    --mdc-icon-size: 80px;
    color: rgba(255, 255, 255, 0.8);
  }

  /* Content container to position above the icon */
  .stat-content {
    position: relative;
    z-index: 2;
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  .stat-header {
    font-size: 1rem;
    padding: 12px 12px 0px 12px;
  }

  .stat-value {
    font-size: 2rem;
    font-weight: bold;
    padding: 8px 12px 0;
    flex: 1;
  }

  .stat-footer {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.8rem;
    background: rgba(0, 0, 0, 0.1);
    padding: 2px 12px;
    margin-top: auto; /* Push to the bottom */
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    box-sizing: border-box;
  }

  /* Dashboard boxes - muted versions of AdGuard colors */
  .queries-box {
    background-color: rgba(92, 127, 195, 0.85);
  }

  .blocked-box {
    background-color: rgba(171, 43, 25, 0.85);
  }

  .percentage-box {
    background-color: rgba(243, 156, 18, 0.85);
  }

  .domains-box {
    background-color: rgba(0, 166, 90, 0.85);
  }

  /* Additional stats styling - specialized responsive grid */
  .additional-stats {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
  }

  .additional-stat {
    cursor: pointer;
    display: flex;
    align-items: center;
    font-size: 0.9rem;
    color: var(--secondary-text-color);
    padding: 8px;
    border-radius: 4px;
    min-width: 120px;
    /* Allow text to wrap if needed */
    white-space: normal;
    overflow: hidden;
  }

  .additional-stat ha-state-icon {
    margin-right: 8px;
    color: var(--secondary-text-color);
  }

  .switches {
    display: flex;
    flex-wrap: wrap;
    overflow: hidden;
    justify-content: space-between;
  }

  /* Version information styles */
  .version-info {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    padding: 8px 16px 16px;
    font-size: 0.85rem;
    color: var(--secondary-text-color);
    border-top: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
    gap: 12px;
  }

  .version-item {
    display: flex;
    align-items: center;
    white-space: nowrap;
  }

  .version-item.update-available {
    border-left: 3px solid var(--warning-color, #ff9800);
    padding-left: 8px;
    margin-left: -8px;
  }

  .version-label {
    margin-right: 4px;
    font-weight: 700;
  }

  .version-text {
    display: inline-flex;
    align-items: center;
  }

  .version-separator {
    margin: 0 4px;
    color: var(--secondary-text-color);
  }

  .version-latest {
    color: var(--warning-color, #ff9800);
    font-weight: 600;
  }

  /* Very small screen adjustments */
  @media (max-width: 400px) {
    .stat-group {
      flex-direction: column;
    }
  }

  /* Click action button styles */
  mwc-button {
    margin: 4px;
    cursor: pointer;
  }

  mwc-button.primary {
    --mdc-theme-primary: var(--success-color);
  }

  mwc-button.warning {
    --mdc-theme-primary: var(--warning-color);
  }

  mwc-button ha-icon {
    margin-right: 3px;
  }

  /* Switch styles */
  .remaining-time {
    font-size: 1.2rem;
    font-weight: 400;
  }

  .remaining-time::before {
    content: '-';
    margin: 0px 8px;
  }

  .space-around {
    justify-content: space-around;
  }

  .space-between > state-card-content {
    width: 100%;
  }

  /* Status icon styles */
  .multi-status {
    font-size: 0.9rem;
    margin-left: 8px;
    opacity: 0.8;
  }

  /* Divider styles */
  .divider {
    height: 1px;
    background-color: var(--secondary-text-color);
    width: 100%;
    margin: 10px 16px;
  }

  /* Warning badge styles */
  .warning-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 25px;
    height: 25px;
    border-radius: 50%;
    background-color: var(--warning-color, #ff9800);
    color: var(--secondary-text-color);
    font-weight: bolder;
    font-size: 1rem;
    margin-right: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    min-width: 25px;
    transition:
      transform 0.2s ease,
      filter 0.2s ease,
      box-shadow 0.2s ease;
    will-change: transform, filter;
  }

  .warning-badge:hover,
  .warning-badge:focus-visible {
    transform: translateY(-1px) scale(1.06);
    filter: brightness(1.05);
    box-shadow:
      0 6px 12px rgba(0, 0, 0, 0.25),
      0 0 0 3px var(--warning-color, #ff9800);
  }

  .badge {
    cursor: pointer;
  }
`;


class $e4f1b26747081709$export$ffae0d3bf5bf7be4 extends (0, $ab210b2da7b39b9d$export$3f2f9f5909897157) {
    /**
   * Returns the component's styles
   */ static get styles() {
        return 0, $13632afec4749c69$export$9dd6ff9ea0189349;
    }
    /**
   * Sets up the card configuration
   * @param {Config} config - The card configuration
   */ setConfig(config) {
        if (!(0, (/*@__PURE__*/$parcel$interopDefault($30856da572fd852b$exports)))(config, this._config)) this._config = config;
    }
    /**
   * Updates the card's state when Home Assistant state changes
   * @param {HomeAssistant} hass - The Home Assistant instance
   */ set hass(hass) {
        this._hass = hass;
        const setup = (0, $0544f6a0e4690d02$export$3e7625def91a5ba7)(hass, this._config);
        if (setup && !(0, (/*@__PURE__*/$parcel$interopDefault($30856da572fd852b$exports)))(setup, this._setup)) this._setup = setup;
        else // update children who are subscribed
        (0, $d8229c453ce2530e$exports.fireEvent)(this, 'hass-update', {
            hass: hass
        });
    }
    // card configuration
    static getConfigElement() {
        return document.createElement('adguard-editor');
    }
    static async getStubConfig(hass) {
        const device = await (0, $19442883b2a008d3$export$df7b058ef38e4826)(hass);
        return {
            device_id: device?.id ?? ''
        };
    }
    render() {
        if (!this._hass || !this._config) return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<ha-card>
        <div class="card-content">
          <div class="no-devices">Loading...</div>
        </div>
      </ha-card>`;
        if (!this._setup || !this._setup.holes || this._setup.holes.length === 0) return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`<ha-card>
        <div class="card-content">
          <div class="no-setup">No instances found</div>
        </div>
      </ha-card>`;
        return (0, $f5cecba293939c1a$export$b078560c105809a7)(this, this._hass, this._setup, this._config);
    }
}
(0, $e710f43c4558477c$export$29e00dfd3077644b)([
    (0, $04c21ea1ce1f6057$export$ca000e230c0caa3e)()
], $e4f1b26747081709$export$ffae0d3bf5bf7be4.prototype, "_config", void 0);
(0, $e710f43c4558477c$export$29e00dfd3077644b)([
    (0, $04c21ea1ce1f6057$export$ca000e230c0caa3e)()
], $e4f1b26747081709$export$ffae0d3bf5bf7be4.prototype, "_setup", void 0);







// Constants for repeated patterns
const $b642db848cc622aa$var$ADGUARD_INTEGRATION_FILTER = [
    {
        integration: 'adguard'
    }
];
const $b642db848cc622aa$var$ADGUARD_ENTITY_FILTER = [
    {
        integration: 'adguard',
        domain: [
            'button',
            'sensor',
            'switch'
        ]
    }
];
const $b642db848cc622aa$var$getSwitchSpacingOptions = (hass)=>{
    const l = (label)=>(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, label);
    return [
        {
            label: l('editor.flex_default'),
            value: 'flex'
        },
        {
            label: l('editor.space_around'),
            value: 'space-around'
        },
        {
            label: l('editor.space_between'),
            value: 'space-between'
        }
    ];
};
const $b642db848cc622aa$var$getSectionExcludeOptions = (hass)=>{
    const l = (label)=>(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, label);
    return [
        {
            label: l('editor.header'),
            value: 'header'
        },
        {
            label: l('editor.statistics'),
            value: 'statistics'
        },
        {
            label: l('editor.sensors'),
            value: 'sensors'
        },
        {
            label: l('editor.switches'),
            value: 'switches'
        },
        {
            label: l('editor.footer'),
            value: 'footer'
        }
    ];
};
const $b642db848cc622aa$var$getCollapsedSectionOptions = (hass)=>{
    const l = (label)=>(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(hass, label);
    return [
        {
            label: l('editor.switches'),
            value: 'switches'
        }
    ];
};
const $b642db848cc622aa$var$ACTION_SCHEMA = [
    {
        name: 'tap_action',
        label: 'editor.tap_action',
        selector: {
            ui_action: {}
        }
    },
    {
        name: 'hold_action',
        label: 'editor.hold_action',
        selector: {
            ui_action: {}
        }
    },
    {
        name: 'double_tap_action',
        label: 'editor.double_tap_action',
        selector: {
            ui_action: {}
        }
    }
];
const $b642db848cc622aa$var$getSchema = (hass)=>{
    return [
        {
            name: 'device_id',
            selector: {
                device: {
                    filter: $b642db848cc622aa$var$ADGUARD_INTEGRATION_FILTER,
                    multiple: true
                }
            },
            required: true,
            label: 'editor.adguard_device'
        },
        {
            name: 'content',
            label: 'editor.content',
            type: 'expandable',
            flatten: true,
            icon: 'mdi:text-short',
            schema: [
                {
                    name: 'title',
                    required: false,
                    label: 'editor.card_title',
                    selector: {
                        text: {}
                    }
                },
                {
                    name: 'icon',
                    required: false,
                    label: 'editor.card_icon',
                    selector: {
                        icon: {
                            placeholder: 'mdi:shield-check'
                        }
                    }
                }
            ]
        },
        {
            name: 'layout',
            label: 'editor.layout',
            type: 'expandable',
            flatten: true,
            icon: 'mdi:view-grid-plus',
            schema: [
                {
                    name: 'exclude_sections',
                    label: 'editor.sections_to_exclude',
                    required: false,
                    selector: {
                        select: {
                            multiple: true,
                            mode: 'list',
                            options: $b642db848cc622aa$var$getSectionExcludeOptions(hass)
                        }
                    }
                },
                {
                    name: 'collapsed_sections',
                    label: 'editor.sections_collapsed_by_default',
                    required: false,
                    selector: {
                        select: {
                            multiple: true,
                            mode: 'list',
                            options: $b642db848cc622aa$var$getCollapsedSectionOptions(hass)
                        }
                    }
                },
                {
                    name: 'switch_style',
                    label: 'editor.style_for_switches',
                    required: false,
                    selector: {
                        select: {
                            multiple: false,
                            mode: 'dropdown',
                            options: $b642db848cc622aa$var$getSwitchSpacingOptions(hass)
                        }
                    }
                },
                {
                    name: 'exclude_entities',
                    label: 'editor.entities_to_exclude',
                    required: false,
                    selector: {
                        entity: {
                            multiple: true,
                            filter: $b642db848cc622aa$var$ADGUARD_INTEGRATION_FILTER
                        }
                    }
                },
                {
                    name: 'entity_order',
                    label: 'editor.entity_display_order',
                    required: false,
                    selector: {
                        entity: {
                            multiple: true,
                            filter: $b642db848cc622aa$var$ADGUARD_ENTITY_FILTER
                        }
                    }
                }
            ]
        },
        {
            name: 'styles',
            label: 'editor.styles.label',
            flatten: true,
            type: 'expandable',
            icon: 'mdi:brush-variant',
            schema: [
                {
                    name: 'switch_spacing',
                    label: 'editor.switch_spacing',
                    required: false,
                    selector: {
                        select: {
                            multiple: false,
                            mode: 'dropdown',
                            options: $b642db848cc622aa$var$getSwitchSpacingOptions(hass)
                        }
                    }
                },
                {
                    name: 'styles',
                    label: 'editor.styles.css_styles',
                    type: 'expandable',
                    icon: 'mdi:spray',
                    schema: [
                        {
                            name: 'card',
                            label: 'editor.styles.card_styles',
                            selector: {
                                object: {}
                            }
                        },
                        {
                            name: 'section',
                            label: 'editor.styles.section_styles',
                            selector: {
                                object: {}
                            }
                        }
                    ]
                }
            ]
        },
        {
            name: 'interactions',
            label: 'editor.interactions',
            type: 'expandable',
            flatten: true,
            icon: 'mdi:gesture-tap',
            schema: [
                {
                    name: 'badge',
                    label: 'editor.badge',
                    type: 'expandable',
                    icon: 'mdi:badge-account-horizontal',
                    schema: $b642db848cc622aa$var$ACTION_SCHEMA
                },
                {
                    name: 'status',
                    label: 'editor.status',
                    type: 'expandable',
                    icon: 'mdi:check-circle-outline',
                    schema: $b642db848cc622aa$var$ACTION_SCHEMA
                },
                {
                    name: 'stats',
                    label: 'editor.statistics',
                    type: 'expandable',
                    icon: 'mdi:counter',
                    schema: $b642db848cc622aa$var$ACTION_SCHEMA
                },
                {
                    name: 'info',
                    label: 'editor.information',
                    type: 'expandable',
                    icon: 'mdi:information-outline',
                    schema: $b642db848cc622aa$var$ACTION_SCHEMA
                }
            ]
        }
    ];
};
class $b642db848cc622aa$export$5333a5daa144f6b5 extends (0, $ab210b2da7b39b9d$export$3f2f9f5909897157) {
    /**
   * renders the lit element card
   * @returns {TemplateResult} The rendered HTML template
   */ render() {
        if (!this.hass || !this._config) return 0, $f58f44579a4747ac$export$45b790e32b2810ee;
        return (0, $f58f44579a4747ac$export$c0bb0b647f701bb5)`
      <ha-form
        .hass=${this.hass}
        .data=${this._config}
        .schema=${$b642db848cc622aa$var$getSchema(this.hass)}
        .computeLabel=${(s)=>(0, $623ffaa3e77fea87$export$b3bd0bc58e36cd63)(this.hass, s.label)}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `;
    }
    /**
   * Sets up the card configuration
   * @param {Config} config - The card configuration
   */ setConfig(config) {
        this._config = config;
        // Normalize device_id: convert string to array for multiple selector compatibility
        if (typeof config.device_id === 'string') this._config = {
            ...config,
            device_id: [
                config.device_id
            ]
        };
        else this._config = config;
    }
    _valueChanged(ev) {
        const config = ev.detail.value;
        // Normalize device_id: convert single-item array to string for cleaner configs
        if (Array.isArray(config.device_id) && config.device_id.length === 1) config.device_id = config.device_id[0];
        const shouldDelete = (obj)=>obj && (Object.keys(obj).length === 0 || Object.values(obj).every((f)=>!f));
        if (shouldDelete(config.stats)) delete config.stats;
        if (shouldDelete(config.info)) delete config.info;
        if (shouldDelete(config.badge)) delete config.badge;
        if (shouldDelete(config.status)) delete config.status;
        if (!config.exclude_entities?.length) delete config.exclude_entities;
        if (!config.exclude_sections?.length) delete config.exclude_sections;
        if (!config.entity_order?.length) delete config.entity_order;
        if (!config.collapsed_sections?.length) delete config.collapsed_sections;
        // @ts-expect-error config-changed is a HA editor event not in the local fireEvent map
        (0, $d8229c453ce2530e$exports.fireEvent)(this, 'config-changed', {
            config: config
        });
    }
}
(0, $e710f43c4558477c$export$29e00dfd3077644b)([
    (0, $04c21ea1ce1f6057$export$ca000e230c0caa3e)()
], $b642db848cc622aa$export$5333a5daa144f6b5.prototype, "_config", void 0);


var $f14e78138687b521$exports = {};
"use strict";
Object.defineProperty($f14e78138687b521$exports, "__esModule", {
    value: true
});
$f14e78138687b521$exports.getDevice = void 0;
/**
 * Retrieves a device from `hass.devices`.
 */ const $f14e78138687b521$var$getDevice = (hass, deviceId)=>{
    const device = hass.devices[deviceId];
    if (!device) return undefined;
    return {
        id: device.id,
        config_entries: device.config_entries,
        identifiers: device.identifiers,
        manufacturer: device.manufacturer,
        model: device.model,
        model_id: device.model_id,
        name: device.name,
        name_by_user: device.name_by_user,
        serial_number: device.serial_number
    };
};
$f14e78138687b521$exports.getDevice = $f14e78138687b521$var$getDevice;


/** Integration that owns AdGuard Home devices. */ const $a1c3df4b1a664a1d$var$ADGUARD_INTEGRATION = 'adguard';
/**
 * Resolves an entity to its AdGuard device id, or `null` when the entity is
 * missing or not owned by that integration.
 */ const $a1c3df4b1a664a1d$var$adguardDeviceId = (hass, entityId)=>{
    const entity = hass.entities[entityId];
    if (!entity?.device_id) return null;
    const device = (0, $f14e78138687b521$exports.getDevice)(hass, entity.device_id);
    if (!device) return null;
    const isAdGuard = device.identifiers.some(([integration])=>integration === $a1c3df4b1a664a1d$var$ADGUARD_INTEGRATION);
    if (!isAdGuard) return null;
    return device.id;
};
const $a1c3df4b1a664a1d$export$eef4717271055433 = (hass, entityId)=>{
    const deviceId = $a1c3df4b1a664a1d$var$adguardDeviceId(hass, entityId);
    if (!deviceId) return null;
    return {
        config: {
            type: 'custom:adguard-card',
            device_id: deviceId
        }
    };
};


var $d51373b66ef17fcb$exports = {};
"use strict";
/**
 * https://github.com/home-assistant/frontend/blob/dev/src/data/lovelace_custom_cards.ts
 */ Object.defineProperty($d51373b66ef17fcb$exports, "__esModule", {
    value: true
});
$d51373b66ef17fcb$exports.customCards = void 0;
const $d51373b66ef17fcb$var$customCardsWindow = globalThis;
if (!('customCards' in $d51373b66ef17fcb$var$customCardsWindow)) $d51373b66ef17fcb$var$customCardsWindow.customCards = [];
$d51373b66ef17fcb$exports.customCards = $d51373b66ef17fcb$var$customCardsWindow.customCards;


var $b06602ab53bd58a3$exports = {};
$b06602ab53bd58a3$exports = JSON.parse("{\"name\":\"adguard\",\"version\":\"0.9.0\",\"author\":{\"name\":\"Patrick Masters\",\"url\":\"https://curiouscat.consulting/projects/ha-adguard-card?utm_source=github-adguard-card&utm_medium=package-metadata&utm_campaign=oss-presence&utm_content=author-url\"},\"license\":\"ISC\",\"prettier\":\"@homeassistant-extras/config/prettier\",\"description\":\"Card to summarize information for, and to control your Adguard instance!\",\"repository\":{\"type\":\"git\",\"url\":\"https://github.com/homeassistant-extras/adguard-card.git\"},\"bugs\":{\"url\":\"https://github.com/homeassistant-extras/adguard-card/issues\"},\"source\":\"src/index.ts\",\"module\":\"dist/adguard-card.js\",\"targets\":{\"module\":{\"includeNodeModules\":true}},\"@parcel/resolver-default\":{\"packageExports\":true},\"scripts\":{\"watch\":\"parcel watch\",\"build\":\"parcel build\",\"lint\":\"eslint .\",\"lint:fix\":\"eslint . --fix\",\"format\":\"prettier --write .\",\"pass\":\"yarn format && yarn typecheck && yarn lint && yarn test\",\"typecheck\":\"tsc --noEmit && tsc -p tsconfig.test.json --noEmit\",\"test\":\"TS_NODE_PROJECT='./tsconfig.test.json' mocha\",\"test:coverage\":\"nyc yarn run test\",\"test:watch\":\"TS_NODE_PROJECT='./tsconfig.test.json' mocha --watch\",\"update\":\"npx npm-check-updates -u && yarn install\"},\"devDependencies\":{\"@eslint/js\":\"^10.0.1\",\"@homeassistant-extras/config\":\"^0.3.1\",\"@istanbuljs/nyc-config-typescript\":\"^1.0.2\",\"@open-wc/testing\":\"^5.0.0\",\"@parcel/transformer-inline-string\":\"^2.16.4\",\"@testing-library/dom\":\"^10.4.2\",\"@trivago/prettier-plugin-sort-imports\":\"^6.0.2\",\"@types/chai\":\"^5.2.3\",\"@types/jsdom\":\"^30.0.0\",\"@types/mocha\":\"^10.0.10\",\"@types/node\":\"^26.6.2\",\"@types/sinon\":\"^22.0.0\",\"chai\":\"^6.2.2\",\"eslint\":\"^10.11.0\",\"eslint-plugin-lit\":\"^2.3.1\",\"eslint-plugin-wc\":\"^3.1.0\",\"globals\":\"^17.12.0\",\"jsdom\":\"^30.1.0\",\"mocha\":\"^12.0.2\",\"nyc\":\"^18.0.0\",\"parcel\":\"^2.16.4\",\"prettier\":\"3.9.8\",\"prettier-plugin-organize-imports\":\"^4.3.0\",\"proxyquire\":\"^2.1.3\",\"sinon\":\"^22.1.0\",\"ts-node\":\"^10.9.2\",\"tsconfig-paths\":\"^4.2.0\",\"typescript\":\"^6.0.3\",\"typescript-eslint\":\"^8.70.0\"},\"dependencies\":{\"@homeassistant-extras/hass\":\"^0.6.0\",\"@lit/task\":\"^1.0.3\",\"fast-deep-equal\":\"^3.1.3\",\"lit\":\"^3.3.3\"}}");


// Register the custom elements with the browser
customElements.define('adguard-card', (0, $e4f1b26747081709$export$ffae0d3bf5bf7be4));
customElements.define('adguard-editor', (0, $b642db848cc622aa$export$5333a5daa144f6b5));
// Register the cards with Home Assistant's custom card registry
(0, $d51373b66ef17fcb$exports.customCards)?.push({
    // Unique identifier for the card type
    type: 'adguard-card',
    // Display name in the UI
    name: 'AdGuard Card',
    // Card description for the UI
    description: 'A card to summarize and control your AdGuard instance.',
    // Show a preview of the card in the UI
    preview: true,
    // URL for the card's documentation
    documentationURL: 'https://github.com/homeassistant-extras/adguard-card',
    getEntitySuggestion: // Suggest this card when picking an AdGuard entity (HA 2026.6+)
    $a1c3df4b1a664a1d$export$eef4717271055433
});
console.info(`%c\u{1F431} Poat's Tools: adguard-card - ${(0, $b06602ab53bd58a3$exports.version)}`, 'color: #CFC493;');


//# sourceMappingURL=adguard-card.js.map
