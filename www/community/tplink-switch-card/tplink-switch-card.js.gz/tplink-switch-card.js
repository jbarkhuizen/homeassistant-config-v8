/*
 * TP-Link Switch Card
 * Lovelace custom card for TP-Link Easy Smart switch overview.
 *
 * UX levels:
 *   1. Port row        — link dot, speed, PoE badge, wattage
 *   2. Detail row      — all read values + toggles + label editor + Configure button (PoE ports only)
 *   3. Configure panel — inline PoE priority + power limit editor with Apply/Cancel
 *
 * Overview:
 *   - Network info tile (IP, MAC, gateway, netmask)
 *   - PoE tiles (used, remaining)
 *   - PoE budget bar with inline limit editor (pencil icon)
 *
 * Services used:
 *   tplink_easy_smart.set_port_poe_settings  — priority, power_limit per port
 *   tplink_easy_smart.set_general_poe_limit  — global PoE budget limit
 */

(function () {
  const CARD_NAME = "tplink-switch-card";
  if (customElements.get(CARD_NAME)) return;

  if (typeof window !== "undefined") {
    window.customCards = window.customCards || [];
    if (!window.customCards.some((c) => c.type === CARD_NAME)) {
      window.customCards.push({
        type: CARD_NAME,
        name: "TP-Link Switch Card",
        description: "Overview card for TP-Link Easy Smart switch with PoE monitoring and configuration.",
        preview: false,
      });
    }
  }

  const POE_PRIORITIES   = ["Low", "Middle", "High"];
  const POE_POWER_LIMITS = ["Auto", "Class 1", "Class 2", "Class 3", "Class 4", "Manual"];
  const DEFAULT_OVERVIEW_FIELDS = Object.freeze([
    "ip", "mac", "gateway", "netmask", "poe_used", "poe_remaining", "poe_budget",
  ]);
  const OVERVIEW_FIELD_SET = new Set(DEFAULT_OVERVIEW_FIELDS);
  const OVERVIEW_LAYOUTS = new Set(["tiles", "compact", "hidden"]);
  const MAX_LABEL_LENGTH = 40;

  // PoE consumption sparkline (issue #14). Bucketed to a fixed point count
  // rather than plotting every raw history row — a 7-day window at the
  // underlying integration's default 30s poll interval could otherwise mean
  // ~20000 points in one SVG path.
  const DEFAULT_POE_HISTORY_HOURS = 24;
  const MAX_POE_HISTORY_HOURS = 24 * 7;
  const POE_HISTORY_BUCKETS = 120;
  // Floor on how often we hit the History API, independent of how often the
  // hass tick fires — protects against a user-configured tplink_easy_smart
  // scan_interval shorter than the default 30s.
  const POE_HISTORY_MIN_REFRESH_MS = 20000;

  const DEFAULT_LANG = "en";

  // Every UI string this file's card + editor render, keyed by BCP-47
  // primary language subtag. Bundled inline (not fetched from separate
  // translations/<lang>.json files) — see root CLAUDE.md's Kortkonventioner
  // for why: HACS's plugin category only ever distributes the one file
  // named in hacs.json, so extra files never reach a real install.
  // POE_PRIORITIES / POE_POWER_LIMITS values above are NOT translated here —
  // they are real tplink_easy_smart service parameters, not display text.
  const TRANSLATIONS = {
    en: {
      title_default: "TP-Link Switch",
      word_up: "Up",
      word_down: "Down",
      poe_badge_on: "PoE",
      poe_badge_off: "no PoE",
      ov_label_ip: "IP address",
      ov_label_mac: "MAC",
      ov_label_gateway: "Gateway",
      ov_label_netmask: "Netmask",
      ov_label_poe_used: "PoE used",
      ov_label_poe_remaining: "PoE remaining",
      ov_label_poe_budget: "PoE budget",
      switch_ui_title: "Open switch UI",
      limit_max_suffix: "max {max} W",
      btn_set: "Set",
      btn_cancel: "Cancel",
      btn_applying: "Applying…",
      limit_error_zero: "Enter a value greater than 0",
      limit_error_max: "Cannot exceed hardware max of {max} W",
      pencil_title: "Edit PoE budget limit",
      section_poe_ports: "PoE ports 1–{to}",
      stat_total: "Total",
      stat_of: "of",
      spark_ago: "-{h}h",
      spark_now: "now",
      section_ports: "Ports {from}–{to}",
      pill_up: "{up} / {total} up",
      pill_poe: "{active} PoE · {watts} W",
      port_word: "Port",
      details_word: "details",
      d_label_speed: "Speed",
      d_label_configured: "Configured",
      d_label_power: "Power",
      d_label_current: "Current",
      d_label_voltage: "Voltage",
      d_label_pd_class: "PD class",
      d_label_priority: "Priority",
      d_label_limit: "Limit",
      d_label_poe_enabled: "PoE enabled",
      d_label_port_enabled: "Port enabled",
      d_label_label: "Label",
      label_placeholder: "Port name",
      btn_save: "Save",
      btn_saving: "Saving…",
      btn_configure_poe: "Configure PoE",
      configure_title: "Port {port} — PoE Settings",
      cfg_label_power_limit: "Power limit",
      btn_apply: "Apply",
      placeholder_waiting: "Waiting for Home Assistant…",
      aria_poe_enabled: "PoE enabled for port {port}",
      aria_port_enabled: "Port {port} enabled",
      editor_title: "Title",
      editor_entity_prefix: "Entity prefix",
      editor_has_poe: "Switch has PoE",
      editor_poe_ports: "Number of PoE ports",
      editor_max_poe_watts: "Hardware PoE max (W)",
      editor_poe_history_hours: "PoE history window (hours)",
      editor_total_ports: "Total ports",
      editor_overview_layout: "Overview layout",
      editor_overview_fields: "Overview fields",
      editor_show_switch_link: "Show switch web-UI link",
      editor_font_scale: "Font scale",
      editor_editable_labels: "Allow inline label editing",
      editor_layout_tiles: "Tiles",
      editor_layout_compact: "Compact",
      editor_layout_hidden: "Hidden",
      editor_field_ip: "IP address",
      editor_field_mac: "MAC address",
      editor_field_gateway: "Gateway",
      editor_field_netmask: "Netmask",
      editor_field_poe_used: "PoE used",
      editor_field_poe_remaining: "PoE remaining",
      editor_field_poe_budget: "PoE budget bar",
    },
    sv: {
      title_default: "TP-Link-switch",
      word_up: "Uppe",
      word_down: "Nere",
      poe_badge_on: "PoE",
      poe_badge_off: "ingen PoE",
      ov_label_ip: "IP-adress",
      ov_label_mac: "MAC",
      ov_label_gateway: "Gateway",
      ov_label_netmask: "Nätmask",
      ov_label_poe_used: "PoE använt",
      ov_label_poe_remaining: "PoE kvar",
      ov_label_poe_budget: "PoE-budget",
      switch_ui_title: "Öppna switchens gränssnitt",
      limit_max_suffix: "max {max} W",
      btn_set: "Sätt",
      btn_cancel: "Avbryt",
      btn_applying: "Tillämpar…",
      limit_error_zero: "Ange ett värde större än 0",
      limit_error_max: "Kan inte överstiga hårdvarumax {max} W",
      pencil_title: "Redigera PoE-budgetgräns",
      section_poe_ports: "PoE-portar 1–{to}",
      stat_total: "Totalt",
      stat_of: "av",
      spark_ago: "-{h}h",
      spark_now: "nu",
      section_ports: "Portar {from}–{to}",
      pill_up: "{up} / {total} uppe",
      pill_poe: "{active} PoE · {watts} W",
      port_word: "Port",
      details_word: "detaljer",
      d_label_speed: "Hastighet",
      d_label_configured: "Konfigurerad",
      d_label_power: "Effekt",
      d_label_current: "Ström",
      d_label_voltage: "Spänning",
      d_label_pd_class: "PD-klass",
      d_label_priority: "Prioritet",
      d_label_limit: "Gräns",
      d_label_poe_enabled: "PoE aktiverad",
      d_label_port_enabled: "Port aktiverad",
      d_label_label: "Etikett",
      label_placeholder: "Portnamn",
      btn_save: "Spara",
      btn_saving: "Sparar…",
      btn_configure_poe: "Konfigurera PoE",
      configure_title: "Port {port} — PoE-inställningar",
      cfg_label_power_limit: "Effektgräns",
      btn_apply: "Tillämpa",
      placeholder_waiting: "Väntar på Home Assistant…",
      aria_poe_enabled: "PoE aktiverad för port {port}",
      aria_port_enabled: "Port {port} aktiverad",
      editor_title: "Titel",
      editor_entity_prefix: "Entitetsprefix",
      editor_has_poe: "Switchen har PoE",
      editor_poe_ports: "Antal PoE-portar",
      editor_max_poe_watts: "Hårdvarans PoE-max (W)",
      editor_poe_history_hours: "PoE-historikfönster (timmar)",
      editor_total_ports: "Totalt antal portar",
      editor_overview_layout: "Översiktslayout",
      editor_overview_fields: "Översiktsfält",
      editor_show_switch_link: "Visa länk till switchens webb-UI",
      editor_font_scale: "Textskala",
      editor_editable_labels: "Tillåt redigering av etiketter direkt i kortet",
      editor_layout_tiles: "Rutor",
      editor_layout_compact: "Kompakt",
      editor_layout_hidden: "Dold",
      editor_field_ip: "IP-adress",
      editor_field_mac: "MAC-adress",
      editor_field_gateway: "Gateway",
      editor_field_netmask: "Nätmask",
      editor_field_poe_used: "PoE använt",
      editor_field_poe_remaining: "PoE kvar",
      editor_field_poe_budget: "PoE-budgetbalk",
    },
    de: {
      title_default: "TP-Link-Switch",
      word_up: "Verbunden",
      word_down: "Getrennt",
      poe_badge_on: "PoE",
      poe_badge_off: "kein PoE",
      ov_label_ip: "IP-Adresse",
      ov_label_mac: "MAC",
      ov_label_gateway: "Gateway",
      ov_label_netmask: "Netzmaske",
      ov_label_poe_used: "PoE genutzt",
      ov_label_poe_remaining: "PoE verbleibend",
      ov_label_poe_budget: "PoE-Budget",
      switch_ui_title: "Switch-Oberfläche öffnen",
      limit_max_suffix: "max {max} W",
      btn_set: "Setzen",
      btn_cancel: "Abbrechen",
      btn_applying: "Wird angewendet…",
      limit_error_zero: "Geben Sie einen Wert größer als 0 ein",
      limit_error_max: "Darf das Hardware-Maximum von {max} W nicht überschreiten",
      pencil_title: "PoE-Budgetgrenze bearbeiten",
      section_poe_ports: "PoE-Ports 1–{to}",
      stat_total: "Gesamt",
      stat_of: "von",
      spark_ago: "-{h}h",
      spark_now: "jetzt",
      section_ports: "Ports {from}–{to}",
      pill_up: "{up} / {total} verbunden",
      pill_poe: "{active} PoE · {watts} W",
      port_word: "Port",
      details_word: "Details",
      d_label_speed: "Geschwindigkeit",
      d_label_configured: "Konfiguriert",
      d_label_power: "Leistung",
      d_label_current: "Strom",
      d_label_voltage: "Spannung",
      d_label_pd_class: "PD-Klasse",
      d_label_priority: "Priorität",
      d_label_limit: "Grenze",
      d_label_poe_enabled: "PoE aktiviert",
      d_label_port_enabled: "Port aktiviert",
      d_label_label: "Bezeichnung",
      label_placeholder: "Portname",
      btn_save: "Speichern",
      btn_saving: "Wird gespeichert…",
      btn_configure_poe: "PoE konfigurieren",
      configure_title: "Port {port} — PoE-Einstellungen",
      cfg_label_power_limit: "Leistungsgrenze",
      btn_apply: "Übernehmen",
      placeholder_waiting: "Warte auf Home Assistant…",
      aria_poe_enabled: "PoE aktiviert für Port {port}",
      aria_port_enabled: "Port {port} aktiviert",
      editor_title: "Titel",
      editor_entity_prefix: "Entitätspräfix",
      editor_has_poe: "Switch hat PoE",
      editor_poe_ports: "Anzahl PoE-Ports",
      editor_max_poe_watts: "Hardware-PoE-Maximum (W)",
      editor_poe_history_hours: "PoE-Verlaufsfenster (Stunden)",
      editor_total_ports: "Ports gesamt",
      editor_overview_layout: "Übersichtslayout",
      editor_overview_fields: "Übersichtsfelder",
      editor_show_switch_link: "Link zur Switch-Web-UI anzeigen",
      editor_font_scale: "Schriftskalierung",
      editor_editable_labels: "Inline-Bearbeitung von Bezeichnungen erlauben",
      editor_layout_tiles: "Kacheln",
      editor_layout_compact: "Kompakt",
      editor_layout_hidden: "Ausgeblendet",
      editor_field_ip: "IP-Adresse",
      editor_field_mac: "MAC-Adresse",
      editor_field_gateway: "Gateway",
      editor_field_netmask: "Netzmaske",
      editor_field_poe_used: "PoE genutzt",
      editor_field_poe_remaining: "PoE verbleibend",
      editor_field_poe_budget: "PoE-Budgetbalken",
    },
    fr: {
      title_default: "Switch TP-Link",
      word_up: "Connecté",
      word_down: "Déconnecté",
      poe_badge_on: "PoE",
      poe_badge_off: "pas de PoE",
      ov_label_ip: "Adresse IP",
      ov_label_mac: "MAC",
      ov_label_gateway: "Passerelle",
      ov_label_netmask: "Masque de sous-réseau",
      ov_label_poe_used: "PoE utilisé",
      ov_label_poe_remaining: "PoE restant",
      ov_label_poe_budget: "Budget PoE",
      switch_ui_title: "Ouvrir l'interface du switch",
      limit_max_suffix: "max {max} W",
      btn_set: "Définir",
      btn_cancel: "Annuler",
      btn_applying: "Application…",
      limit_error_zero: "Entrez une valeur supérieure à 0",
      limit_error_max: "Ne peut pas dépasser le maximum matériel de {max} W",
      pencil_title: "Modifier la limite du budget PoE",
      section_poe_ports: "Ports PoE 1–{to}",
      stat_total: "Total",
      stat_of: "sur",
      spark_ago: "-{h}h",
      spark_now: "maintenant",
      section_ports: "Ports {from}–{to}",
      pill_up: "{up} / {total} connectés",
      pill_poe: "{active} PoE · {watts} W",
      port_word: "Port",
      details_word: "détails",
      d_label_speed: "Vitesse",
      d_label_configured: "Configuré",
      d_label_power: "Puissance",
      d_label_current: "Courant",
      d_label_voltage: "Tension",
      d_label_pd_class: "Classe PD",
      d_label_priority: "Priorité",
      d_label_limit: "Limite",
      d_label_poe_enabled: "PoE activé",
      d_label_port_enabled: "Port activé",
      d_label_label: "Étiquette",
      label_placeholder: "Nom du port",
      btn_save: "Enregistrer",
      btn_saving: "Enregistrement…",
      btn_configure_poe: "Configurer PoE",
      configure_title: "Port {port} — Paramètres PoE",
      cfg_label_power_limit: "Limite de puissance",
      btn_apply: "Appliquer",
      placeholder_waiting: "En attente de Home Assistant…",
      aria_poe_enabled: "PoE activé pour le port {port}",
      aria_port_enabled: "Port {port} activé",
      editor_title: "Titre",
      editor_entity_prefix: "Préfixe d'entité",
      editor_has_poe: "Le switch a du PoE",
      editor_poe_ports: "Nombre de ports PoE",
      editor_max_poe_watts: "Maximum PoE matériel (W)",
      editor_poe_history_hours: "Fenêtre d'historique PoE (heures)",
      editor_total_ports: "Nombre total de ports",
      editor_overview_layout: "Disposition de l'aperçu",
      editor_overview_fields: "Champs de l'aperçu",
      editor_show_switch_link: "Afficher le lien vers l'interface web du switch",
      editor_font_scale: "Échelle de police",
      editor_editable_labels: "Autoriser l'édition des étiquettes en ligne",
      editor_layout_tiles: "Tuiles",
      editor_layout_compact: "Compact",
      editor_layout_hidden: "Masqué",
      editor_field_ip: "Adresse IP",
      editor_field_mac: "Adresse MAC",
      editor_field_gateway: "Passerelle",
      editor_field_netmask: "Masque de sous-réseau",
      editor_field_poe_used: "PoE utilisé",
      editor_field_poe_remaining: "PoE restant",
      editor_field_poe_budget: "Barre de budget PoE",
    },
  };

  /** Resolves the HA-configured language to one of our translated languages, falling back to English. */
  function _lang(hass) {
    const raw = (hass?.locale?.language || hass?.language || DEFAULT_LANG).toLowerCase();
    const primary = raw.split("-")[0];
    return TRANSLATIONS[primary] ? primary : DEFAULT_LANG;
  }

  /** Looks up a UI string in the current language, with {placeholder} substitution. */
  function _t(hass, key, replacements) {
    const dict = TRANSLATIONS[_lang(hass)] || TRANSLATIONS[DEFAULT_LANG];
    const raw = dict[key] ?? TRANSLATIONS[DEFAULT_LANG][key] ?? key;
    if (!replacements) return raw;
    return raw.replace(/\{([^}]+)\}/g, (match, k) =>
      Object.prototype.hasOwnProperty.call(replacements, k) ? replacements[k] : match
    );
  }

  class TplinkSwitchCard extends HTMLElement {
    constructor() {
      super();
      this._expanded      = new Set(); // ports with open detail row
      this._configuring   = new Set(); // ports with open configure panel
      this._editingLimit  = false;     // overview PoE limit editor open
      this._portEntitiesCache = new Map();

      // PoE consumption sparkline (issue #14)
      this._poeHistoryBuckets   = null;  // { values: number[], purged: bool } | null
      this._poeHistoryFetchedAt = 0;
      this._poeHistoryFetching  = false;
      this._poeHistoryConfigKey = null;

      // Pending configure values — keyed by port
      this._pendingPoe    = new Map(); // port → { priority, power_limit }
      this._pendingLimit  = "";        // draft global PoE limit
      this._applying      = new Set(); // ports currently awaiting service call
      this._applyingLimit = false;

      // Label editing
      this._labelDrafts   = new Map(); // port → unsaved input text (survives re-renders)
      this._savingLabel   = new Set(); // ports currently persisting a label
      this._localLabelsCache = null;   // per-render cache of localStorage overrides
    }

    setConfig(config) {
      if (!config) throw new Error("Missing configuration");
      this._rawConfig = config; // untouched original — used to locate this card in the Lovelace config
      this.config = {
        title: null,
        has_poe: true,
        poe_ports: 8,
        total_ports: 16,
        entity_prefix: "tp_link_switch",
        max_poe_watts: null,
        poe_history_hours: DEFAULT_POE_HISTORY_HOURS,
        overview_layout: "tiles",
        overview_fields: [...DEFAULT_OVERVIEW_FIELDS],
        show_switch_link: true,
        port_labels: {},
        editable_labels: true,
        font_scale: 1,
        ...config,
      };
      this.config.has_poe = this.config.has_poe !== false;
      if (!this.config.has_poe) this.config.poe_ports = 0;

      const historyHours = Number(this.config.poe_history_hours);
      this.config.poe_history_hours = Number.isFinite(historyHours)
        ? Math.min(MAX_POE_HISTORY_HOURS, Math.max(1, Math.round(historyHours)))
        : DEFAULT_POE_HISTORY_HOURS;

      if (!OVERVIEW_LAYOUTS.has(this.config.overview_layout)) {
        this.config.overview_layout = "tiles";
      }

      const scale = Number(this.config.font_scale);
      this.config.font_scale = Number.isFinite(scale)
        ? Math.min(2, Math.max(0.7, scale))
        : 1;
      this.config.editable_labels = this.config.editable_labels !== false;

      const requestedOverviewFields = Array.isArray(this.config.overview_fields)
        ? this.config.overview_fields
        : DEFAULT_OVERVIEW_FIELDS;
      this.config.overview_fields = [...new Set(
        requestedOverviewFields.filter(field => OVERVIEW_FIELD_SET.has(field))
      )];
      this.config.show_switch_link = this.config.show_switch_link !== false;

      const requestedPortLabels = this.config.port_labels;
      const portLabels = {};
      if (requestedPortLabels && typeof requestedPortLabels === "object" && !Array.isArray(requestedPortLabels)) {
        Object.entries(requestedPortLabels).forEach(([key, rawLabel]) => {
          const port = Number(key);
          if (!Number.isInteger(port) || port < 1 || port > this.config.total_ports || rawLabel == null) return;
          const label = String(rawLabel).trim();
          if (label) portLabels[port] = label;
        });
      }
      this.config.port_labels = portLabels;

      this._portEntitiesCache.clear();
      // Only depends on entity_prefix/has_poe/total_ports/poe_ports, all fixed
      // above — recompute once per config change instead of on every hass tick.
      this._watchedEntitiesCache = this._watchedEntities();

      // Editing an unrelated field (title, a port label, ...) re-runs setConfig
      // too — only wipe the cached history when something that actually
      // changes the History API query changed, or we'd refetch on every
      // keystroke in the visual editor.
      const poeHistoryKey = `${this.config.entity_prefix}|${this.config.has_poe}|${this.config.poe_history_hours}`;
      if (poeHistoryKey !== this._poeHistoryConfigKey) {
        this._poeHistoryConfigKey = poeHistoryKey;
        this._poeHistoryBuckets = null;
        this._poeHistoryFetchedAt = 0;
      }

      this.render();
    }

    set hass(hass) {
      const old = this._hass;
      this._hass = hass;
      if (old && !this._statesChanged(old, hass)) return;
      this.render();
    }

    connectedCallback() { this.render(); }

    static getConfigElement() {
      return document.createElement(`${CARD_NAME}-editor`);
    }

    static getStubConfig() {
      return { type: `custom:${CARD_NAME}`, entity_prefix: "tp_link_switch" };
    }

    getCardSize() {
      const baseSize = this.config?.has_poe === false ? 5 : 7;
      const overviewHidden = this.config?.overview_layout === "hidden" ||
        this.config?.overview_fields?.length === 0;
      return Math.max(3, baseSize - (overviewHidden ? 1 : 0));
    }

    // ── Change detection ──────────────────────────────────────────────────────

    _watchedEntities() {
      if (!this.config) return [];
      const p = this.config.entity_prefix;
      const ids = [`sensor.${p}_network_info`];
      if (this.config.has_poe) ids.push(`sensor.${p}_poe_consumption`);
      for (let i = 1; i <= this.config.total_ports; i++) {
        ids.push(`binary_sensor.${p}_port_${i}_state`);
        if (this.config.has_poe && i <= this.config.poe_ports) {
          ids.push(`binary_sensor.${p}_port_${i}_poe_state`);
          ids.push(`switch.${p}_port_${i}_poe_enabled`);
        }
        ids.push(`switch.${p}_port_${i}_enabled`);
      }
      return ids;
    }

    _statesChanged(oldHass, newHass) {
      const ids = this._watchedEntitiesCache || this._watchedEntities();
      return ids.some(id => {
        const o = oldHass.states[id];
        const n = newHass.states[id];
        if (o?.state !== n?.state) return true;
        const oa = o?.attributes ?? {};
        const na = n?.attributes ?? {};
        return oa.power_w !== na.power_w ||
               oa.current_ma !== na.current_ma ||
               oa.voltage_v !== na.voltage_v ||
               oa.speed !== na.speed ||
               oa.speed_config !== na.speed_config ||
               oa.priority !== na.priority ||
               oa.power_limit !== na.power_limit ||
               oa.power_limit_w !== na.power_limit_w ||
               oa.power_remain_w !== na.power_remain_w;
      });
    }

    // ── Entity helpers ────────────────────────────────────────────────────────

    _escapeHtml(value) {
      return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
    }

    // Scaled font size — base rem value multiplied by config font_scale
    _fs(rem) {
      const s = this.config?.font_scale ?? 1;
      return `${+(rem * s).toFixed(3)}rem`;
    }

    _e(entityId) { return this._hass?.states[entityId] ?? null; }

    _getMacAddress() {
      const pfx  = this.config.entity_prefix;
      const netS = this._e(`sensor.${pfx}_network_info`);
      return netS?.attributes?.mac ?? null;
    }

    _getSwitchUrl() {
      const pfx  = this.config.entity_prefix;
      const netS = this._e(`sensor.${pfx}_network_info`);
      const ip   = netS?.state;
      if (!ip || ip === "unknown" || ip === "unavailable") return null;
      return `http://${ip}`;
    }

    _portEntities(port) {
      if (this._portEntitiesCache.has(port)) return this._portEntitiesCache.get(port);
      const p      = this.config.entity_prefix;
      const hasPoe = this.config.has_poe && port <= this.config.poe_ports;
      const entities = {
        state:       this._e(`binary_sensor.${p}_port_${port}_state`),
        poeState:    hasPoe ? this._e(`binary_sensor.${p}_port_${port}_poe_state`) : null,
        poeEnabled:  hasPoe ? this._e(`switch.${p}_port_${port}_poe_enabled`) : null,
        portEnabled: this._e(`switch.${p}_port_${port}_enabled`),
      };
      this._portEntitiesCache.set(port, entities);
      return entities;
    }

    // ── Port labels ───────────────────────────────────────────────────────────

    _labelStorageKey() {
      const id = this._getMacAddress() ?? this.config.entity_prefix;
      return `${CARD_NAME}:labels:${id}`;
    }

    _localLabels() {
      if (this._localLabelsCache) return this._localLabelsCache;
      let labels = {};
      try {
        const raw = localStorage.getItem(this._labelStorageKey());
        const parsed = raw ? JSON.parse(raw) : {};
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) labels = parsed;
      } catch (err) {
        console.warn("tplink-switch-card: could not read local labels", err);
      }
      this._localLabelsCache = labels;
      return labels;
    }

    _writeLocalLabels(labels) {
      this._localLabelsCache = null;
      try {
        if (Object.keys(labels).length === 0) {
          localStorage.removeItem(this._labelStorageKey());
        } else {
          localStorage.setItem(this._labelStorageKey(), JSON.stringify(labels));
        }
      } catch (err) {
        console.warn("tplink-switch-card: could not write local labels", err);
      }
    }

    // Effective label: localStorage override (may be "" = removed) wins over config
    _effectiveLabel(port) {
      const local = this._localLabels();
      const value = Object.prototype.hasOwnProperty.call(local, port)
        ? local[port]
        : this.config.port_labels?.[port];
      return value ? String(value) : "";
    }

    // Locate the hui-root lovelace object by walking the HA DOM
    _getLovelace() {
      try {
        let node = document.querySelector("home-assistant");
        node = node?.shadowRoot?.querySelector("home-assistant-main");
        node = node?.shadowRoot;
        node = node?.querySelector("ha-drawer partial-panel-resolver")
            ?? node?.querySelector("partial-panel-resolver")
            ?? node?.querySelector("app-drawer-layout partial-panel-resolver");
        node = (node?.shadowRoot ?? node)?.querySelector("ha-panel-lovelace");
        node = node?.shadowRoot?.querySelector("hui-root");
        return node?.lovelace ?? null;
      } catch (err) {
        return null;
      }
    }

    // Recursively collect all tplink-switch-card configs inside a Lovelace config tree
    _collectCardConfigs(node, matches) {
      if (!node || typeof node !== "object") return;
      if (Array.isArray(node)) {
        node.forEach(item => this._collectCardConfigs(item, matches));
        return;
      }
      if (node.type === `custom:${CARD_NAME}`) matches.push(node);
      ["views", "sections", "cards", "card", "rows", "elements"].forEach(key => {
        if (node[key]) this._collectCardConfigs(node[key], matches);
      });
    }

    /*
     * Persist labels into the dashboard config via lovelace.saveConfig.
     * Returns true on success. Fails gracefully (→ localStorage fallback) when:
     *   - the dashboard runs in YAML mode
     *   - the card cannot be uniquely located in the config
     *   - the HA DOM layout changed and hui-root is not found
     */
    async _persistLabelsToLovelace(labels) {
      const lovelace = this._getLovelace();
      if (!lovelace || lovelace.mode !== "storage" || typeof lovelace.saveConfig !== "function") {
        return false;
      }
      const target = JSON.stringify(this._rawConfig ?? {});
      const cloned = JSON.parse(JSON.stringify(lovelace.config));
      const matches = [];
      this._collectCardConfigs(cloned, matches);
      const found = matches.filter(card => JSON.stringify(card) === target);
      if (found.length !== 1) {
        console.warn(`tplink-switch-card: found ${found.length} matching card config(s); falling back to local label storage`);
        return false;
      }
      if (Object.keys(labels).length > 0) {
        found[0].port_labels = labels;
      } else {
        delete found[0].port_labels;
      }
      await lovelace.saveConfig(cloned);
      return true;
    }

    async _saveLabel(port, rawValue) {
      const value = String(rawValue ?? "").trim().slice(0, MAX_LABEL_LENGTH);
      if (value === this._effectiveLabel(port)) {
        this._labelDrafts.delete(port);
        this.render();
        return;
      }

      // Full desired label set = config labels + local overrides + this change
      const merged = { ...this.config.port_labels };
      const local = this._localLabels();
      Object.entries(local).forEach(([p, v]) => {
        if (v) merged[p] = v; else delete merged[p];
      });
      if (value) merged[port] = value; else delete merged[port];

      this._savingLabel.add(port);
      this.render();

      let saved = false;
      try {
        saved = await this._persistLabelsToLovelace(merged);
      } catch (err) {
        console.warn("tplink-switch-card: saving label to dashboard failed", err);
      }

      this._savingLabel.delete(port);
      this._labelDrafts.delete(port);

      if (saved) {
        // Dashboard config now holds every label — local overrides are obsolete
        this._writeLocalLabels({});
        this.config.port_labels = merged; // instant UI update; setConfig follows from HA
      } else {
        const updatedLocal = { ...this._localLabels() };
        if (value) {
          updatedLocal[port] = value;
        } else if (this.config.port_labels?.[port]) {
          updatedLocal[port] = ""; // override config label with "removed"
        } else {
          delete updatedLocal[port];
        }
        this._writeLocalLabels(updatedLocal);
      }
      this.render();
    }

    // ── Service calls ─────────────────────────────────────────────────────────

    _toggle(entityId) {
      if (!this._hass || !entityId) return;
      const e = this._hass.states[entityId];
      if (!e) return;
      const domain = entityId.split(".")[0];
      this._hass.callService(domain, e.state === "on" ? "turn_off" : "turn_on", { entity_id: entityId });
    }

    async _applyPortPoe(port) {
      const pending = this._pendingPoe.get(port);
      if (!pending || !this._hass) return;
      this._applying.add(port);
      this.render();
      try {
        const poeEnt = this._portEntities(port);
        const isEnabled = poeEnt.poeEnabled?.state === "on";
        await this._hass.callService("tplink_easy_smart", "set_port_poe_settings", {
          mac_address: this._getMacAddress(),
          port_number: port,
          enabled: isEnabled,
          priority: pending.priority,
          power_limit: pending.power_limit,
        });
      } catch (err) {
        console.error("tplink-switch-card: set_port_poe_settings failed", err);
      } finally {
        this._applying.delete(port);
        this._configuring.delete(port);
        this._pendingPoe.delete(port);
        this.render();
      }
    }

    _showLimitError(msg) {
      const el = this.querySelector("#poe-limit-error");
      const input = this.querySelector("#poe-limit-input");
      if (el) { el.textContent = msg; el.style.display = "inline"; }
      if (input) input.style.borderColor = "var(--error-color, #c22040)";
    }

    _clearLimitError() {
      const el = this.querySelector("#poe-limit-error");
      const input = this.querySelector("#poe-limit-input");
      if (el) { el.textContent = ""; el.style.display = "none"; }
      if (input) input.style.borderColor = "";
    }

    async _applyPoeLimitGlobal() {
      // Read current value directly from DOM so we don't need a re-render
      const inputEl = this.querySelector("#poe-limit-input");
      if (inputEl) this._pendingLimit = inputEl.value;

      const val  = parseFloat(this._pendingLimit);
      const maxW = this.config.max_poe_watts;

      if (isNaN(val) || val <= 0) {
        this._showLimitError(_t(this._hass, "limit_error_zero"));
        return;
      }
      if (maxW && val > maxW) {
        this._showLimitError(_t(this._hass, "limit_error_max", { max: maxW }));
        return;
      }
      if (!this._hass) return;
      this._clearLimitError();
      this._applyingLimit = true;
      this.render();
      try {
        await this._hass.callService("tplink_easy_smart", "set_general_poe_limit", {
          mac_address: this._getMacAddress(),
          power_limit: val,
        });
      } catch (err) {
        console.error("tplink-switch-card: set_general_poe_limit failed", err);
      } finally {
        this._applyingLimit = false;
        this._editingLimit = false;
        this._pendingLimit = "";
        this.render();
      }
    }

    // ── Expand / configure state ──────────────────────────────────────────────

    _toggleExpand(port) {
      if (this._expanded.has(port)) {
        this._expanded.delete(port);
        this._configuring.delete(port);
        this._pendingPoe.delete(port);
        this._labelDrafts.delete(port);
      } else {
        this._expanded.add(port);
      }
      this.render();
    }

    _openConfigure(port) {
      const ent  = this._portEntities(port);
      const attr = ent.poeState?.attributes ?? {};
      // Pre-fill with current values from entity
      this._pendingPoe.set(port, {
        priority:    attr.priority    ?? POE_PRIORITIES[0],
        power_limit: attr.power_limit ?? POE_POWER_LIMITS[0],
      });
      this._configuring.add(port);
      this.render();
    }

    _cancelConfigure(port) {
      this._configuring.delete(port);
      this._pendingPoe.delete(port);
      this.render();
    }

    // ── CSS ───────────────────────────────────────────────────────────────────

    _css() {
      const fs = v => this._fs(v);
      return `
        :host { display: block; }
        * { box-sizing: border-box; }
        .card {
          background: var(--ha-card-background, var(--card-background-color));
          border-radius: var(--ha-card-border-radius, 12px);
          box-shadow: var(--ha-card-box-shadow, none);
          padding: 1rem 1.25rem 1.25rem;
          color: var(--primary-text-color);
          font-family: var(--primary-font-family, inherit);
        }

        /* ── Header ── */
        .card-header {
          display: flex; align-items: center;
          justify-content: space-between; margin-bottom: 0.9rem;
        }
        .card-title { font-size: ${fs(1.1)}; font-weight: 700; }
        .summary-pills { display: flex; gap: 0.4rem; flex-wrap: wrap; }
        .pill {
          font-size: ${fs(0.7)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.07em;
          padding: 0.18rem 0.55rem; border-radius: 999px;
          background: var(--secondary-background-color);
          color: var(--secondary-text-color);
          border: 1px solid var(--divider-color, rgba(128,128,128,0.2));
          white-space: nowrap;
        }
        .pill.up  { background: rgba(46,143,87,0.13); color: var(--success-color, #2e8f57); border-color: rgba(46,143,87,0.28); }
        .pill.poe { background: rgba(3,169,244,0.1); color: var(--primary-color,#03a9f4); border-color: rgba(3,169,244,0.28); }

        /* ── Overview ── */
        .overview {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
          gap: 0.4rem; margin-bottom: 1rem;
        }
        .overview.compact {
          display: flex; flex-wrap: wrap; align-items: stretch;
          gap: 0.35rem; padding: 0.45rem; margin-bottom: 1rem;
          background: var(--secondary-background-color, rgba(128,128,128,0.06));
          border: 1px solid var(--divider-color, rgba(128,128,128,0.14));
          border-radius: 8px;
        }
        .overview.compact .ov-item {
          flex: 1 1 145px; min-width: 0;
          flex-direction: row; align-items: center; justify-content: space-between;
          gap: 0.6rem; padding: 0.35rem 0.5rem;
          background: transparent; border: none; border-radius: 6px;
        }
        .overview.compact .ov-item.copyable:hover {
          background: var(--secondary-background-color, rgba(128,128,128,0.08));
        }
        .overview.compact .ov-item.copyable:hover .ov-label::after,
        .overview.compact .ov-item.copied .ov-label::after {
          content: none;
        }
        .overview.compact .ov-label { flex-shrink: 0; }
        .overview.compact .ov-value { text-align: right; }
        .overview.compact .ov-value-row { margin-left: auto; min-width: 0; }
        .overview.compact .poe-bar-wrap {
          flex: 1 0 100%;
          border: none;
          border-top: 1px solid var(--divider-color, rgba(128,128,128,0.14));
          border-radius: 0;
          padding: 0.55rem 0.5rem 0.2rem;
        }
        .ov-item {
          background: var(--secondary-background-color, rgba(128,128,128,0.06));
          border: 1px solid var(--divider-color, rgba(128,128,128,0.14));
          border-radius: 8px; padding: 0.45rem 0.6rem;
          display: flex; flex-direction: column; gap: 0.12rem;
        }
        .ov-label {
          font-size: ${fs(0.64)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.08em;
          color: var(--secondary-text-color);
        }
        .ov-value {
          font-size: ${fs(0.9)}; font-weight: 600;
          color: var(--primary-text-color);
          font-variant-numeric: tabular-nums;
          overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }
        .ov-value.poe    { color: var(--primary-color, #03a9f4); }
        .ov-value.remain { color: var(--success-color, #2e8f57); }

        /* Copyable overview tiles */
        .ov-item.copyable { cursor: pointer; transition: border-color 0.15s ease; }
        .ov-item.copyable:hover { border-color: var(--primary-color, #03a9f4); }
        .ov-item.copyable:hover .ov-label::after {
          content: " · click to copy";
          font-weight: 400; opacity: 0.7; text-transform: none; letter-spacing: 0;
        }
        .ov-item.copied { border-color: var(--success-color, #2e8f57) !important; }
        .ov-item.copied .ov-label::after {
          content: " · copied!";
          color: var(--success-color, #2e8f57); font-weight: 400; text-transform: none; letter-spacing: 0;
        }

        /* Switch UI link */
        .ui-link {
          display: inline-flex; align-items: center; justify-content: center;
          width: 1.3rem; height: 1.3rem; border-radius: 4px;
          color: var(--secondary-text-color);
          background: none; border: none; cursor: pointer; padding: 0;
          transition: color 0.15s ease; text-decoration: none; flex-shrink: 0;
        }
        .ui-link:hover { color: var(--primary-color, #03a9f4); }
        .ov-value-row { display: flex; align-items: center; gap: 0.3rem; }

        /* PoE budget bar */
        .poe-bar-wrap {
          grid-column: 1 / -1;
          background: var(--secondary-background-color, rgba(128,128,128,0.06));
          border: 1px solid var(--divider-color, rgba(128,128,128,0.14));
          border-radius: 8px; padding: 0.45rem 0.6rem;
        }
        .poe-bar-header {
          display: flex; justify-content: space-between;
          align-items: center; margin-bottom: 0.35rem;
        }
        .poe-bar-track {
          height: 5px; border-radius: 999px;
          background: var(--divider-color, rgba(128,128,128,0.2)); overflow: hidden;
        }
        .poe-bar-fill {
          height: 100%; border-radius: 999px;
          background: var(--primary-color, #03a9f4);
          transition: width 0.4s ease;
        }
        .poe-spark-wrap { margin-top: 0.4rem; }
        .poe-spark { display: block; width: 100%; height: 22px; }
        .poe-spark-foot {
          display: flex; justify-content: space-between; margin-top: 0.15rem;
          font-size: ${fs(0.62)}; color: var(--secondary-text-color);
          font-variant-numeric: tabular-nums;
        }

        /* Limit editor */
        .limit-editor {
          display: flex; align-items: center; gap: 0.4rem;
          margin-top: 0.45rem; flex-wrap: wrap;
        }
        .limit-input {
          width: 5rem; font-size: ${fs(0.85)};
          padding: 0.2rem 0.4rem; border-radius: 5px;
          border: 1px solid var(--primary-color, #03a9f4);
          background: var(--secondary-background-color);
          color: var(--primary-text-color);
          font-variant-numeric: tabular-nums;
        }
        .limit-input:focus { outline: none; border-color: var(--primary-color); }
        .limit-unit { font-size: ${fs(0.78)}; color: var(--secondary-text-color); }
        .edit-pencil {
          background: none; border: none; cursor: pointer;
          color: var(--secondary-text-color); padding: 0 0.2rem;
          font-size: ${fs(0.8)}; line-height: 1;
          transition: color 0.15s ease;
        }
        .edit-pencil:hover { color: var(--primary-color); }

        /* ── Section ── */
        .section { margin-bottom: 0.75rem; }
        .section:last-child { margin-bottom: 0; }
        .section-header {
          display: flex; align-items: center; gap: 0.5rem;
          margin-bottom: 0.35rem; padding-bottom: 0.3rem;
          border-bottom: 1px solid var(--divider-color, rgba(128,128,128,0.14));
        }
        .section-label {
          font-size: ${fs(0.7)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.1em;
          color: var(--secondary-text-color); flex: 1;
        }
        .section-stat { font-size: ${fs(0.7)}; color: var(--secondary-text-color); font-variant-numeric: tabular-nums; }
        .section-stat span { color: var(--primary-color, #03a9f4); font-weight: 600; }

        /* ── Port table ── */
        .port-table { width: 100%; border-collapse: collapse; }
        .port-row td {
          padding: 0.3rem 0.25rem; vertical-align: middle;
          border-bottom: 1px solid var(--divider-color, rgba(128,128,128,0.07));
        }
        .port-row.expandable { cursor: pointer; }
        .port-row.expandable:hover td { background: var(--secondary-background-color, rgba(128,128,128,0.05)); }
        .port-row:last-child td { border-bottom: none; }

        .port-num {
          font-size: ${fs(0.8)}; font-weight: 700; font-variant-numeric: tabular-nums;
          color: var(--secondary-text-color); width: 2rem; text-align: center;
        }
        .port-num.up { color: var(--success-color, #2e8f57); }

        .link-dot {
          display: inline-block; width: 0.48rem; height: 0.48rem;
          border-radius: 50%; background: rgba(128,128,128,0.25); flex-shrink: 0;
        }
        .link-dot.up { background: var(--success-color, #2e8f57); box-shadow: 0 0 4px rgba(46,143,87,0.45); }

        .port-info-cell { width: 100%; }
        .port-info { display: flex; align-items: center; gap: 0.4rem; }
        .port-speed { font-size: ${fs(0.75)}; color: var(--secondary-text-color); white-space: nowrap; }
        .port-speed.active { color: var(--success-color, #2e8f57); }
        .port-label {
          min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
          font-size: ${fs(0.8)}; font-weight: 500; color: var(--primary-text-color);
        }
        .port-label::before {
          content: "·"; margin-right: 0.4rem; color: var(--secondary-text-color);
        }

        .poe-badge {
          font-size: ${fs(0.66)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.05em;
          padding: 0.1rem 0.38rem; border-radius: 999px; white-space: nowrap;
          background: rgba(128,128,128,0.1); color: var(--secondary-text-color);
          border: 1px solid transparent;
        }
        .poe-badge.active {
          background: rgba(3,169,244,0.1); color: var(--primary-color, #03a9f4);
          border-color: rgba(3,169,244,0.22);
        }

        .port-watt {
          font-size: ${fs(0.8)}; font-variant-numeric: tabular-nums;
          color: var(--primary-color, #03a9f4); font-weight: 600;
          white-space: nowrap; min-width: 3.2rem;
          text-align: right; padding-right: 0.35rem;
        }
        .port-watt.zero { color: var(--secondary-text-color); font-weight: 400; }

        .chevron-cell { width: 1.2rem; text-align: center; }
        .chevron {
          display: inline-block; width: 0; height: 0; border-style: solid;
          border-width: 0.26rem 0.2rem 0 0.2rem;
          border-color: var(--secondary-text-color) transparent transparent transparent;
          transition: transform 0.15s ease; opacity: 0.45; vertical-align: middle;
        }
        .chevron.open { transform: rotate(180deg); }

        /* ── Detail row ── */
        .detail-row td {
          padding: 0;
          border-bottom: 1px solid var(--divider-color, rgba(128,128,128,0.07));
        }
        .detail-inner {
          padding: 0.5rem 0.5rem 0.6rem 2.3rem;
          display: flex; gap: 0.6rem 1rem; flex-wrap: wrap;
          background: var(--secondary-background-color, rgba(128,128,128,0.04));
        }
        .d-item { display: flex; flex-direction: column; gap: 0.12rem; min-width: 70px; }
        .d-label {
          font-size: ${fs(0.64)}; text-transform: uppercase;
          letter-spacing: 0.08em; color: var(--secondary-text-color); font-weight: 700;
        }
        .d-value { font-size: ${fs(0.86)}; color: var(--primary-text-color); font-weight: 500; font-variant-numeric: tabular-nums; }
        .d-value.poe  { color: var(--primary-color, #03a9f4); }
        .d-value.good { color: var(--success-color, #2e8f57); }
        .d-value.muted { color: var(--secondary-text-color); }

        /* Label editor */
        .label-edit-row { display: flex; align-items: center; gap: 0.35rem; }
        .label-input {
          width: 9.5rem; max-width: 40vw;
          font-size: ${fs(0.85)}; font-family: inherit;
          padding: 0.22rem 0.45rem; border-radius: 5px;
          border: 1px solid var(--divider-color, rgba(128,128,128,0.3));
          background: var(--ha-card-background, var(--card-background-color));
          color: var(--primary-text-color);
        }
        .label-input:focus { outline: none; border-color: var(--primary-color, #03a9f4); }
        .label-input::placeholder { color: var(--secondary-text-color); opacity: 0.7; }

        /* Configure button */
        .btn-configure {
          font-size: ${fs(0.76)}; font-weight: 600;
          padding: 0.22rem 0.65rem; border-radius: 999px;
          border: 1px solid rgba(3,169,244,0.4);
          background: rgba(3,169,244,0.07);
          color: var(--primary-color, #03a9f4);
          cursor: pointer; white-space: nowrap;
          transition: background 0.15s ease, border-color 0.15s ease;
          align-self: center;
        }
        .btn-configure:hover { background: rgba(3,169,244,0.14); border-color: var(--primary-color); }
        .btn-configure:disabled { opacity: 0.45; cursor: not-allowed; }

        /* ── Configure panel ── */
        .configure-row td {
          padding: 0;
          border-bottom: 1px solid var(--divider-color, rgba(128,128,128,0.07));
        }
        .configure-inner {
          padding: 0.65rem 0.65rem 0.75rem 2.3rem;
          background: var(--secondary-background-color, rgba(128,128,128,0.04));
          border-top: 1px solid rgba(3,169,244,0.2);
          display: flex; flex-direction: column; gap: 0.6rem;
        }
        .configure-title {
          font-size: ${fs(0.7)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.09em;
          color: var(--primary-color, #03a9f4);
        }
        .configure-fields {
          display: flex; gap: 0.75rem 1.25rem; flex-wrap: wrap; align-items: flex-end;
        }
        .cfg-field { display: flex; flex-direction: column; gap: 0.22rem; }
        .cfg-label {
          font-size: ${fs(0.64)}; font-weight: 700;
          text-transform: uppercase; letter-spacing: 0.08em;
          color: var(--secondary-text-color);
        }
        .cfg-select {
          font-size: ${fs(0.86)}; font-family: inherit;
          padding: 0.25rem 0.5rem; border-radius: 6px;
          border: 1px solid var(--divider-color, rgba(128,128,128,0.3));
          background: var(--ha-card-background, var(--card-background-color));
          color: var(--primary-text-color); cursor: pointer;
          min-width: 90px;
        }
        .cfg-select:focus { outline: none; border-color: var(--primary-color); }
        .configure-actions { display: flex; gap: 0.5rem; }
        .btn-apply {
          font-size: ${fs(0.8)}; font-weight: 600;
          padding: 0.25rem 0.8rem; border-radius: 999px;
          border: none; background: var(--primary-color, #03a9f4);
          color: #fff; cursor: pointer;
          transition: opacity 0.15s ease;
        }
        .btn-apply:hover { opacity: 0.85; }
        .btn-apply:disabled { opacity: 0.45; cursor: not-allowed; }
        .btn-cancel {
          font-size: ${fs(0.8)}; font-weight: 600;
          padding: 0.25rem 0.8rem; border-radius: 999px;
          border: 1px solid var(--divider-color, rgba(128,128,128,0.3));
          background: transparent; color: var(--secondary-text-color);
          cursor: pointer; transition: border-color 0.15s ease, color 0.15s ease;
        }
        .btn-cancel:hover { border-color: var(--primary-text-color); color: var(--primary-text-color); }

        ha-switch { --mdc-switch-track-height: 14px; }
        .placeholder { padding: 1rem; color: var(--secondary-text-color); font-size: ${fs(0.9)}; }
      `;
    }

    // ── Render helpers ────────────────────────────────────────────────────────

    _renderToggle(entityId, ariaLabel) {
      if (!entityId) return `<span class="d-value muted">—</span>`;
      const e = this._hass?.states[entityId];
      if (!e)  return `<span class="d-value muted">—</span>`;
      return `<ha-switch ${e.state === "on" ? "checked" : ""} data-entity="${entityId}" aria-label="${this._escapeHtml(ariaLabel || entityId)}"></ha-switch>`;
    }

    _fmtSpeed(raw) {
      if (!raw) return null;
      const m = raw.match(/(\d+)/);
      if (!m) return raw;
      const n = parseInt(m[1]);
      if (n >= 10000) return "10G";
      if (n >= 2500)  return "2.5G";
      if (n >= 1000)  return "1G";
      if (n >= 100)   return "100M";
      return `${n}M`;
    }

    /** Same 80%/95% thresholds used everywhere PoE load gets a color (budget bar, header pill, sparkline). */
    _poeBarColor(pct) {
      return pct > 95 ? "var(--error-color, #c22040)"
        : pct > 80 ? "var(--warning-color, #f4b942)"
        : "var(--primary-color, #03a9f4)";
    }

    /** Local-time ISO string without a "Z" suffix — HA interprets an unzoned timestamp as local time. */
    _localISO(date) {
      const p = n => String(n).padStart(2, "0");
      return `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}` +
        `T${p(date.getHours())}:${p(date.getMinutes())}:${p(date.getSeconds())}`;
    }

    /**
     * Fetches sensor.<prefix>_poe_consumption's history for the configured
     * window and bucketizes it, then patches just the sparkline <svg> in
     * place (_updateSparkline) rather than a full render() — avoids
     * disrupting any expanded port row or in-progress limit edit while the
     * network request is in flight.
     */
    async _refreshPoeHistory() {
      if (!this.config.has_poe || this._poeHistoryFetching || !this._hass) return;
      const now = Date.now();
      if (this._poeHistoryFetchedAt && now - this._poeHistoryFetchedAt < POE_HISTORY_MIN_REFRESH_MS) return;
      this._poeHistoryFetching = true;
      this._poeHistoryFetchedAt = now;

      const pfx    = this.config.entity_prefix;
      const entity = `sensor.${pfx}_poe_consumption`;
      const hours  = this.config.poe_history_hours;
      const end    = new Date();
      const start  = new Date(end.getTime() - hours * 3600 * 1000);
      // Small margin before the window start so a state that hasn't changed
      // in a while still shows up as the carried-forward value at t=0.
      const fetchFrom = new Date(start.getTime() - 30 * 60 * 1000);

      try {
        const path = `history/period/${this._localISO(fetchFrom)}?filter_entity_id=${entity}&end_time=${this._localISO(end)}&minimal_response=true&no_attributes=true`;
        const resp = await this._hass.callApi("GET", path);
        const raw = resp?.[0] ?? [];
        this._poeHistoryBuckets = this._bucketizePoeHistory(raw, start.getTime(), end.getTime());
      } catch (err) {
        console.warn(`${CARD_NAME}: failed to fetch PoE consumption history`, err);
        this._poeHistoryBuckets = null;
      } finally {
        this._poeHistoryFetching = false;
        this._updateSparkline();
      }
    }

    /**
     * Downsamples raw history/period rows into POE_HISTORY_BUCKETS fixed-width
     * buckets, taking the MAX value seen in each bucket (not the average) —
     * the whole point of the sparkline is to surface a momentary spike, which
     * averaging would smooth away. A bucket with no state change in it just
     * carries forward the last known value, matching how entity history
     * actually behaves (state holds until the next recorded change).
     */
    _bucketizePoeHistory(raw, startMs, endMs) {
      const points = raw
        .map(s => ({
          t: s.lu ? s.lu * 1000 : new Date(s.last_changed).getTime(),
          v: parseFloat(s.state),
        }))
        .filter(p => Number.isFinite(p.t) && !isNaN(p.v))
        .sort((a, b) => a.t - b.t);

      if (points.length < 2) return { values: [], purged: true };

      const bucketMs = (endMs - startMs) / POE_HISTORY_BUCKETS;
      const values = new Array(POE_HISTORY_BUCKETS);

      let pointer = 0;
      let carry = points[0].v;
      while (pointer < points.length && points[pointer].t <= startMs) {
        carry = points[pointer].v;
        pointer++;
      }

      for (let b = 0; b < POE_HISTORY_BUCKETS; b++) {
        const bucketEnd = startMs + (b + 1) * bucketMs;
        let bucketMax = -Infinity;
        let saw = false;
        while (pointer < points.length && points[pointer].t < bucketEnd) {
          bucketMax = Math.max(bucketMax, points[pointer].v);
          carry = points[pointer].v;
          saw = true;
          pointer++;
        }
        values[b] = saw ? bucketMax : carry;
      }

      return { values, purged: false };
    }

    /** Patches just the sparkline <svg> after an async history fetch resolves — see _refreshPoeHistory. */
    _updateSparkline() {
      const svg = this.querySelector("#poe-history-spark");
      if (!svg) return; // not currently on screen (hidden layout, has_poe off, ...) — next full render() picks up fresh data
      // Re-read the live budget limit rather than trusting a stale closure —
      // it's power_limit_w off the sensor, NEVER max_poe_watts (that's only
      // the editor's client-side input cap, see the CLAUDE.md gotcha on it).
      const pfx = this.config.entity_prefix;
      const limitW = parseFloat(this._e(`sensor.${pfx}_poe_consumption`)?.attributes?.power_limit_w ?? 0) || 0;
      svg.outerHTML = this._renderPoeSparkSvg(limitW);
    }

    /** Kicks off/refreshes the history fetch and returns the wrapper markup — the <svg> itself is filled in by _renderPoeSparkSvg. */
    _renderPoeSparkline(limitW) {
      if (!limitW) return ""; // no hardware budget to scale a percentage against
      this._refreshPoeHistory();
      const hours = this.config.poe_history_hours;
      return `
        <div class="poe-spark-wrap">
          ${this._renderPoeSparkSvg(limitW)}
          <div class="poe-spark-foot">
            <span>${_t(this._hass, "spark_ago", { h: hours })}</span>
            <span>${_t(this._hass, "spark_now")}</span>
          </div>
        </div>`;
    }

    _renderPoeSparkSvg(limitW) {
      const W = 300, H = 28, PAD = 2;
      const data = this._poeHistoryBuckets;
      if (!data || data.purged || data.values.length === 0) {
        return `<svg class="poe-spark" id="poe-history-spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"></svg>`;
      }
      const limit  = limitW > 0 ? limitW : 1;
      const values = data.values;
      const n      = values.length;
      const scaleMax = Math.max(limit, ...values);
      const x = i => (i / (n - 1)) * W;
      const y = v => H - PAD - (v / scaleMax) * (H - PAD * 2);

      // Subtle fill under the line, then dashed 80%/95% threshold guides —
      // without these the line reads as flat/context-free on a switch
      // that's nowhere near its budget, even though that IS the correct
      // reading (see the mockup this was built from: the guides are what
      // make "far from the danger zone" visually legible, not the line
      // itself).
      let fillD = `M ${x(0).toFixed(1)} ${H} L ${x(0).toFixed(1)} ${y(values[0]).toFixed(1)}`;
      for (let i = 1; i < n; i++) fillD += ` L ${x(i).toFixed(1)} ${y(values[i]).toFixed(1)}`;
      fillD += ` L ${x(n - 1).toFixed(1)} ${H} Z`;

      let markup = `<path d="${fillD}" fill="var(--secondary-text-color, #9e9e9e)" opacity="0.08" stroke="none"/>`;
      markup += `<line x1="0" y1="${y(limit * 0.95).toFixed(1)}" x2="${W}" y2="${y(limit * 0.95).toFixed(1)}" stroke="var(--error-color, #c22040)" stroke-opacity="0.3" stroke-width="1" stroke-dasharray="2 2"/>`;
      markup += `<line x1="0" y1="${y(limit * 0.8).toFixed(1)}" x2="${W}" y2="${y(limit * 0.8).toFixed(1)}" stroke="var(--warning-color, #f4b942)" stroke-opacity="0.3" stroke-width="1" stroke-dasharray="2 2"/>`;

      for (let i = 1; i < n; i++) {
        const v0 = values[i - 1], v1 = values[i];
        const segPct = Math.min(100, (Math.max(v0, v1) / limit) * 100);
        const color = this._poeBarColor(segPct);
        markup += `<line x1="${x(i - 1).toFixed(1)}" y1="${y(v0).toFixed(1)}" x2="${x(i).toFixed(1)}" y2="${y(v1).toFixed(1)}" stroke="${color}" stroke-width="1.6" stroke-linecap="round"/>`;
      }
      return `<svg class="poe-spark" id="poe-history-spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${markup}</svg>`;
    }

    _renderOverview() {
      const pfx    = this.config.entity_prefix;
      const hasPoe = this.config.has_poe;
      const layout = this.config.overview_layout;
      const fields = this.config.overview_fields;

      if (layout === "hidden" || fields.length === 0) return "";

      const poeS = hasPoe ? this._e(`sensor.${pfx}_poe_consumption`) : null;
      const netS = this._e(`sensor.${pfx}_network_info`);

      const consumed = parseFloat(poeS?.state ?? 0) || 0;
      const limitW   = parseFloat(poeS?.attributes?.power_limit_w ?? 0) || 0;
      const remainW  = parseFloat(poeS?.attributes?.power_remain_w ?? 0) || 0;
      const pct      = limitW > 0 ? Math.min(100, (consumed / limitW) * 100) : 0;
      const barColor = this._poeBarColor(pct);

      const ip        = netS?.state ?? "—";
      const mac       = netS?.attributes?.mac ?? "—";
      const gateway   = netS?.attributes?.gateway ?? "—";
      const mask      = netS?.attributes?.netmask ?? "—";
      const switchUrl = this.config.show_switch_link ? this._getSwitchUrl() : null;

      const maxPoeW = this.config.max_poe_watts;
      const limitEditorHtml = hasPoe && this._editingLimit ? `
        <div class="limit-editor">
          <input class="limit-input" type="number" id="poe-limit-input"
            value="${this._pendingLimit || limitW}"
            min="1" max="${maxPoeW || 1000}" step="0.5">
          <span class="limit-unit">W</span>
          ${maxPoeW ? `<span class="limit-unit" style="color:var(--secondary-text-color)">${_t(this._hass, "limit_max_suffix", { max: maxPoeW })}</span>` : ""}
          <span class="limit-error" id="poe-limit-error" style="display:none;color:var(--error-color, #c22040);font-size:${this._fs(0.72)}"></span>
          <button class="btn-apply" id="poe-limit-apply" ${this._applyingLimit ? "disabled" : ""}>
            ${this._applyingLimit ? _t(this._hass, "btn_applying") : _t(this._hass, "btn_set")}
          </button>
          <button class="btn-cancel" id="poe-limit-cancel">${_t(this._hass, "btn_cancel")}</button>
        </div>` : "";

      const renderField = field => {
        switch (field) {
          case "ip":
            return `
              <div class="ov-item copyable" data-copy="${this._escapeHtml(ip)}">
                <div class="ov-label">${_t(this._hass, "ov_label_ip")}</div>
                <div class="ov-value-row">
                  <div class="ov-value" style="flex:1">${this._escapeHtml(ip)}</div>
                  ${switchUrl ? `<a class="ui-link" href="${this._escapeHtml(switchUrl)}" target="_blank" rel="noreferrer" title="${_t(this._hass, "switch_ui_title")}">
                    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                      <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                    </svg>
                  </a>` : ""}
                </div>
              </div>`;

          case "mac":
            return `
              <div class="ov-item copyable" data-copy="${this._escapeHtml(mac)}">
                <div class="ov-label">${_t(this._hass, "ov_label_mac")}</div>
                <div class="ov-value" style="font-size:${this._fs(0.76)};letter-spacing:0.02em">${this._escapeHtml(mac)}</div>
              </div>`;

          case "gateway":
            return `
              <div class="ov-item">
                <div class="ov-label">${_t(this._hass, "ov_label_gateway")}</div>
                <div class="ov-value">${this._escapeHtml(gateway)}</div>
              </div>`;

          case "netmask":
            return `
              <div class="ov-item">
                <div class="ov-label">${_t(this._hass, "ov_label_netmask")}</div>
                <div class="ov-value">${this._escapeHtml(mask)}</div>
              </div>`;

          case "poe_used":
            return hasPoe ? `
              <div class="ov-item">
                <div class="ov-label">${_t(this._hass, "ov_label_poe_used")}</div>
                <div class="ov-value poe">${consumed.toFixed(1)} W</div>
              </div>` : "";

          case "poe_remaining":
            return hasPoe ? `
              <div class="ov-item">
                <div class="ov-label">${_t(this._hass, "ov_label_poe_remaining")}</div>
                <div class="ov-value remain">${remainW.toFixed(1)} W</div>
              </div>` : "";

          case "poe_budget":
            return hasPoe ? `
              <div class="poe-bar-wrap">
                <div class="poe-bar-header">
                  <div class="ov-label">${_t(this._hass, "ov_label_poe_budget")}</div>
                  <div style="display:flex;align-items:center;gap:0.3rem">
                    <div class="ov-label">${consumed.toFixed(1)} / ${limitW} W (${pct.toFixed(0)}%)</div>
                    <button class="edit-pencil" id="poe-limit-edit" title="${_t(this._hass, "pencil_title")}">✏️</button>
                  </div>
                </div>
                <div class="poe-bar-track">
                  <div class="poe-bar-fill" style="width:${pct.toFixed(1)}%;background:${barColor}"></div>
                </div>
                ${limitEditorHtml}
                ${this._renderPoeSparkline(limitW)}
              </div>` : "";

          default:
            return "";
        }
      };

      const overviewHtml = fields.map(renderField).join("");
      if (!overviewHtml.trim()) return "";

      return `
        <div class="overview ${layout === "compact" ? "compact" : ""}">
          ${overviewHtml}
        </div>`;
    }

    _renderPort(port, hasPoe) {
      const ent   = this._portEntities(port);
      const isUp  = ent.state?.state === "on";
      const poeOn = ent.poeState?.state === "on";
      const watts = hasPoe ? (parseFloat(ent.poeState?.attributes?.power_w ?? 0) || 0) : 0;
      const speed       = ent.state?.attributes?.speed ?? null;
      const speedConfig = ent.state?.attributes?.speed_config ?? null;
      const portLabel   = this._effectiveLabel(port);
      const safeLabel   = portLabel ? this._escapeHtml(portLabel) : "";

      const pfx         = this.config.entity_prefix;
      const poeEnabledId  = hasPoe && ent.poeEnabled  ? `switch.${pfx}_port_${port}_poe_enabled`  : null;
      const portEnabledId = ent.portEnabled ? `switch.${pfx}_port_${port}_enabled` : null;

      const hasToggles  = !!(poeEnabledId || portEnabledId);
      const canExpand   = hasToggles || this.config.editable_labels;
      const expanded    = canExpand && this._expanded.has(port);
      const configuring = this._configuring.has(port);
      const applying    = this._applying.has(port);

      const mainRow = `
        <tr class="port-row${canExpand ? " expandable" : ""}" data-port="${port}"
          ${canExpand ? `role="button" tabindex="0" aria-expanded="${expanded}" aria-label="${_t(this._hass, "port_word")} ${port}${safeLabel ? ` ${safeLabel}` : ""} ${_t(this._hass, "details_word")}"` : ""}>
          <td class="port-num ${isUp ? "up" : ""}">P${port}</td>
          <td class="port-info-cell">
            <div class="port-info">
              <span class="link-dot ${isUp ? "up" : ""}"></span>
              <span class="port-speed ${isUp ? "active" : ""}">${isUp && speed ? this._fmtSpeed(speed) : isUp ? _t(this._hass, "word_up") : _t(this._hass, "word_down")}</span>
              ${safeLabel ? `<span class="port-label" title="${safeLabel}">${safeLabel}</span>` : ""}
              ${hasPoe ? `<span class="poe-badge ${poeOn ? "active" : ""}">${poeOn ? _t(this._hass, "poe_badge_on") : _t(this._hass, "poe_badge_off")}</span>` : ""}
            </div>
          </td>
          <td class="port-watt ${!hasPoe || watts === 0 ? "zero" : ""}">${hasPoe && watts > 0 ? watts.toFixed(1) + " W" : hasPoe ? "—" : ""}</td>
          <td class="chevron-cell">${canExpand ? `<span class="chevron ${expanded ? "open" : ""}"></span>` : ""}</td>
        </tr>`;

      if (!expanded) return mainRow;

      const attr    = ent.poeState?.attributes ?? {};
      const pending = this._pendingPoe.get(port) ?? {};

      // Inline label editor — draft survives re-renders triggered by entity updates
      const savingLabel = this._savingLabel.has(port);
      const draft       = this._labelDrafts.get(port);
      const labelEditor = this.config.editable_labels ? `
        <div class="d-item">
          <div class="d-label">${_t(this._hass, "d_label_label")}</div>
          <div class="label-edit-row">
            <input class="label-input" type="text" maxlength="${MAX_LABEL_LENGTH}"
              placeholder="${_t(this._hass, "label_placeholder")}" data-label-port="${port}"
              value="${this._escapeHtml(draft ?? portLabel)}">
            <button class="btn-apply" data-label-save="${port}" ${savingLabel ? "disabled" : ""}>
              ${savingLabel ? _t(this._hass, "btn_saving") : _t(this._hass, "btn_save")}
            </button>
          </div>
        </div>` : "";

      // Detail row — read-only values + toggles + label editor + Configure button
      const detailRow = `
        <tr class="detail-row">
          <td colspan="4">
            <div class="detail-inner">
              ${isUp && speed ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_speed")}</div><div class="d-value good">${this._fmtSpeed(speed)}</div></div>` : ""}
              ${speedConfig   ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_configured")}</div><div class="d-value muted">${speedConfig}</div></div>` : ""}
              ${hasPoe && poeOn ? `
                <div class="d-item"><div class="d-label">${_t(this._hass, "d_label_power")}</div><div class="d-value poe">${watts.toFixed(1)} W</div></div>
                ${attr.current_ma != null ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_current")}</div><div class="d-value">${attr.current_ma} mA</div></div>` : ""}
                ${attr.voltage_v  != null ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_voltage")}</div><div class="d-value">${attr.voltage_v} V</div></div>` : ""}
                ${attr.pd_class   ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_pd_class")}</div><div class="d-value">${attr.pd_class}</div></div>` : ""}
              ` : ""}
              ${hasPoe && attr.priority    ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_priority")}</div><div class="d-value">${attr.priority}</div></div>` : ""}
              ${hasPoe && attr.power_limit ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_limit")}</div><div class="d-value">${attr.power_limit}</div></div>` : ""}
              ${poeEnabledId  ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_poe_enabled")}</div>${this._renderToggle(poeEnabledId, _t(this._hass, "aria_poe_enabled", { port }))}</div>`  : ""}
              ${portEnabledId ? `<div class="d-item"><div class="d-label">${_t(this._hass, "d_label_port_enabled")}</div>${this._renderToggle(portEnabledId, _t(this._hass, "aria_port_enabled", { port }))}</div>` : ""}
              ${labelEditor}
              ${hasPoe ? `<button class="btn-configure" data-configure="${port}" ${applying ? "disabled" : ""}>
                ${applying ? _t(this._hass, "btn_applying") : _t(this._hass, "btn_configure_poe")}
              </button>` : ""}
            </div>
          </td>
        </tr>`;

      // Configure panel — shown below detail row when open
      const configureRow = configuring ? `
        <tr class="configure-row">
          <td colspan="4">
            <div class="configure-inner">
              <div class="configure-title">${_t(this._hass, "configure_title", { port })}</div>
              <div class="configure-fields">
                <div class="cfg-field">
                  <div class="cfg-label">${_t(this._hass, "d_label_priority")}</div>
                  <select class="cfg-select" data-cfg-port="${port}" data-cfg-key="priority">
                    ${POE_PRIORITIES.map(v => `<option value="${v}" ${(pending.priority ?? attr.priority) === v ? "selected" : ""}>${v}</option>`).join("")}
                  </select>
                </div>
                <div class="cfg-field">
                  <div class="cfg-label">${_t(this._hass, "cfg_label_power_limit")}</div>
                  <select class="cfg-select" data-cfg-port="${port}" data-cfg-key="power_limit">
                    ${POE_POWER_LIMITS.map(v => `<option value="${v}" ${(pending.power_limit ?? attr.power_limit) === v ? "selected" : ""}>${v}</option>`).join("")}
                  </select>
                </div>
              </div>
              <div class="configure-actions">
                <button class="btn-apply" data-apply-port="${port}" ${applying ? "disabled" : ""}>
                  ${applying ? _t(this._hass, "btn_applying") : _t(this._hass, "btn_apply")}
                </button>
                <button class="btn-cancel" data-cancel-port="${port}">${_t(this._hass, "btn_cancel")}</button>
              </div>
            </div>
          </td>
        </tr>` : "";

      return mainRow + detailRow + configureRow;
    }

    _totalWatts(ports) {
      return ports.reduce((sum, port) =>
        sum + (parseFloat(this._portEntities(port).poeState?.attributes?.power_w ?? 0) || 0), 0);
    }

    // ── Main render ───────────────────────────────────────────────────────────

    render() {
      if (!this.config) return;
      if (!this._hass) {
        this.innerHTML = `<div class="card"><style>${this._css()}</style><div class="placeholder">${_t(this._hass, "placeholder_waiting")}</div></div>`;
        return;
      }

      this._portEntitiesCache.clear();
      this._localLabelsCache = null;

      const hasPoe       = this.config.has_poe;
      const poePorts     = hasPoe ? Array.from({ length: this.config.poe_ports }, (_, i) => i + 1) : [];
      const regularPorts = Array.from(
        { length: this.config.total_ports - poePorts.length },
        (_, i) => i + poePorts.length + 1
      );

      const totalWatts = this._totalWatts(poePorts);
      const portsUp    = [...poePorts, ...regularPorts].filter(p => this._portEntities(p).state?.state === "on").length;
      const poeActive  = poePorts.filter(p => this._portEntities(p).poeState?.state === "on").length;
      const pfx        = this.config.entity_prefix;
      const limitW     = hasPoe
        ? (parseFloat(this._e(`sensor.${pfx}_poe_consumption`)?.attributes?.power_limit_w ?? 0) || 0)
        : 0;
      // Mirror the budget bar's own amber/red thresholds on the header pill,
      // so overall load is visible at a glance even when overview_layout: hidden.
      const headerPoePct   = limitW > 0 ? Math.min(100, (totalWatts / limitW) * 100) : 0;
      const headerPoeColor = this._poeBarColor(headerPoePct);

      this.innerHTML = `
        <div class="card">
          <style>${this._css()}</style>
          <div class="card-header">
            <div class="card-title">${this.config.title || _t(this._hass, "title_default")}</div>
            <div class="summary-pills">
              <div class="pill up">${_t(this._hass, "pill_up", { up: portsUp, total: this.config.total_ports })}</div>
              ${hasPoe ? `<div class="pill poe" style="color:${headerPoeColor}">${_t(this._hass, "pill_poe", { active: poeActive, watts: totalWatts.toFixed(1) })}</div>` : ""}
            </div>
          </div>

          ${this._renderOverview()}

          ${hasPoe ? `
          <div class="section">
            <div class="section-header">
              <div class="section-label">${_t(this._hass, "section_poe_ports", { to: this.config.poe_ports })}</div>
              <div class="section-stat">${_t(this._hass, "stat_total")} <span>${totalWatts.toFixed(1)} W</span> ${_t(this._hass, "stat_of")} ${limitW} W</div>
            </div>
            <table class="port-table">
              <tbody>${poePorts.map(p => this._renderPort(p, true)).join("")}</tbody>
            </table>
          </div>
          ` : ""}

          <div class="section">
            <div class="section-header">
              <div class="section-label">${hasPoe ? _t(this._hass, "section_ports", { from: this.config.poe_ports + 1, to: this.config.total_ports }) : _t(this._hass, "section_ports", { from: 1, to: this.config.total_ports })}</div>
            </div>
            <table class="port-table">
              <tbody>${regularPorts.map(p => this._renderPort(p, false)).join("")}</tbody>
            </table>
          </div>
        </div>`;

      this._bindEvents();
    }

    // ── Event binding ─────────────────────────────────────────────────────────

    _clipboardFallback(text, onSuccess) {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.cssText = "position:fixed;top:0;left:0;opacity:0;pointer-events:none";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(ta);
        if (ok && onSuccess) onSuccess();
      } catch (err) {
        console.warn("tplink-switch-card: clipboard copy failed", err);
      }
    }

    _bindEvents() {
      // Port row expand/collapse
      this.querySelectorAll(".port-row.expandable").forEach(row => {
        row.addEventListener("click", e => {
          if (e.target.closest("ha-switch, button, select, input, a")) return;
          this._toggleExpand(parseInt(row.dataset.port));
        });
        row.addEventListener("keydown", e => {
          if (e.key !== "Enter" && e.key !== " ") return;
          if (e.target.closest("ha-switch, button, select, input, a")) return;
          e.preventDefault();
          this._toggleExpand(parseInt(row.dataset.port));
        });
      });

      // Toggle switches
      this.querySelectorAll("ha-switch[data-entity]").forEach(sw => {
        sw.addEventListener("change", e => { e.stopPropagation(); this._toggle(sw.dataset.entity); });
        sw.addEventListener("click",  e => e.stopPropagation());
      });

      // Configure PoE button
      this.querySelectorAll("[data-configure]").forEach(btn => {
        btn.addEventListener("click", e => {
          e.stopPropagation();
          this._openConfigure(parseInt(btn.dataset.configure));
        });
      });

      // Configure panel — select change
      this.querySelectorAll(".cfg-select[data-cfg-port]").forEach(sel => {
        sel.addEventListener("change", e => {
          e.stopPropagation();
          const port = parseInt(sel.dataset.cfgPort);
          const key  = sel.dataset.cfgKey;
          const cur  = this._pendingPoe.get(port) ?? {};
          this._pendingPoe.set(port, { ...cur, [key]: sel.value });
        });
      });

      // Apply button
      this.querySelectorAll("[data-apply-port]").forEach(btn => {
        btn.addEventListener("click", e => {
          e.stopPropagation();
          this._applyPortPoe(parseInt(btn.dataset.applyPort));
        });
      });

      // Cancel button
      this.querySelectorAll("[data-cancel-port]").forEach(btn => {
        btn.addEventListener("click", e => {
          e.stopPropagation();
          this._cancelConfigure(parseInt(btn.dataset.cancelPort));
        });
      });

      // Label editor — input keeps a draft (no re-render), Enter or Save persists
      this.querySelectorAll(".label-input[data-label-port]").forEach(inp => {
        const port = parseInt(inp.dataset.labelPort);
        inp.addEventListener("click", e => e.stopPropagation());
        inp.addEventListener("input", () => {
          this._labelDrafts.set(port, inp.value);
        });
        inp.addEventListener("keydown", e => {
          e.stopPropagation();
          if (e.key === "Enter") this._saveLabel(port, inp.value);
          if (e.key === "Escape") {
            this._labelDrafts.delete(port);
            this.render();
          }
        });
      });
      this.querySelectorAll("[data-label-save]").forEach(btn => {
        btn.addEventListener("click", e => {
          e.stopPropagation();
          const port = parseInt(btn.dataset.labelSave);
          const inp  = this.querySelector(`.label-input[data-label-port="${port}"]`);
          this._saveLabel(port, inp?.value ?? "");
        });
      });

      // Copyable tiles
      this.querySelectorAll(".ov-item.copyable[data-copy]").forEach(tile => {
        tile.addEventListener("click", e => {
          if (e.target.closest("a")) return;
          const val = tile.dataset.copy;
          if (!val || val === "—") return;

          const markCopied = () => {
            tile.classList.add("copied");
            setTimeout(() => tile.classList.remove("copied"), 1500);
          };

          // Modern clipboard API (requires HTTPS or localhost)
          if (navigator.clipboard?.writeText) {
            navigator.clipboard.writeText(val).then(markCopied).catch(() => {
              this._clipboardFallback(val, markCopied);
            });
          } else {
            this._clipboardFallback(val, markCopied);
          }
        });
      });

      // PoE limit edit pencil
      this.querySelector("#poe-limit-edit")?.addEventListener("click", e => {
        e.stopPropagation();
        const pfx  = this.config.entity_prefix;
        const limitW = parseFloat(this._e(`sensor.${pfx}_poe_consumption`)?.attributes?.power_limit_w ?? 0) || 0;
        this._pendingLimit = String(limitW);
        this._editingLimit = true;
        this.render();
      });

      // PoE limit input — only sync value, no re-render
      this.querySelector("#poe-limit-input")?.addEventListener("input", e => {
        this._pendingLimit = e.target.value;
      });

      // PoE limit apply
      this.querySelector("#poe-limit-apply")?.addEventListener("click", e => {
        e.stopPropagation();
        this._applyPoeLimitGlobal();
      });

      // PoE limit cancel
      this.querySelector("#poe-limit-cancel")?.addEventListener("click", e => {
        e.stopPropagation();
        this._editingLimit = false;
        this._pendingLimit = "";
        this.render();
      });
    }
  }

  customElements.define(CARD_NAME, TplinkSwitchCard);

  // ── Visual editor ──────────────────────────────────────────────────────────
  //
  // Built on ha-form (Home Assistant's built-in schema-driven form component,
  // globally available in the frontend — same pattern already relied on for
  // ha-switch elsewhere in this file). port_labels is deliberately NOT exposed
  // here: it already has a better, WYSIWYG editing flow directly in the card
  // itself (click a port row → Label field), so duplicating it as a form list
  // would be redundant and worse UX. overview_fields is a simple multi-select
  // (fixed order) rather than a reorderable list — full drag-reordering isn't
  // worth the complexity for a card editor.

  class TplinkSwitchCardEditor extends HTMLElement {
    setConfig(config) {
      this._config = config;
      this._render();
    }

    set hass(hass) {
      this._hass = hass;
      this._render();
    }

    connectedCallback() {
      this._render();
    }

    // Suggests entity prefixes actually present in this HA instance, since a
    // mismatched entity_prefix (the #1 setup mistake) silently shows no data.
    _entityPrefixSelector() {
      const suffix = "_network_info";
      const states = this._hass?.states ?? {};
      const prefixes = Object.keys(states)
        .filter(id => id.startsWith("sensor.") && id.endsWith(suffix))
        .map(id => id.slice("sensor.".length, -suffix.length));
      if (!prefixes.length) return { text: {} };
      return { select: { mode: "dropdown", custom_value: true, options: [...new Set(prefixes)] } };
    }

    _schema() {
      const hasPoe = this._config?.has_poe !== false;
      const schema = [
        { name: "title", selector: { text: {} } },
        { name: "entity_prefix", selector: this._entityPrefixSelector() },
        { name: "has_poe", selector: { boolean: {} } },
      ];
      if (hasPoe) {
        schema.push(
          { name: "poe_ports", selector: { number: { min: 0, max: 48, mode: "box" } } },
          { name: "max_poe_watts", selector: { number: { min: 0, mode: "box" } } },
          { name: "poe_history_hours", selector: { number: { min: 1, max: MAX_POE_HISTORY_HOURS, mode: "box" } } },
        );
      }
      schema.push(
        { name: "total_ports", selector: { number: { min: 1, max: 48, mode: "box" } } },
        { name: "overview_layout", selector: { select: { mode: "dropdown", options: [
          { value: "tiles", label: _t(this._hass, "editor_layout_tiles") },
          { value: "compact", label: _t(this._hass, "editor_layout_compact") },
          { value: "hidden", label: _t(this._hass, "editor_layout_hidden") },
        ] } } },
        { name: "overview_fields", selector: { select: {
          multiple: true,
          mode: "list",
          options: DEFAULT_OVERVIEW_FIELDS.map(f => ({ value: f, label: _t(this._hass, "editor_field_" + f) })),
        } } },
        { name: "show_switch_link", selector: { boolean: {} } },
        { name: "font_scale", selector: { number: { min: 0.7, max: 2, step: 0.1, mode: "slider" } } },
        { name: "editable_labels", selector: { boolean: {} } },
      );
      return schema;
    }

    _computeLabel(schema) {
      return _t(this._hass, "editor_" + schema.name);
    }

    _render() {
      if (!this._config || !this._hass) return;
      let form = this.querySelector("ha-form");
      if (!form) {
        form = document.createElement("ha-form");
        form.addEventListener("value-changed", e => {
          e.stopPropagation();
          this.dispatchEvent(new CustomEvent("config-changed", {
            detail: { config: e.detail.value },
            bubbles: true,
            composed: true,
          }));
        });
        this.innerHTML = "";
        this.appendChild(form);
      }
      form.hass = this._hass;
      form.data = this._config;
      form.schema = this._schema();
      form.computeLabel = this._computeLabel.bind(this);
    }
  }

  customElements.define(`${CARD_NAME}-editor`, TplinkSwitchCardEditor);
})();
